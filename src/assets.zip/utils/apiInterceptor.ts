import { limpiarSesion } from '../services/authService';

/**
 * Mostrar toast de expiración de sesión
 */
const mostrarToastExpiracion = () => {
  // Crear elemento toast
  const toast = document.createElement('div');
  toast.className = 'fixed top-4 right-4 z-50 max-w-sm w-full bg-red-500 text-white p-4 rounded-lg shadow-lg transform transition-all duration-300 ease-in-out';
  toast.innerHTML = `
    <div class="flex items-center">
      <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
      </svg>
      <div>
        <p class="font-medium">Sesión expirada</p>
        <p class="text-sm opacity-90">Inicia sesión nuevamente</p>
      </div>
    </div>
  `;
  
  document.body.appendChild(toast);
  
  // Remover toast después de 3 segundos
  setTimeout(() => {
    if (toast.parentNode) {
      toast.parentNode.removeChild(toast);
    }
  }, 3000);
};

/**
 * Interceptor global para manejar respuestas de API
 * Verifica si el token ha expirado y redirige al login automáticamente
 */
export const handleApiResponse = async (response: Response): Promise<Response> => {
  // Si la respuesta es 401 (Unauthorized), el token ha expirado
  if (response.status === 401) {
    console.log('Token expirado - redirigiendo al login');
    mostrarToastExpiracion();
    limpiarSesion();
    setTimeout(() => {
      window.location.reload();
    }, 1000);
    throw new Error('Sesión expirada. Por favor, inicia sesión nuevamente.');
  }

  // Si la respuesta es OK, verificar el contenido JSON para otros indicadores de token expirado
  if (response.ok) {
    try {
      const data = await response.clone().json();
      
      // Verificar si el estatus indica token expirado o sesión inválida
      if (data.estatus === 401 || 
          data.estatus === 403 || 
          (data.message && data.message.toLowerCase().includes('token')) ||
          (data.message && data.message.toLowerCase().includes('sesión')) ||
          (data.message && data.message.toLowerCase().includes('autorización'))) {
        
        console.log('Token expirado detectado en respuesta - redirigiendo al login');
        mostrarToastExpiracion();
        limpiarSesion();
        setTimeout(() => {
          window.location.reload();
        }, 1000);
        throw new Error('Sesión expirada. Por favor, inicia sesión nuevamente.');
      }
    } catch (jsonError) {
      // Si no se puede parsear como JSON, continuar normalmente
      console.log('Respuesta no es JSON válido, continuando...');
    }
  }

  return response;
};

/**
 * Wrapper para fetch que incluye manejo automático de expiración de token
 */
export const fetchWithAuth = async (url: string, options: RequestInit = {}): Promise<Response> => {
  try {
    const response = await fetch(url, options);
    return await handleApiResponse(response);
  } catch (error) {
    // Si es un error de token expirado, ya se manejó en handleApiResponse
    throw error;
  }
};