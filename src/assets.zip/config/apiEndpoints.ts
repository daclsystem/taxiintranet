/** RideFleetApi: place, distancia y ruta (antes ruta.indevsoft.com directo) */
export const DISTANCIA_TIEMPO_API_BASE =
  'https://apiservices.zmovilidad.app/api/WDistanciatiempodireccion';
