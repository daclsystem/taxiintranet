import { TrackingResponse, RutaResponse } from '../types/tracking';
import { DISTANCIA_TIEMPO_API_BASE } from '../config/apiEndpoints';

const API_BASE_URL = 'https://apiservices.zmovilidad.app/api/Operaciones';

/**
 * Servicio para obtener datos de tracking
 */
export const obtenerTracking = async (token: string): Promise<TrackingResponse> => {
  try {
    const response = await fetch(`${API_BASE_URL}/Tracking?tokens=${token}&tservicio=1`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      }
    });

    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`);
    }

    const data: TrackingResponse = await response.json();
    
    if (data.estatus !== 200) {
      throw new Error(data.message || 'Error al obtener tracking');
    }

    return data;
  } catch (error) {
    console.error('Error al obtener tracking:', error);
    throw new Error('Error de conexión. Intenta nuevamente.');
  }
};

/**
 * Servicio para obtener ruta entre conductor y primer punto
 */
export const obtenerRuta = async (
  conductorLat: number, 
  conductorLng: number, 
  destinoLat: number, 
  destinoLng: number
): Promise<RutaResponse> => {
  try {
    const origin = `${conductorLat},${conductorLng}`;
    const destination = `${destinoLat},${destinoLng}`;
    const response = await fetch(
      `${DISTANCIA_TIEMPO_API_BASE}/Route?origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}&tipo=1&sistema=udemo`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          version: '1',
        },
      }
    );

    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`);
    }

    const data: RutaResponse = await response.json();

    const ok =
      data.status === 200 ||
      (data as RutaResponse & { estatus?: number }).estatus === 200 ||
      (data.time != null && data.distance != null);
    if (!ok) {
      throw new Error('Error al obtener ruta');
    }

    return data;
  } catch (error) {
    console.error('Error al obtener ruta:', error);
    throw new Error('Error de conexión al obtener ruta.');
  }
};