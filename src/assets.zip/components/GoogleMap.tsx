import React, { useEffect, useRef, useState } from 'react';
import { Loader } from '@googlemaps/js-api-loader';
import { Loader2, AlertCircle } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import mapsLightStyle from '../assets/maps.json';
import mapsDarkStyle from '../assets/oscuro.json';

interface GoogleMapProps {
  origen?: { lat: number; lng: number; direccion: string };
  destino?: { lat: number; lng: number; direccion: string };
  conductor?: { lat: number; lng: number; nombre: string; angulo?: number };
  puntosIntermedios?: Array<{ lat: number; lng: number; direccion: string }>;
  todosLosPuntos?: Array<{ lat: number; lng: number; direccion: string }>;
  rutaConductor?: Array<{ lat: number; lng: number }>;
  rutaGPS?: Array<{ lat: number; lng: number }>;
  mostrarRutaCompleta?: boolean;
  onLocationSelect?: (lat: number, lng: number, address: string) => void;
  onMarkerDrag?: (type: 'origen' | 'destino', lat: number, lng: number, address: string) => void;
  useCustomPins?: boolean; // Solo para Solicitar Servicio
  className?: string;
}

/**
 * Componente de Google Maps integrado
 * Muestra origen, destino, conductor y puntos intermedios
 */
export const GoogleMap: React.FC<GoogleMapProps> = ({
  origen,
  destino,
  conductor,
  puntosIntermedios = [],
  todosLosPuntos = [],
  rutaConductor = [],
  rutaGPS = [],
  mostrarRutaCompleta = false,
  onLocationSelect,
  onMarkerDrag,
  useCustomPins = false, // Por defecto false para mantener compatibilidad
  className = ''
}) => {
  const { resolvedTheme } = useTheme();
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const directionsServiceRef = useRef<google.maps.DirectionsService | null>(null);
  const directionsRendererRef = useRef<google.maps.DirectionsRenderer | null>(null);
  const conductorRouteRendererRef = useRef<google.maps.DirectionsRenderer | null>(null);
  const polylineRef = useRef<google.maps.Polyline | null>(null);
  const gpsRoutePolylineRef = useRef<google.maps.Polyline | null>(null);
  const isInitializedRef = useRef<boolean>(false);
  const lastUpdateKeyRef = useRef<string>('');
  
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const API_KEY = 'AIzaSyB1xLDVYxgUq07jmqvNdGpJIsJ7UNvMWMk';

  useEffect(() => {
    if (!isInitializedRef.current) {
      initializeMap();
    }
  }, []);

  useEffect(() => {
    if (mapInstanceRef.current) {
      updateMapTheme();
    }
  }, [resolvedTheme]);
  
  useEffect(() => {
    // Crear una clave única basada en las ubicaciones para evitar updates innecesarios
    const updateKey = JSON.stringify({
      origen: origen ? `${origen.lat}-${origen.lng}` : null,
      destino: destino ? `${destino.lat}-${destino.lng}` : null,
      conductor: conductor ? `${conductor.lat}-${conductor.lng}-${conductor.angulo}` : null,
      todosLosPuntos: todosLosPuntos.map(p => `${p.lat}-${p.lng}`).join('|'),
      rutaConductor: rutaConductor.map(p => `${p.lat}-${p.lng}`).join('|'),
      rutaGPS: rutaGPS?.map(p => `${p.lat}-${p.lng}`).join('|') || '',
      mostrarRutaCompleta
    });

    // Solo actualizar si realmente cambió algo importante
    if (mapInstanceRef.current && updateKey !== lastUpdateKeyRef.current) {
      lastUpdateKeyRef.current = updateKey;
      updateMarkers();
      if (mostrarRutaCompleta && origen && destino) {
        calculateRoute();
      } else if (rutaConductor.length > 0) {
        drawConductorRoute();
      }
      if (rutaGPS && rutaGPS.length > 0) {
        drawGPSRoute();
      }
    }
  }, [origen, destino, conductor, puntosIntermedios, todosLosPuntos, rutaConductor, rutaGPS, mostrarRutaCompleta]);

  const updateMapTheme = () => {
    if (!mapInstanceRef.current) return;

    const mapStyles = resolvedTheme === 'dark' ? mapsDarkStyle : mapsLightStyle;
    mapInstanceRef.current.setOptions({
      styles: mapStyles
    });
  };
  
  const initializeMap = async () => {
    if (!mapRef.current) return;

    try {
      setIsLoading(true);
      setError(null);

      const loader = new Loader({
        apiKey: API_KEY,
        version: 'weekly',
        libraries: ['places', 'geometry']
      });

      await loader.load();

      // Re-verificar que el elemento aún existe después del await
      if (!mapRef.current) {
        console.warn('MapRef se volvió null después de cargar la API de Google Maps');
        return;
      }

      // Coordenadas por defecto (Lima, Perú)
      const defaultCenter = { lat: -12.0464, lng: -77.0428 };

      const mapStyles = resolvedTheme === 'dark' ? mapsDarkStyle : mapsLightStyle;
      const map = new google.maps.Map(mapRef.current, {
        center: defaultCenter,
        zoom: 13,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: false,
        gestureHandling: 'greedy', // Permite mejor control del mapa
        disableDefaultUI: false,
        zoomControl: true,
        mapTypeControl: false,
        scaleControl: false,
        streetViewControl: false,
        rotateControl: false,
        fullscreenControl: true,
        styles: mapStyles
      });

      mapInstanceRef.current = map;
      isInitializedRef.current = true;
      
      directionsServiceRef.current = new google.maps.DirectionsService();
      directionsRendererRef.current = new google.maps.DirectionsRenderer({
        suppressMarkers: true, // No mostrar marcadores de la ruta
        polylineOptions: {
          strokeColor: '#6b7280', // Gris para ruta completa
          strokeWeight: 3,
          strokeOpacity: 0.8
        }
      });

      // Renderer para ruta del conductor
      conductorRouteRendererRef.current = new google.maps.DirectionsRenderer({
        suppressMarkers: true,
        polylineOptions: {
          strokeColor: '#ef4444', // Rojo para ruta del conductor
          strokeWeight: 4,
          strokeOpacity: 0.9
        }
      });

      directionsRendererRef.current.setMap(map);
      conductorRouteRendererRef.current.setMap(map);

      // Agregar listener para clics en el mapa
      if (onLocationSelect) {
        map.addListener('click', async (event: google.maps.MapMouseEvent) => {
          if (event.latLng) {
            const lat = event.latLng.lat();
            const lng = event.latLng.lng();
            
            try {
              const geocoder = new google.maps.Geocoder();
              const response = await geocoder.geocode({ location: { lat, lng } });
              
              if (response.results[0]) {
                const address = response.results[0].formatted_address;
                onLocationSelect(lat, lng, address);
              } else {
                onLocationSelect(lat, lng, `${lat}, ${lng}`);
              }
            } catch (error) {
              console.error('Error en geocodificación:', error);
              onLocationSelect(lat, lng, `${lat}, ${lng}`);
            }
          }
        });
      }

      updateMarkers();
      
    } catch (error) {
      console.error('Error al cargar Google Maps:', error);
      setError('Error al cargar el mapa. Verifica tu conexión a internet.');
    } finally {
      setIsLoading(false);
    }
  };

  const updateMarkers = () => {
    if (!mapInstanceRef.current) return;

    // Limpiar marcadores existentes
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    const bounds = new google.maps.LatLngBounds();
    let hasLocations = false;
    let shouldFitBounds = false;

    // Si tenemos todosLosPuntos, mostrar todos los marcadores de la ruta completa
    if (todosLosPuntos.length > 0) {
      console.log('Creando markers para', todosLosPuntos.length, 'puntos');
      
      todosLosPuntos.forEach((punto, index) => {
        const isOrigen = index === 0;
        const isDestino = index === todosLosPuntos.length - 1;
        const isPuntoIntermedio = !isOrigen && !isDestino;
        
        let iconConfig;
        let title;
        let zIndex = 100; // Z-index base
        
        if (isOrigen) {
          zIndex = 300; // Origen más alto
          if (useCustomPins) {
            // Pins personalizados solo para Solicitar Servicio
            iconConfig = {
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg width="32" height="40" viewBox="0 0 32 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M16 0C7.18 0 0 7.18 0 16c0 8.82 16 24 16 24s16-15.18 16-24C32 7.18 24.82 0 16 0z" fill="#10b981"/>
                  <circle cx="16" cy="16" r="8" fill="white"/>
                  <text x="16" y="20" text-anchor="middle" fill="#10b981" font-size="10" font-weight="bold">O</text>
                </svg>
              `),
              scaledSize: new google.maps.Size(32, 40),
              anchor: new google.maps.Point(16, 40)
            };
          } else {
            // Configuración original para otros mapas
            iconConfig = {
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="20" cy="20" r="16" fill="#10b981" stroke="white" stroke-width="4"/>
                  <circle cx="20" cy="20" r="6" fill="white"/>
                  <text x="20" y="25" text-anchor="middle" fill="#10b981" font-size="8" font-weight="bold">O</text>
                </svg>
              `),
              scaledSize: new google.maps.Size(40, 40),
              anchor: new google.maps.Point(20, 20)
            };
          }
          title = `Origen: ${punto.direccion}`;
        } else if (isDestino) {
          zIndex = 200; // Destino medio
          if (useCustomPins) {
            // Pins personalizados solo para Solicitar Servicio
            iconConfig = {
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg width="32" height="40" viewBox="0 0 32 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M16 0C7.18 0 0 7.18 0 16c0 8.82 16 24 16 24s16-15.18 16-24C32 7.18 24.82 0 16 0z" fill="#ef4444"/>
                  <circle cx="16" cy="16" r="8" fill="white"/>
                  <text x="16" y="20" text-anchor="middle" fill="#ef4444" font-size="10" font-weight="bold">D</text>
                </svg>
              `),
              scaledSize: new google.maps.Size(32, 40),
              anchor: new google.maps.Point(16, 40)
            };
          } else {
            // Configuración original para otros mapas
            iconConfig = {
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="20" cy="20" r="16" fill="#ef4444" stroke="white" stroke-width="4"/>
                  <circle cx="20" cy="20" r="6" fill="white"/>
                  <text x="20" y="25" text-anchor="middle" fill="#ef4444" font-size="8" font-weight="bold">D</text>
                </svg>
              `),
              scaledSize: new google.maps.Size(40, 40),
              anchor: new google.maps.Point(20, 20)
            };
          }
          title = `Destino: ${punto.direccion}`;
        } else {
          zIndex = 250; // Puntos intermedios más altos
          if (useCustomPins) {
            // Pins personalizados solo para Solicitar Servicio
            iconConfig = {
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg width="28" height="36" viewBox="0 0 28 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M14 0C6.27 0 0 6.27 0 14c0 7.73 14 22 14 22s14-14.27 14-22C28 6.27 21.73 0 14 0z" fill="#f59e0b"/>
                  <text x="14" y="18" text-anchor="middle" fill="white" font-size="10" font-weight="bold">${index}</text>
                </svg>
              `),
              scaledSize: new google.maps.Size(28, 36),
              anchor: new google.maps.Point(14, 36)
            };
          } else {
            // Configuración original para otros mapas
            iconConfig = {
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="18" cy="18" r="14" fill="#f59e0b" stroke="white" stroke-width="4"/>
                  <text x="18" y="22" text-anchor="middle" fill="white" font-size="12" font-weight="bold">${index}</text>
                </svg>
              `),
              scaledSize: new google.maps.Size(36, 36),
              anchor: new google.maps.Point(18, 18)
            };
          }
          title = `Punto ${index}: ${punto.direccion}`;
        }
        
        const marker = new google.maps.Marker({
          position: { lat: punto.lat, lng: punto.lng },
          map: mapInstanceRef.current,
          title: title,
          icon: iconConfig,
          zIndex: zIndex,
          draggable: isOrigen || isDestino, // Solo origen y destino son movibles
          cursor: isOrigen || isDestino ? 'grab' : 'default'
        });

        const infoWindow = new google.maps.InfoWindow({
          content: `
            <div class="p-2">
              <h3 class="font-semibold ${isOrigen ? 'text-green-600' : isDestino ? 'text-red-600' : 'text-orange-600'}">${isOrigen ? 'Origen' : isDestino ? 'Destino' : `Punto ${index}`}</h3>
              <p class="text-sm text-gray-600">${punto.direccion}</p>
            </div>
          `
        });

        marker.addListener('click', () => {
          infoWindow.open(mapInstanceRef.current, marker);
        });

        // Agregar listeners de drag para origen y destino
        if (onMarkerDrag && (isOrigen || isDestino)) {
          marker.addListener('dragstart', () => {
            marker.setCursor('grabbing');
          });
          
          marker.addListener('dragend', async (event: google.maps.MapMouseEvent) => {
            marker.setCursor('grab');
            if (event.latLng) {
              const lat = event.latLng.lat();
              const lng = event.latLng.lng();
              
              try {
                const geocoder = new google.maps.Geocoder();
                const response = await geocoder.geocode({ location: { lat, lng } });
                
                let address = `${lat}, ${lng}`;
                if (response.results[0]) {
                  address = response.results[0].formatted_address;
                }
                
                const type = isOrigen ? 'origen' : 'destino';
                onMarkerDrag(type, lat, lng, address);
              } catch (error) {
                console.error(`Error en reverse geocoding del ${isOrigen ? 'origen' : 'destino'}:`, error);
                const type = isOrigen ? 'origen' : 'destino';
                onMarkerDrag(type, lat, lng, `${lat}, ${lng}`);
              }
            }
          });
        }

        markersRef.current.push(marker);
        bounds.extend({ lat: punto.lat, lng: punto.lng });
        hasLocations = true;
        shouldFitBounds = true;
      });
    }

    // Agregar marcador del conductor
    if (conductor) {
      const conductorMarker = new google.maps.Marker({
        position: { lat: conductor.lat, lng: conductor.lng },
        map: mapInstanceRef.current,
        title: `Conductor: ${conductor.nombre}`,
        icon: {
          url: '/ima_movil.png',
          scaledSize: new google.maps.Size(40, 40),
          anchor: new google.maps.Point(20, 20),
          rotation: conductor.angulo || 0
        }
      });

      const conductorInfoWindow = new google.maps.InfoWindow({
        content: `
          <div class="p-2">
            <h3 class="font-semibold text-blue-600">Conductor</h3>
            <p class="text-sm text-gray-600">${conductor.nombre}</p>
          </div>
        `
      });

      conductorMarker.addListener('click', () => {
        conductorInfoWindow.open(mapInstanceRef.current, conductorMarker);
      });

      markersRef.current.push(conductorMarker);
      bounds.extend({ lat: conductor.lat, lng: conductor.lng });
      hasLocations = true;
    }

    // Solo agregar marcadores individuales si no tenemos todosLosPuntos
    if (!todosLosPuntos.length && origen) {
      const origenMarker = new google.maps.Marker({
        position: { lat: origen.lat, lng: origen.lng },
        map: mapInstanceRef.current,
        title: `Origen: ${origen.direccion}`,
        icon: useCustomPins ? {
          // Pin personalizado para Solicitar Servicio
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="32" height="40" viewBox="0 0 32 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M16 0C7.18 0 0 7.18 0 16c0 8.82 16 24 16 24s16-15.18 16-24C32 7.18 24.82 0 16 0z" fill="#10b981"/>
              <circle cx="16" cy="16" r="8" fill="white"/>
              <text x="16" y="20" text-anchor="middle" fill="#10b981" font-size="10" font-weight="bold">O</text>
            </svg>
          `),
          scaledSize: new google.maps.Size(32, 40),
          anchor: new google.maps.Point(16, 40)
        } : {
          // Configuración original para otros mapas
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="16" cy="16" r="12" fill="#10b981" stroke="white" stroke-width="3"/>
              <circle cx="16" cy="16" r="4" fill="white"/>
            </svg>
          `),
          scaledSize: new google.maps.Size(32, 32),
          anchor: new google.maps.Point(16, 16)
        },
        draggable: true, // Hacer el marker movible
        cursor: 'grab'
      });

      const origenInfoWindow = new google.maps.InfoWindow({
        content: `
          <div class="p-2">
            <h3 class="font-semibold text-green-600">Origen</h3>
            <p class="text-sm text-gray-600">${origen.direccion}</p>
            <p class="text-xs text-gray-500 mt-1">Arrastra para mover</p>
          </div>
        `
      });

      origenMarker.addListener('click', () => {
        origenInfoWindow.open(mapInstanceRef.current, origenMarker);
      });

      // Agregar listener para arrastrar el marker
      if (onMarkerDrag) {
        origenMarker.addListener('dragstart', () => {
          origenMarker.setCursor('grabbing');
        });
        
        origenMarker.addListener('dragend', async (event: google.maps.MapMouseEvent) => {
          origenMarker.setCursor('grab');
          if (event.latLng) {
            const lat = event.latLng.lat();
            const lng = event.latLng.lng();
            
            try {
              const geocoder = new google.maps.Geocoder();
              const response = await geocoder.geocode({ location: { lat, lng } });
              
              let address = `${lat}, ${lng}`;
              if (response.results[0]) {
                address = response.results[0].formatted_address;
              }
              
              onMarkerDrag('origen', lat, lng, address);
            } catch (error) {
              console.error('Error en reverse geocoding del origen:', error);
              onMarkerDrag('origen', lat, lng, `${lat}, ${lng}`);
            }
          }
        });
      }

      markersRef.current.push(origenMarker);
      bounds.extend({ lat: origen.lat, lng: origen.lng });
      hasLocations = true;
      shouldFitBounds = true;
    }

    // Solo agregar puntos intermedios si no tenemos todosLosPuntos
    if (!todosLosPuntos.length) {
      puntosIntermedios.forEach((punto, index) => {
        const puntoMarker = new google.maps.Marker({
          position: { lat: punto.lat, lng: punto.lng },
          map: mapInstanceRef.current,
          title: `Punto ${index + 2}: ${punto.direccion}`,
          icon: {
            url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="16" cy="16" r="12" fill="#f59e0b" stroke="white" stroke-width="3"/>
                <text x="16" y="20" text-anchor="middle" fill="white" font-size="10" font-weight="bold">${index + 2}</text>
              </svg>
            `),
            scaledSize: new google.maps.Size(32, 32),
            anchor: new google.maps.Point(16, 16)
          }
        });

        const puntoInfoWindow = new google.maps.InfoWindow({
          content: `
            <div class="p-2">
              <h3 class="font-semibold text-orange-600">Punto ${index + 2}</h3>
              <p class="text-sm text-gray-600">${punto.direccion}</p>
            </div>
          `
        });

        puntoMarker.addListener('click', () => {
          puntoInfoWindow.open(mapInstanceRef.current, puntoMarker);
        });

        markersRef.current.push(puntoMarker);
        bounds.extend({ lat: punto.lat, lng: punto.lng });
        hasLocations = true;
        shouldFitBounds = true;
      });
    }

        // Solo agregar destino si no tenemos todosLosPuntos
    if (!todosLosPuntos.length && destino) {
      const destinoMarker = new google.maps.Marker({
        position: { lat: destino.lat, lng: destino.lng },
        map: mapInstanceRef.current,
        title: `Destino: ${destino.direccion}`,
        icon: useCustomPins ? {
          // Pin personalizado para Solicitar Servicio
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="32" height="40" viewBox="0 0 32 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M16 0C7.18 0 0 7.18 0 16c0 8.82 16 24 16 24s16-15.18 16-24C32 7.18 24.82 0 16 0z" fill="#ef4444"/>
              <circle cx="16" cy="16" r="8" fill="white"/>
              <text x="16" y="20" text-anchor="middle" fill="#ef4444" font-size="10" font-weight="bold">D</text>
            </svg>
          `),
          scaledSize: new google.maps.Size(32, 40),
          anchor: new google.maps.Point(16, 40)
        } : {
          // Configuración original para otros mapas
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="16" cy="16" r="12" fill="#ef4444" stroke="white" stroke-width="3"/>
              <circle cx="16" cy="16" r="4" fill="white"/>
            </svg>
          `),
          scaledSize: new google.maps.Size(32, 32),
          anchor: new google.maps.Point(16, 16)
        },
        draggable: true, // Hacer el marker movible
        cursor: 'grab'
      });

      const destinoInfoWindow = new google.maps.InfoWindow({
        content: `
          <div class="p-2">
            <h3 class="font-semibold text-red-600">Destino</h3>
            <p class="text-sm text-gray-600">${destino.direccion}</p>
            <p class="text-xs text-gray-500 mt-1">Arrastra para mover</p>
          </div>
        `
      });

      destinoMarker.addListener('click', () => {
        destinoInfoWindow.open(mapInstanceRef.current, destinoMarker);
      });

      // Agregar listener para arrastrar el marker
      if (onMarkerDrag) {
        destinoMarker.addListener('dragend', async (event: google.maps.MapMouseEvent) => {
          if (event.latLng) {
            const lat = event.latLng.lat();
            const lng = event.latLng.lng();
            
            try {
              const geocoder = new google.maps.Geocoder();
              const response = await geocoder.geocode({ location: { lat, lng } });
              
              let address = `${lat}, ${lng}`;
              if (response.results[0]) {
                address = response.results[0].formatted_address;
              }
              
              onMarkerDrag('destino', lat, lng, address);
            } catch (error) {
              console.error('Error en reverse geocoding del destino:', error);
              onMarkerDrag('destino', lat, lng, `${lat}, ${lng}`);
            }
          }
        });
      }

      markersRef.current.push(destinoMarker);
      bounds.extend({ lat: destino.lat, lng: destino.lng });
      hasLocations = true;
      shouldFitBounds = true;
    }

    // Ajustar vista del mapa
    if (hasLocations && shouldFitBounds) {
      if (todosLosPuntos.length > 1 || (origen && destino)) {
        // Usar padding más generoso para mejor visualización
        mapInstanceRef.current.fitBounds(bounds, { 
          padding: { top: 80, right: 80, bottom: 80, left: 80 }
        });
        
        // Si todos los puntos están muy cerca, hacer zoom out un poco
        setTimeout(() => {
          if (mapInstanceRef.current) {
            const currentZoom = mapInstanceRef.current.getZoom();
            if (currentZoom && currentZoom > 16) {
              mapInstanceRef.current.setZoom(Math.min(currentZoom, 15));
            }
          }
        }, 500);
      } else {
        const centerPoint = origen || destino || todosLosPuntos[0];
        if (centerPoint) {
          mapInstanceRef.current.setCenter(centerPoint);
          mapInstanceRef.current.setZoom(15);
        }
      }
    }

    // Calcular y mostrar ruta si tenemos origen y destino
    if (origen && destino && !mostrarRutaCompleta) {
      calculateRoute();
    }
  };

  const drawConductorRoute = () => {
    if (rutaConductor.length < 2) return;

    // Limpiar polilínea anterior
    if (polylineRef.current) {
      polylineRef.current.setMap(null);
    }

    // Crear nueva polilínea para la ruta del conductor
    const path = rutaConductor.map(point => ({ lat: point.lat, lng: point.lng }));
    
    polylineRef.current = new google.maps.Polyline({
      path: path,
      geodesic: true,
      strokeColor: '#ef4444', // Rojo
      strokeOpacity: 0.9,
      strokeWeight: 4,
      map: mapInstanceRef.current
    });
  };

  const drawGPSRoute = () => {
    if (!rutaGPS || rutaGPS.length < 2) {
      console.log('No hay suficientes puntos GPS para dibujar ruta:', rutaGPS?.length || 0);
      return;
    }

    console.log('Dibujando ruta GPS con', rutaGPS.length, 'puntos');

    // Limpiar polilínea anterior
    if (gpsRoutePolylineRef.current) {
      gpsRoutePolylineRef.current.setMap(null);
    }

    // Crear nueva polilínea para la ruta GPS real
    const path = rutaGPS.map(point => ({ lat: point.lat, lng: point.lng }));
    
    gpsRoutePolylineRef.current = new google.maps.Polyline({
      path: path,
      geodesic: true,
      strokeColor: '#10b981', // Verde para ruta completada
      strokeOpacity: 0.9,
      strokeWeight: 5,
      map: mapInstanceRef.current
    });

    console.log('Ruta GPS dibujada exitosamente');
  };

  const calculateRoute = async () => {
    if (!origen || !destino || !directionsServiceRef.current || !directionsRendererRef.current) {
      return;
    }

    try {
      const request: google.maps.DirectionsRequest = {
        origin: { lat: origen.lat, lng: origen.lng },
        destination: { lat: destino.lat, lng: destino.lng },
        travelMode: google.maps.TravelMode.DRIVING,
        unitSystem: google.maps.UnitSystem.METRIC,
        avoidHighways: false,
        avoidTolls: false
      };

      const response = await directionsServiceRef.current.route(request);
      directionsRendererRef.current.setDirections(response);

      // Obtener información de la ruta
      const route = response.routes[0];
      if (route) {
        const leg = route.legs[0];
        console.log('Distancia:', leg.distance?.text);
        console.log('Tiempo:', leg.duration?.text);
      }

    } catch (error) {
      console.error('Error al calcular ruta:', error);
    }
  };

  if (error) {
    return (
      <div 
        className={`flex items-center justify-center bg-gray-100 dark:bg-gray-700 rounded-xl h-full ${className}`}
      >
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-2" />
          <p className="text-red-600 dark:text-red-400 mb-2">{error}</p>
          <button
            onClick={initializeMap}
            className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200"
          >
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative rounded-xl overflow-hidden h-full ${className}`}>
      {isLoading && (
        <div className="absolute inset-0 bg-gray-100 dark:bg-gray-700 flex items-center justify-center z-10">
          <div className="text-center">
            <Loader2 className="w-8 h-8 animate-spin text-primary-600 mx-auto mb-2" />
            <p className="text-gray-600 dark:text-gray-400">Cargando mapa...</p>
          </div>
        </div>
      )}
      <div
        ref={mapRef}
        className="w-full h-full min-h-full"
      />
    </div>
  );
};