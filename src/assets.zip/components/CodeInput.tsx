import React, { useState, useRef, useEffect } from 'react';

interface CodeInputProps {
  length: number;
  onComplete: (code: string) => void;
  disabled?: boolean;
}

/**
 * Componente para entrada de código de verificación
 * Muestra 6 cajas individuales para cada dígito del código
 */
export const CodeInput: React.FC<CodeInputProps> = ({ 
  length, 
  onComplete, 
  disabled = false 
}) => {
  const [code, setCode] = useState<string[]>(new Array(length).fill(''));
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (inputRefs.current[0] && !disabled) {
      inputRefs.current[0].focus();
    }
  }, [disabled]);

  const handleChange = (value: string, index: number) => {
    if (disabled) return;
    
    const newCode = [...code];
    newCode[index] = value.slice(-1); // Solo tomar el último carácter
    setCode(newCode);

    // Mover al siguiente campo si hay un valor
    if (value && index < length - 1) {
      setActiveIndex(index + 1);
      inputRefs.current[index + 1]?.focus();
    }

    // Verificar si el código está completo
    const completeCode = newCode.join('');
    if (completeCode.length === length) {
      onComplete(completeCode);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent, index: number) => {
    if (disabled) return;

    if (e.key === 'Backspace') {
      if (!code[index] && index > 0) {
        // Si el campo actual está vacío, ir al anterior
        setActiveIndex(index - 1);
        inputRefs.current[index - 1]?.focus();
      } else {
        // Limpiar el campo actual
        const newCode = [...code];
        newCode[index] = '';
        setCode(newCode);
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      setActiveIndex(index - 1);
      inputRefs.current[index - 1]?.focus();
    } else if (e.key === 'ArrowRight' && index < length - 1) {
      setActiveIndex(index + 1);
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleFocus = (index: number) => {
    setActiveIndex(index);
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, length);
    
    if (pastedData) {
      const newCode = [...code];
      for (let i = 0; i < pastedData.length && i < length; i++) {
        newCode[i] = pastedData[i];
      }
      setCode(newCode);
      
      // Enfocar el siguiente campo disponible o el último
      const nextIndex = Math.min(pastedData.length, length - 1);
      setActiveIndex(nextIndex);
      inputRefs.current[nextIndex]?.focus();
      
      // Verificar si el código está completo
      const completeCode = newCode.join('');
      if (completeCode.length === length) {
        onComplete(completeCode);
      }
    }
  };

  return (
    <div className="flex justify-center space-x-3">
      {Array.from({ length }, (_, index) => (
        <div key={index} className="relative">
          <input
            ref={(el) => (inputRefs.current[index] = el)}
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
            maxLength={1}
            value={code[index]}
            onChange={(e) => handleChange(e.target.value, index)}
            onKeyDown={(e) => handleKeyDown(e, index)}
            onFocus={() => handleFocus(index)}
            onPaste={handlePaste}
            disabled={disabled}
            className={`
              w-12 h-14 text-center text-xl font-semibold rounded-xl
              bg-white/10 backdrop-blur-sm border-2 text-white
              focus:outline-none transition-all duration-200
              ${activeIndex === index 
                ? 'border-orange-400 bg-white/20' 
                : code[index] 
                  ? 'border-white/40 bg-white/15' 
                  : 'border-white/20'
              }
              ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-white/40'}
            `}
            autoComplete="one-time-code"
          />
        </div>
      ))}
    </div>
  );
};