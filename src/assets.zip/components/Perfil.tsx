import React, { useState, useEffect } from 'react';
import { 
  User, ArrowLeft, Loader2, AlertCircle, Mail, Phone, Building, 
  Shield, UserCheck, CreditCard, Eye, EyeOff, Lock, Save, X
} from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';
import { Toast } from './Toast';
import { obtenerPerfil } from '../services/perfilService';
import { recuperarPassword, actualizarPassword, cambiarContrasena, limpiarSesion, obtenerSesion } from '../services/authService';
import { PerfilResponse, ActualizarPasswordData } from '../types/perfil';

interface PerfilProps {
  onVolver: () => void;
}

/**
 * Componente Perfil - Muestra información del usuario y permite cambiar contraseña
 */
export const Perfil: React.FC<PerfilProps> = ({ onVolver }) => {
  const [perfilData, setPerfilData] = useState<PerfilResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [mostrarModalPassword, setMostrarModalPassword] = useState(false);
  const [mostrarModalDirectPassword, setMostrarModalDirectPassword] = useState(false);
  const [isLoadingPassword, setIsLoadingPassword] = useState(false);
  const [pasoPassword, setPasoPassword] = useState<'solicitar' | 'verificar'>('solicitar');
  const [idPersonalRecuperacion, setIdPersonalRecuperacion] = useState<number | null>(null);
  const [showPasswords, setShowPasswords] = useState({
    nueva: false,
    confirmar: false,
    actual: false
  });

  const [passwordData, setPasswordData] = useState<ActualizarPasswordData>({
    codigoVerificacion: '',
    nuevaPassword: '',
    confirmarPassword: ''
  });

  // Estado para cambio directo de contraseña
  const [directPasswordData, setDirectPasswordData] = useState({
    nuevaPassword: '',
    confirmarPassword: ''
  });

  const [passwordErrors, setPasswordErrors] = useState<{
    codigoVerificacion?: string;
    nuevaPassword?: string;
    confirmarPassword?: string;
    general?: string;
  }>({});

  const [toast, setToast] = useState<{
    isVisible: boolean;
    message: string;
    type: 'success' | 'error';
  }>({
    isVisible: false,
    message: '',
    type: 'success'
  });

  useEffect(() => {
    cargarPerfil();
  }, []);

  const cargarPerfil = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await obtenerPerfil();
      setPerfilData(data);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error desconocido');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePasswordChange = (field: keyof ActualizarPasswordData, value: string) => {
    setPasswordData(prev => ({ ...prev, [field]: value }));
    if (passwordErrors[field]) {
      setPasswordErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const togglePasswordVisibility = (field: 'actual' | 'nueva' | 'confirmar') => {
    setShowPasswords(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const validatePasswordForm = (): boolean => {
    const newErrors: typeof passwordErrors = {};

    if (pasoPassword === 'verificar') {
      if (!passwordData.codigoVerificacion.trim()) {
        newErrors.codigoVerificacion = 'El código es requerido';
      } else if (passwordData.codigoVerificacion.length !== 6) {
        newErrors.codigoVerificacion = 'El código debe tener 6 dígitos';
      }
    }

    if (!passwordData.nuevaPassword.trim()) {
      newErrors.nuevaPassword = 'La nueva contraseña es requerida';
    } else if (passwordData.nuevaPassword.length < 6) {
      newErrors.nuevaPassword = 'La contraseña debe tener al menos 6 caracteres';
    }

    if (!passwordData.confirmarPassword.trim()) {
      newErrors.confirmarPassword = 'Confirma la nueva contraseña';
    } else if (passwordData.nuevaPassword !== passwordData.confirmarPassword) {
      newErrors.confirmarPassword = 'Las contraseñas no coinciden';
    }

    setPasswordErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSolicitarCodigo = async () => {
    if (!perfilData) return;

    setIsLoadingPassword(true);
    setPasswordErrors({});

    try {
      // Usar API /Accesoemailrecupera
      const response = await recuperarPassword(perfilData.operfilu.email);
      
      if (response.estatus === 200) {
        setIdPersonalRecuperacion(response.idpersonal);
        setPasoPassword('verificar');
        setToast({
          isVisible: true,
          message: 'Código de verificación enviado a tu correo',
          type: 'success'
        });
      } else {
        setPasswordErrors({ 
          general: response.message || 'Error al enviar código de verificación' 
        });
      }
    } catch (error) {
      setPasswordErrors({ 
        general: error instanceof Error ? error.message : 'Error de conexión' 
      });
    } finally {
      setIsLoadingPassword(false);
    }
  };

  const handleActualizarPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validatePasswordForm() || !idPersonalRecuperacion) return;

    setIsLoadingPassword(true);
    setPasswordErrors({});

    try {
      // Usar API /Contrasenaa
      const response = await actualizarPassword(
        idPersonalRecuperacion,
        passwordData.codigoVerificacion,
        passwordData.nuevaPassword
      );

      if (response.estatus === 200) {
        setToast({
          isVisible: true,
          message: 'Contraseña actualizada exitosamente. Cerrando sesión...',
          type: 'success'
        });

        // Cerrar modal
        setMostrarModalPassword(false);

        // Cerrar sesión después de 2 segundos
        setTimeout(() => {
          limpiarSesion();
          window.location.reload();
        }, 2000);
      } else {
        setPasswordErrors({ 
          general: response.message || 'Error al actualizar contraseña' 
        });
      }
    } catch (error) {
      setPasswordErrors({ 
        general: error instanceof Error ? error.message : 'Error de conexión' 
      });
    } finally {
      setIsLoadingPassword(false);
    }
  };

  const resetPasswordForm = () => {
    setPasoPassword('solicitar');
    setIdPersonalRecuperacion(null);
    setPasswordData({
      codigoVerificacion: '',
      nuevaPassword: '',
      confirmarPassword: ''
    });
    setPasswordErrors({});
    setShowPasswords({
      nueva: false,
      confirmar: false,
      actual: false
    });
  };

  const handleDirectPasswordChange = (field: 'nuevaPassword' | 'confirmarPassword', value: string) => {
    setDirectPasswordData(prev => ({ ...prev, [field]: value }));
    if (passwordErrors[field]) {
      setPasswordErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const validateDirectPasswordForm = (): boolean => {
    const newErrors: typeof passwordErrors = {};

    if (!directPasswordData.nuevaPassword.trim()) {
      newErrors.nuevaPassword = 'La nueva contraseña es requerida';
    } else if (directPasswordData.nuevaPassword.length < 6) {
      newErrors.nuevaPassword = 'La contraseña debe tener al menos 6 caracteres';
    }

    if (!directPasswordData.confirmarPassword.trim()) {
      newErrors.confirmarPassword = 'Confirma la nueva contraseña';
    } else if (directPasswordData.nuevaPassword !== directPasswordData.confirmarPassword) {
      newErrors.confirmarPassword = 'Las contraseñas no coinciden';
    }

    setPasswordErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleCambiarContrasenaDirecta = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateDirectPasswordForm()) return;

    const session = obtenerSesion();
    if (!session || !session.idpersonal) {
      setPasswordErrors({ general: 'Sesión no válida' });
      return;
    }

    setIsLoadingPassword(true);
    setPasswordErrors({});

    try {
      const response = await cambiarContrasena(
        session.idpersonal,
        directPasswordData.nuevaPassword
      );

      if (response.estatus === 200) {
        setToast({
          isVisible: true,
          message: 'Contraseña actualizada exitosamente. Cerrando sesión...',
          type: 'success'
        });

        // Cerrar modal
        setMostrarModalDirectPassword(false);

        // Cerrar sesión después de 2 segundos
        setTimeout(() => {
          limpiarSesion();
          window.location.reload();
        }, 2000);
      } else {
        setPasswordErrors({ 
          general: response.message || 'Error al actualizar contraseña' 
        });
      }
    } catch (error) {
      setPasswordErrors({ 
        general: error instanceof Error ? error.message : 'Error de conexión' 
      });
    } finally {
      setIsLoadingPassword(false);
    }
  };

  const resetDirectPasswordForm = () => {
    setDirectPasswordData({
      nuevaPassword: '',
      confirmarPassword: ''
    });
    setPasswordErrors({});
    setShowPasswords({
      nueva: false,
      confirmar: false,
      actual: false
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Cargando perfil...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            Error al cargar perfil
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-4">{error}</p>
          <button
            onClick={cargarPerfil}
            className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200"
          >
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  if (!perfilData) return null;

  const { operfilu } = perfilData;

  return (
    <>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        {/* Header */}
        <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center">
                <button
                  onClick={onVolver}
                  className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors duration-200"
                >
                  <ArrowLeft className="w-5 h-5 mr-2" />
                  Volver
                </button>
                <h1 className="ml-4 text-xl font-bold text-gray-900 dark:text-white flex items-center">
                  <User className="w-6 h-6 mr-2" />
                  Mi Perfil
                </h1>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => {
                    resetDirectPasswordForm();
                    setMostrarModalDirectPassword(true);
                  }}
                  className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
                >
                  <Lock className="w-4 h-4 mr-2" />
                  Cambiar Contraseña
                </button>
                <ThemeToggle />
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Información del Usuario */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            
            {/* Header del Perfil */}
            <div className="bg-gradient-to-r from-gray-800 to-gray-900 dark:from-gray-700 dark:to-gray-800 px-8 py-12">
              <div className="flex items-center space-x-6">
                <img
                  src={operfilu.foto}
                  alt="Foto de perfil"
                  className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
                />
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">
                    {operfilu.nombres} {operfilu.apellidos}
                  </h2>
                  <p className="text-white/90 text-lg mb-3">
                    {operfilu.nombrecomercial}
                  </p>
                  
                  {/* Badges de Permisos */}
                  <div className="flex flex-wrap gap-2">
                    {operfilu.administrador && (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-white/20 text-white backdrop-blur-sm">
                        <Shield className="w-3 h-3 mr-1" />
                        Administrador
                      </span>
                    )}
                    {operfilu.jefe && (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-white/20 text-white backdrop-blur-sm">
                        <UserCheck className="w-3 h-3 mr-1" />
                        Jefe
                      </span>
                    )}
                    {operfilu.validador && (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-white/20 text-white backdrop-blur-sm">
                        <UserCheck className="w-3 h-3 mr-1" />
                        Validador
                      </span>
                    )}
                    {operfilu.verificador && (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-white/20 text-white backdrop-blur-sm">
                        <Shield className="w-3 h-3 mr-1" />
                        Verificador
                      </span>
                    )}
                    {operfilu.credito && (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-white/20 text-white backdrop-blur-sm">
                        <CreditCard className="w-3 h-3 mr-1" />
                        Crédito Corporativo
                      </span>
                    )}
                    {!operfilu.administrador && !operfilu.jefe && !operfilu.validador && !operfilu.verificador && !operfilu.credito && (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-white/20 text-white backdrop-blur-sm">
                        <User className="w-3 h-3 mr-1" />
                        Usuario
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Información Detallada */}
            <div className="p-8">
              <div className="grid md:grid-cols-2 gap-8">
                
                {/* Información Personal */}
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    Información Personal
                  </h3>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300">Tipo de Documento</span>
                      <span className="text-gray-900 dark:text-white font-semibold">
                        {operfilu.tipodocumento}
                      </span>
                    </div>

                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300">Número de Documento</span>
                      <span className="text-gray-900 dark:text-white font-semibold">
                        {operfilu.ndocumento && operfilu.ndocumento !== '0' ? operfilu.ndocumento : 'No registrado'}
                      </span>
                    </div>

                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300 flex items-center">
                        <Phone className="w-4 h-4 mr-2" />
                        Teléfono
                      </span>
                      <span className="text-gray-900 dark:text-white font-semibold">
                        {operfilu.telefono}
                      </span>
                    </div>

                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300 flex items-center">
                        <Mail className="w-4 h-4 mr-2" />
                        Email
                      </span>
                      <span className="text-gray-900 dark:text-white font-semibold">
                        {operfilu.email}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Información Organizacional */}
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    Información Organizacional
                  </h3>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300">Jefe Directo</span>
                      <span className="text-gray-900 dark:text-white font-semibold">
                        {operfilu.datjefe || 'No asignado'}
                      </span>
                    </div>

                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300 flex items-center">
                        <Building className="w-4 h-4 mr-2" />
                        Área
                      </span>
                      <span className="text-gray-900 dark:text-white font-semibold">
                        {operfilu.area && operfilu.area !== '0' ? operfilu.area : 'No asignada'}
                      </span>
                    </div>

                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300">Centro de Costos</span>
                      <span className="text-gray-900 dark:text-white font-semibold">
                        {operfilu.centrocostos && operfilu.centrocostos !== '0' ? operfilu.centrocostos : 'No asignado'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Sección de Permisos */}
              <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-600">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Permisos y Accesos
                </h3>
                
                                  <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className={`p-4 rounded-lg border-2 ${
                      operfilu.administrador 
                        ? 'border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20' 
                        : 'border-gray-200 bg-gray-50 dark:border-gray-600 dark:bg-gray-700'
                    }`}>
                      <div className="flex items-center justify-center mb-2">
                        <Shield className={`w-8 h-8 ${
                          operfilu.administrador ? 'text-red-600 dark:text-red-400' : 'text-gray-400'
                        }`} />
                      </div>
                      <p className="text-center text-sm font-medium text-gray-900 dark:text-white">
                        Administrador
                      </p>
                      <p className="text-center text-xs text-gray-600 dark:text-gray-400 mt-1">
                        {operfilu.administrador ? 'Activo' : 'Inactivo'}
                      </p>
                    </div>

                    <div className={`p-4 rounded-lg border-2 ${
                      operfilu.jefe 
                        ? 'border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-900/20' 
                        : 'border-gray-200 bg-gray-50 dark:border-gray-600 dark:bg-gray-700'
                    }`}>
                      <div className="flex items-center justify-center mb-2">
                        <UserCheck className={`w-8 h-8 ${
                          operfilu.jefe ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400'
                        }`} />
                      </div>
                      <p className="text-center text-sm font-medium text-gray-900 dark:text-white">
                        Jefe
                      </p>
                      <p className="text-center text-xs text-gray-600 dark:text-gray-400 mt-1">
                        {operfilu.jefe ? 'Activo' : 'Inactivo'}
                      </p>
                    </div>

                    <div className={`p-4 rounded-lg border-2 ${
                      operfilu.validador 
                        ? 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20' 
                        : 'border-gray-200 bg-gray-50 dark:border-gray-600 dark:bg-gray-700'
                    }`}>
                      <div className="flex items-center justify-center mb-2">
                        <UserCheck className={`w-8 h-8 ${
                          operfilu.validador ? 'text-green-600 dark:text-green-400' : 'text-gray-400'
                        }`} />
                      </div>
                      <p className="text-center text-sm font-medium text-gray-900 dark:text-white">
                        Validador
                      </p>
                      <p className="text-center text-xs text-gray-600 dark:text-gray-400 mt-1">
                        {operfilu.validador ? 'Activo' : 'Inactivo'}
                      </p>
                    </div>

                    <div className={`p-4 rounded-lg border-2 ${
                      operfilu.verificador 
                        ? 'border-teal-200 bg-teal-50 dark:border-teal-800 dark:bg-teal-900/20' 
                        : 'border-gray-200 bg-gray-50 dark:border-gray-600 dark:bg-gray-700'
                    }`}>
                      <div className="flex items-center justify-center mb-2">
                        <Shield className={`w-8 h-8 ${
                          operfilu.verificador ? 'text-teal-600 dark:text-teal-400' : 'text-gray-400'
                        }`} />
                      </div>
                      <p className="text-center text-sm font-medium text-gray-900 dark:text-white">
                        Verificador
                      </p>
                      <p className="text-center text-xs text-gray-600 dark:text-gray-400 mt-1">
                        {operfilu.verificador ? 'Activo' : 'Inactivo'}
                      </p>
                    </div>

                    <div className={`p-4 rounded-lg border-2 ${
                      operfilu.credito 
                        ? 'border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-900/20' 
                        : 'border-gray-200 bg-gray-50 dark:border-gray-600 dark:bg-gray-700'
                    }`}>
                      <div className="flex items-center justify-center mb-2">
                        <CreditCard className={`w-8 h-8 ${
                          operfilu.credito ? 'text-yellow-600 dark:text-yellow-400' : 'text-gray-400'
                        }`} />
                      </div>
                      <p className="text-center text-sm font-medium text-gray-900 dark:text-white">
                        Crédito
                      </p>
                      <p className="text-center text-xs text-gray-600 dark:text-gray-400 mt-1">
                        {operfilu.credito ? 'Habilitado' : 'Deshabilitado'}
                      </p>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal para Cambiar Contraseña */}
      {mostrarModalPassword && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            {/* Overlay */}
            <div 
              className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
              onClick={() => !isLoadingPassword && setMostrarModalPassword(false)}
            />

            {/* Modal */}
            <div className="inline-block w-full max-w-md p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white dark:bg-gray-800 shadow-xl rounded-2xl">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Cambiar Contraseña
                </h3>
                <button
                  onClick={() => !isLoadingPassword && setMostrarModalPassword(false)}
                  disabled={isLoadingPassword}
                  className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors duration-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-50"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Error General */}
              {passwordErrors.general && (
                <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                  <p className="text-sm text-red-700 dark:text-red-300">{passwordErrors.general}</p>
                </div>
              )}

              {pasoPassword === 'solicitar' ? (
                /* Paso 1: Solicitar código */
                <div className="space-y-6">
                  <div className="text-center">
                    <Mail className="w-16 h-16 text-primary-600 mx-auto mb-4" />
                    <p className="text-gray-600 dark:text-gray-400 mb-2">
                      Se enviará un código de verificación a:
                    </p>
                    <p className="text-lg font-semibold text-gray-900 dark:text-white">
                      {perfilData.operfilu.email}
                    </p>
                  </div>

                  <div className="flex justify-end space-x-3">
                    <button
                      type="button"
                      onClick={() => !isLoadingPassword && setMostrarModalPassword(false)}
                      disabled={isLoadingPassword}
                      className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200 disabled:opacity-50"
                    >
                      Cancelar
                    </button>
                    <button
                      type="button"
                      onClick={handleSolicitarCodigo}
                      disabled={isLoadingPassword}
                      className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200 disabled:opacity-50 flex items-center"
                    >
                      {isLoadingPassword ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Mail className="w-4 h-4 mr-2" />
                      )}
                      Enviar Código
                    </button>
                  </div>
                </div>
              ) : (
                /* Paso 2: Verificar código y cambiar contraseña */
                <form onSubmit={handleActualizarPassword} className="space-y-4">
                  {/* Código de Verificación */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Código de Verificación *
                    </label>
                    <input
                      type="text"
                      value={passwordData.codigoVerificacion}
                      onChange={(e) => handlePasswordChange('codigoVerificacion', e.target.value.replace(/\D/g, ''))}
                      maxLength={6}
                      className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-all duration-200 text-center font-mono text-lg ${
                        passwordErrors.codigoVerificacion 
                          ? 'border-red-300 dark:border-red-600' 
                          : 'border-gray-300 dark:border-gray-600'
                      }`}
                      placeholder="123456"
                      autoComplete="off"
                    />
                    {passwordErrors.codigoVerificacion && (
                      <p className="text-sm text-red-600 dark:text-red-400 mt-1">{passwordErrors.codigoVerificacion}</p>
                    )}
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      Código enviado a: {perfilData.operfilu.email}
                    </p>
                  </div>

                  {/* Nueva Contraseña */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Nueva Contraseña *
                    </label>
                    <div className="relative">
                      <input
                        type={showPasswords.nueva ? 'text' : 'password'}
                        value={passwordData.nuevaPassword}
                        onChange={(e) => handlePasswordChange('nuevaPassword', e.target.value)}
                        className={`w-full pl-4 pr-12 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-all duration-200 ${
                          passwordErrors.nuevaPassword 
                            ? 'border-red-300 dark:border-red-600' 
                            : 'border-gray-300 dark:border-gray-600'
                        }`}
                        placeholder="Mínimo 6 caracteres"
                      />
                      <button
                        type="button"
                        onClick={() => togglePasswordVisibility('nueva')}
                        className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                      >
                        {showPasswords.nueva ? (
                          <EyeOff className="h-5 w-5" />
                        ) : (
                          <Eye className="h-5 w-5" />
                        )}
                      </button>
                    </div>
                    {passwordErrors.nuevaPassword && (
                      <p className="text-sm text-red-600 dark:text-red-400 mt-1">{passwordErrors.nuevaPassword}</p>
                    )}
                  </div>

                  {/* Confirmar Contraseña */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Confirmar Nueva Contraseña *
                    </label>
                    <div className="relative">
                      <input
                        type={showPasswords.confirmar ? 'text' : 'password'}
                        value={passwordData.confirmarPassword}
                        onChange={(e) => handlePasswordChange('confirmarPassword', e.target.value)}
                        className={`w-full pl-4 pr-12 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-all duration-200 ${
                          passwordErrors.confirmarPassword 
                            ? 'border-red-300 dark:border-red-600' 
                            : 'border-gray-300 dark:border-gray-600'
                        }`}
                        placeholder="Confirma la nueva contraseña"
                      />
                      <button
                        type="button"
                        onClick={() => togglePasswordVisibility('confirmar')}
                        className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                      >
                        {showPasswords.confirmar ? (
                          <EyeOff className="h-5 w-5" />
                        ) : (
                          <Eye className="h-5 w-5" />
                        )}
                      </button>
                    </div>
                    {passwordErrors.confirmarPassword && (
                      <p className="text-sm text-red-600 dark:text-red-400 mt-1">{passwordErrors.confirmarPassword}</p>
                    )}
                  </div>

                  {/* Botones */}
                  <div className="flex justify-end space-x-3 pt-4">
                    <button
                      type="button"
                      onClick={() => !isLoadingPassword && setMostrarModalPassword(false)}
                      disabled={isLoadingPassword}
                      className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200 disabled:opacity-50"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      disabled={isLoadingPassword}
                      className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200 disabled:opacity-50 flex items-center"
                    >
                      {isLoadingPassword ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Save className="w-4 h-4 mr-2" />
                      )}
                      Actualizar Contraseña
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal para Cambio Directo de Contraseña */}
      {mostrarModalDirectPassword && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            {/* Overlay */}
            <div 
              className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
              onClick={() => !isLoadingPassword && setMostrarModalDirectPassword(false)}
            />

            {/* Modal */}
            <div className="inline-block w-full max-w-md p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white dark:bg-gray-800 shadow-xl rounded-2xl">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Cambiar Contraseña
                </h3>
                <button
                  onClick={() => !isLoadingPassword && setMostrarModalDirectPassword(false)}
                  disabled={isLoadingPassword}
                  className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors duration-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-50"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Error General */}
              {passwordErrors.general && (
                <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                  <p className="text-sm text-red-700 dark:text-red-300">{passwordErrors.general}</p>
                </div>
              )}

              <form onSubmit={handleCambiarContrasenaDirecta} className="space-y-4">
                {/* Nueva Contraseña */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Nueva Contraseña *
                  </label>
                  <div className="relative">
                    <input
                      type={showPasswords.nueva ? 'text' : 'password'}
                      value={directPasswordData.nuevaPassword}
                      onChange={(e) => handleDirectPasswordChange('nuevaPassword', e.target.value)}
                      className={`w-full pl-4 pr-12 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-all duration-200 ${
                        passwordErrors.nuevaPassword 
                          ? 'border-red-300 dark:border-red-600' 
                          : 'border-gray-300 dark:border-gray-600'
                      }`}
                      placeholder="Mínimo 6 caracteres"
                    />
                    <button
                      type="button"
                      onClick={() => togglePasswordVisibility('nueva')}
                      className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      {showPasswords.nueva ? (
                        <EyeOff className="h-5 w-5" />
                      ) : (
                        <Eye className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                  {passwordErrors.nuevaPassword && (
                    <p className="text-sm text-red-600 dark:text-red-400 mt-1">{passwordErrors.nuevaPassword}</p>
                  )}
                </div>

                {/* Confirmar Contraseña */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Confirmar Nueva Contraseña *
                  </label>
                  <div className="relative">
                    <input
                      type={showPasswords.confirmar ? 'text' : 'password'}
                      value={directPasswordData.confirmarPassword}
                      onChange={(e) => handleDirectPasswordChange('confirmarPassword', e.target.value)}
                      className={`w-full pl-4 pr-12 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-all duration-200 ${
                        passwordErrors.confirmarPassword 
                          ? 'border-red-300 dark:border-red-600' 
                          : 'border-gray-300 dark:border-gray-600'
                      }`}
                      placeholder="Confirma la nueva contraseña"
                    />
                    <button
                      type="button"
                      onClick={() => togglePasswordVisibility('confirmar')}
                      className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      {showPasswords.confirmar ? (
                        <EyeOff className="h-5 w-5" />
                      ) : (
                        <Eye className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                  {passwordErrors.confirmarPassword && (
                    <p className="text-sm text-red-600 dark:text-red-400 mt-1">{passwordErrors.confirmarPassword}</p>
                  )}
                </div>

                {/* Botones */}
                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => !isLoadingPassword && setMostrarModalDirectPassword(false)}
                    disabled={isLoadingPassword}
                    className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200 disabled:opacity-50"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={isLoadingPassword}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200 disabled:opacity-50 flex items-center"
                  >
                    {isLoadingPassword ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4 mr-2" />
                    )}
                    Actualizar Contraseña
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Toast de Notificación */}
      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={() => setToast(prev => ({ ...prev, isVisible: false }))}
      />
    </>
  );
};