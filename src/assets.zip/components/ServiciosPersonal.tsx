import React, { useState, useEffect } from 'react';
import { 
  Users, Download, Loader2, AlertCircle, ArrowLeft,
  RefreshCw, MapPin, X, Trash2, MessageCircle, FileText
} from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';
import { Vale } from './Vale';
import { Tracking } from './Tracking';
import { Toast } from './Toast';
import { obtenerSolicitudesPersonal, exportarSolicitudesXLS, obtenerMotivosCancelacion } from '../services/serviciosPersonalService';
import { SolicitudPersonal, FiltrosSolicitudes } from '../types/serviciosPersonal';

interface ServiciosPersonalProps {
  onVolver: () => void;
}

/**
 * Componente para gestión de servicios del personal
 * Permite consultar, filtrar, exportar y gestionar servicios
 */
export const ServiciosPersonal: React.FC<ServiciosPersonalProps> = ({ onVolver }) => {
  const [solicitudes, setSolicitudes] = useState<SolicitudPersonal[]>([]);
  const [solicitudesFiltradas, setSolicitudesFiltradas] = useState<SolicitudPersonal[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [paginaActual, setPaginaActual] = useState(1);
  const [itemsPorPagina] = useState(50);
  const [vistaActual, setVistaActual] = useState<'lista' | 'vale' | 'tracking'>('lista');
  const [tokenSeleccionado, setTokenSeleccionado] = useState<string>('');
  
  // Estados para cancelación
  const [modalCancelacion, setModalCancelacion] = useState<{
    isOpen: boolean;
    solicitud: SolicitudPersonal | null;
  }>({
    isOpen: false,
    solicitud: null
  });
  const [motivosCancelacion, setMotivosCancelacion] = useState<string[]>([]);
  const [isLoadingMotivos, setIsLoadingMotivos] = useState(false);
  const [motivoSeleccionado, setMotivoSeleccionado] = useState('');
  const [observaciones, setObservaciones] = useState('');

  const [filtros, setFiltros] = useState<FiltrosSolicitudes>({
    busqueda: '',
    estado: 'todos',
    tipoServicio: 'todos',
    fechaDesde: '',
    fechaHasta: '',
    solicitante: '',
    mesAnio: ''
  });

  const [filtrosTabla, setFiltrosTabla] = useState({
    idServicio: '',
    traslado: '',
    origen: '',
    rutaAdicional: '',
    destino: '',
    area: '',
    centroCostos: '',
    motivo: '',
    detalleMotivo: '',
    costo: ''
  });

  const [toast, setToast] = useState<{
    isVisible: boolean;
    message: string;
    type: 'success' | 'error';
  }>({
    isVisible: false,
    message: '',
    type: 'success'
  });

  useEffect(() => {
    cargarSolicitudes();
  }, []);

  useEffect(() => {
    filtrarSolicitudes();
  }, [solicitudes, filtros, filtrosTabla]);

  // Función para convertir fecha DD-MM a YYYY-MM-DD para comparación
  const convertirFechaParaComparacion = (fechaServicio: string): string => {
    if (!fechaServicio) return '';
    
    // Si la fecha ya está en formato YYYY-MM-DD, devolverla tal como está
    if (fechaServicio.includes('-') && fechaServicio.length === 10 && fechaServicio.indexOf('-') === 4) {
      return fechaServicio;
    }
    
    // Si está en formato DD-MM, convertir a YYYY-MM-DD agregando el año actual
    if (fechaServicio.includes('-') && fechaServicio.length === 5) {
      const añoActual = new Date().getFullYear();
      const [dia, mes] = fechaServicio.split('-');
      return `${añoActual}-${mes.padStart(2, '0')}-${dia.padStart(2, '0')}`;
    }
    
    // Si está en formato DD/MM/YYYY, convertir a YYYY-MM-DD
    if (fechaServicio.includes('/')) {
      const partes = fechaServicio.split('/');
      if (partes.length === 3) {
        const [dia, mes, año] = partes;
        return `${año}-${mes.padStart(2, '0')}-${dia.padStart(2, '0')}`;
      }
    }
    
    return fechaServicio;
  };

  const cargarSolicitudes = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await obtenerSolicitudesPersonal();
      setSolicitudes(response.aisolicitudes);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error desconocido');
    } finally {
      setIsLoading(false);
    }
  };

  const cargarMotivosCancelacion = async (idservicio: number) => {
    try {
      setIsLoadingMotivos(true);
      const response = await obtenerMotivosCancelacion(idservicio);
      setMotivosCancelacion(response.aocancelar.map(m => m.cancelar));
    } catch (error) {
      console.error('Error al cargar motivos:', error);
      setMotivosCancelacion(['Error al cargar motivos']);
    } finally {
      setIsLoadingMotivos(false);
    }
  };

  const filtrarSolicitudes = () => {
    let resultado = [...solicitudes];

    // Filtrar por búsqueda general
    if (filtros.busqueda.trim()) {
      resultado = resultado.filter(s =>
        s.idservicio.toString().includes(filtros.busqueda) ||
        s.solicitante.toLowerCase().includes(filtros.busqueda.toLowerCase()) ||
        s.traslado.toLowerCase().includes(filtros.busqueda.toLowerCase()) ||
        s.direccionorigen.toLowerCase().includes(filtros.busqueda.toLowerCase()) ||
        s.direcciondestino.toLowerCase().includes(filtros.busqueda.toLowerCase())
      );
    }

    // Filtros específicos de tabla
    if (filtrosTabla.idServicio.trim()) {
      resultado = resultado.filter(s =>
        s.idservicio.toString().includes(filtrosTabla.idServicio)
      );
    }

    if (filtrosTabla.traslado.trim()) {
      resultado = resultado.filter(s =>
        s.traslado.toLowerCase().includes(filtrosTabla.traslado.toLowerCase())
      );
    }

    if (filtrosTabla.origen.trim()) {
      resultado = resultado.filter(s =>
        s.direccionorigen.toLowerCase().includes(filtrosTabla.origen.toLowerCase())
      );
    }

    if (filtrosTabla.rutaAdicional.trim()) {
      resultado = resultado.filter(s =>
        (s.rutaadicional || '').toLowerCase().includes(filtrosTabla.rutaAdicional.toLowerCase())
      );
    }

    if (filtrosTabla.destino.trim()) {
      resultado = resultado.filter(s =>
        s.direcciondestino.toLowerCase().includes(filtrosTabla.destino.toLowerCase())
      );
    }

    if (filtrosTabla.area.trim()) {
      resultado = resultado.filter(s =>
        (s.area || '').toLowerCase().includes(filtrosTabla.area.toLowerCase())
      );
    }

    if (filtrosTabla.centroCostos.trim()) {
      resultado = resultado.filter(s =>
        (s.centrocostos || '').toLowerCase().includes(filtrosTabla.centroCostos.toLowerCase())
      );
    }

    if (filtrosTabla.motivo.trim()) {
      resultado = resultado.filter(s =>
        (s.motivosolicitud || '').toLowerCase().includes(filtrosTabla.motivo.toLowerCase())
      );
    }

    if (filtrosTabla.detalleMotivo.trim()) {
      resultado = resultado.filter(s =>
        (s.motivodetalle || '').toLowerCase().includes(filtrosTabla.detalleMotivo.toLowerCase())
      );
    }

    if (filtrosTabla.costo.trim()) {
      resultado = resultado.filter(s =>
        s.costototal.toString().includes(filtrosTabla.costo)
      );
    }

    // Filtrar por estado
    if (filtros.estado !== 'todos') {
      const estadoMap: { [key: string]: number[] } = {
        'pendiente': [7],
        'aprobado': [8, 9, 10, 11],
        'completado': [12, 13],
        'rechazado': [14, 15]
      };
      resultado = resultado.filter(s => estadoMap[filtros.estado]?.includes(s.idestado));
    }

    // Filtrar por tipo de servicio
    if (filtros.tipoServicio !== 'todos') {
      resultado = resultado.filter(s => s.tservicio === filtros.tipoServicio);
    }

    // Filtrar por fechas - Manejar formato DD-MM vs YYYY-MM-DD
    if (filtros.fechaDesde) {
      resultado = resultado.filter(s => {
        const fechaServicio = convertirFechaParaComparacion(s.fecha);
        const fechaDesde = filtros.fechaDesde;
        return fechaServicio >= fechaDesde;
      });
    }
    if (filtros.fechaHasta) {
      resultado = resultado.filter(s => {
        const fechaServicio = convertirFechaParaComparacion(s.fecha);
        const fechaHasta = filtros.fechaHasta;
        return fechaServicio <= fechaHasta;
      });
    }

    // Filtrar por solicitante
    if (filtros.solicitante.trim()) {
      resultado = resultado.filter(s =>
        s.solicitante.toLowerCase().includes(filtros.solicitante.toLowerCase())
      );
    }

    setSolicitudesFiltradas(resultado);
    setPaginaActual(1);
  };

  const handleFiltroChange = (campo: keyof FiltrosSolicitudes, valor: string) => {
    setFiltros(prev => ({ ...prev, [campo]: valor }));
  };

  const handleFiltroTablaChange = (campo: keyof typeof filtrosTabla, valor: string) => {
    setFiltrosTabla(prev => ({ ...prev, [campo]: valor }));
  };

  const handleExportar = () => {
    exportarSolicitudesXLS(solicitudesFiltradas);
    setToast({
      isVisible: true,
      message: 'Archivo exportado exitosamente',
      type: 'success'
    });
  };

  const handleVerVale = (token: string) => {
    setTokenSeleccionado(token);
    setVistaActual('vale');
  };

  const handleVerTracking = (token: string) => {
    setTokenSeleccionado(token);
    setVistaActual('tracking');
  };

  const handleCancelar = async (solicitud: SolicitudPersonal) => {
    setModalCancelacion({
      isOpen: true,
      solicitud
    });
    setMotivoSeleccionado('');
    setObservaciones('');
    await cargarMotivosCancelacion(solicitud.idservicio);
  };

  const handleEnviarWhatsApp = () => {
    if (!motivoSeleccionado || !modalCancelacion.solicitud) {
      setToast({
        isVisible: true,
        message: 'Debe seleccionar un motivo de cancelación',
        type: 'error'
      });
      return;
    }

    const { solicitud } = modalCancelacion;
    const mensaje = `Solicitud de cancelación de servicio:
    
Número de servicio: ${solicitud.idservicio}
Motivo: ${motivoSeleccionado}
${observaciones ? `Observaciones: ${observaciones}` : ''}

Por favor, proceder con la cancelación.`;

    const whatsappUrl = `https://api.whatsapp.com/send?phone=51971166146&text=${encodeURIComponent(mensaje)}`;
    
    window.open(whatsappUrl, '_blank');
    
    setModalCancelacion({
      isOpen: false,
      solicitud: null
    });
    
    setToast({
      isVisible: true,
      message: 'Solicitud de cancelación enviada por WhatsApp',
      type: 'success'
    });
  };

  const formatearMoneda = (monto: number): string => {
    return `S/ ${monto.toFixed(2)}`;
  };

  const limpiarTexto = (texto: string): string => {
    return texto
      .replace(/&#x0D;\n/g, '') // Carriage Return + Line Feed codificado HTML
      .replace(/&#13;&#10;/g, '') // Otra codificación HTML de CRLF
      .replace(/\r\n/g, ' ') // Carriage Return + Line Feed estándar
      .replace(/\n/g, ' ') // Line Feed
      .replace(/\r/g, ' ') // Carriage Return
      .replace(/\s+/g, ' ') // Múltiples espacios a uno solo
      .trim();
  };

  const obtenerColorEstado = (idestado: number): { bg: string; text: string } => {
    switch (idestado) {
      case 7: return { bg: 'bg-yellow-100 dark:bg-yellow-900', text: 'text-yellow-800 dark:text-yellow-200' };
      case 8:
      case 9:
      case 10:
      case 11: return { bg: 'bg-blue-100 dark:bg-blue-900', text: 'text-blue-800 dark:text-blue-200' };
      case 12:
      case 13: return { bg: 'bg-green-100 dark:bg-green-900', text: 'text-green-800 dark:text-green-200' };
      case 14:
      case 15: return { bg: 'bg-red-100 dark:bg-red-900', text: 'text-red-800 dark:text-red-200' };
      default: return { bg: 'bg-gray-100 dark:bg-gray-700', text: 'text-gray-800 dark:text-gray-300' };
    }
  };

  // Paginación
  const totalPaginas = Math.ceil(solicitudesFiltradas.length / itemsPorPagina);
  const indiceInicio = (paginaActual - 1) * itemsPorPagina;
  const indiceFin = indiceInicio + itemsPorPagina;
  const solicitudesActuales = solicitudesFiltradas.slice(indiceInicio, indiceFin);

  // Mostrar componente Vale si está seleccionado
  if (vistaActual === 'vale' && tokenSeleccionado) {
    return (
      <Vale 
        token={tokenSeleccionado}
        onVolver={() => {
          setVistaActual('lista');
          setTokenSeleccionado('');
        }}
      />
    );
  }

  // Mostrar componente Tracking si está seleccionado
  if (vistaActual === 'tracking' && tokenSeleccionado) {
    return (
      <Tracking 
        token={tokenSeleccionado}
        onVolver={() => {
          setVistaActual('lista');
          setTokenSeleccionado('');
        }}
      />
    );
  }

  if (isLoading && solicitudes.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Cargando servicios del personal...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={onVolver}
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors duration-200"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Volver
              </button>
              <h1 className="ml-4 text-xl font-bold text-gray-900 dark:text-white flex items-center">
                <Users className="w-6 h-6 mr-2" />
                Servicios del Personal
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {solicitudesFiltradas.length} servicio{solicitudesFiltradas.length !== 1 ? 's' : ''}
              </span>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <div className="w-[95%] mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Controles compactos */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-200 dark:border-gray-700 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                Servicios del Personal
              </h2>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={cargarSolicitudes}
                disabled={isLoading}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                Consultar
              </button>

              <button
                onClick={handleExportar}
                className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar
              </button>
            </div>
          </div>
        </div>

        {/* Estadísticas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          {/* Total */}
          <div className="bg-blue-600 text-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm font-medium mb-1">Total</p>
                <p className="text-3xl font-bold">{solicitudesFiltradas.length}</p>
                <p className="text-blue-200 text-sm">
                  S/ {solicitudesFiltradas.reduce((sum, s) => sum + (s.costototal || 0), 0).toFixed(2)}
                </p>
              </div>
              <div className="p-3 bg-blue-500 rounded-lg">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20 6h-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v2H4a1 1 0 0 0 0 2h1v11a3 3 0 0 0 3 3h8a3 3 0 0 0 3-3V8h1a1 1 0 0 0 0-2zM8 4h8v2H8V4zm8 16H8a1 1 0 0 1-1-1V8h10v11a1 1 0 0 1-1 1z"/>
                </svg>
              </div>
            </div>
          </div>

          {/* En Proceso */}
          <div className="bg-green-600 text-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm font-medium mb-1">En Proceso</p>
                <p className="text-3xl font-bold">
                  {solicitudesFiltradas.filter(s => [7, 8, 9, 10, 11].includes(s.idestado)).length}
                </p>
                <p className="text-green-200 text-sm">
                  S/ {solicitudesFiltradas.filter(s => [7, 8, 9, 10, 11].includes(s.idestado)).reduce((sum, s) => sum + (s.costototal || 0), 0).toFixed(2)}
                </p>
              </div>
              <div className="p-3 bg-green-500 rounded-lg">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
              </div>
            </div>
          </div>

          {/* Cancelados */}
          <div className="bg-red-600 text-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100 text-sm font-medium mb-1">Cancelados</p>
                <p className="text-3xl font-bold">
                  {solicitudesFiltradas.filter(s => s.idestado === 14).length}
                </p>
                <p className="text-red-200 text-sm">
                  S/ {solicitudesFiltradas.filter(s => s.idestado === 14).reduce((sum, s) => sum + (s.costototal || 0), 0).toFixed(2)}
                </p>
              </div>
              <div className="p-3 bg-red-500 rounded-lg">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 mr-2" />
              <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
            </div>
          </div>
        )}

        {/* Tabla */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div className="overflow-x-auto overflow-y-auto max-h-[600px] scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700 sticky top-0 z-10">
                <tr>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Acciones
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Servicio
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Fecha/Hora
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Solicitante
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Traslado
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Origen
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Ruta Adicional
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Destino
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Área
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Centro Costos
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Motivo
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Detalle Motivo
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Tipo
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Costo
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Estado
                  </th>
                </tr>
                {/* Fila de filtros */}
                <tr className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-600">
                  <td className="px-6 py-2">
                    <button
                      onClick={() => {
                        setFiltros({
                          busqueda: '',
                          estado: 'todos',
                          tipoServicio: 'todos',
                          fechaDesde: '',
                          fechaHasta: '',
                          solicitante: '',
                          mesAnio: ''
                        });
                        setFiltrosTabla({
                          idServicio: '',
                          traslado: '',
                          origen: '',
                          rutaAdicional: '',
                          destino: '',
                          area: '',
                          centroCostos: '',
                          motivo: '',
                          detalleMotivo: '',
                          costo: ''
                        });
                      }}
                      className="text-xs text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                      title="Limpiar filtros"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.idServicio}
                      onChange={(e) => handleFiltroTablaChange('idServicio', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Buscar por ID..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <div className="flex space-x-1">
                      <input
                        type="date"
                        value={filtros.fechaDesde}
                        onChange={(e) => handleFiltroChange('fechaDesde', e.target.value)}
                        className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        title="Fecha desde"
                      />
                      <input
                        type="date"
                        value={filtros.fechaHasta}
                        onChange={(e) => handleFiltroChange('fechaHasta', e.target.value)}
                        className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        title="Fecha hasta"
                      />
                    </div>
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtros.solicitante}
                      onChange={(e) => handleFiltroChange('solicitante', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.traslado}
                      onChange={(e) => handleFiltroTablaChange('traslado', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Buscar traslado..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.origen}
                      onChange={(e) => handleFiltroTablaChange('origen', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar origen..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.rutaAdicional}
                      onChange={(e) => handleFiltroTablaChange('rutaAdicional', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar ruta..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.destino}
                      onChange={(e) => handleFiltroTablaChange('destino', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar destino..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.area}
                      onChange={(e) => handleFiltroTablaChange('area', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar área..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.centroCostos}
                      onChange={(e) => handleFiltroTablaChange('centroCostos', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar centro..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.motivo}
                      onChange={(e) => handleFiltroTablaChange('motivo', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar motivo..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.detalleMotivo}
                      onChange={(e) => handleFiltroTablaChange('detalleMotivo', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar detalle..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <select
                      value={filtros.tipoServicio}
                      onChange={(e) => handleFiltroChange('tipoServicio', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    >
                      <option value="todos">Todos</option>
                      <option value="Traslado">Traslado</option>
                      <option value="Delivery">Delivery</option>
                      <option value="Espera">Espera</option>
                    </select>
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.costo}
                      onChange={(e) => handleFiltroTablaChange('costo', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar costo..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <select
                      value={filtros.estado}
                      onChange={(e) => handleFiltroChange('estado', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    >
                      <option value="todos">Todos</option>
                      <option value="pendiente">Pendiente</option>
                      <option value="aprobado">Aprobado</option>
                      <option value="completado">Completado</option>
                      <option value="rechazado">Rechazado</option>
                    </select>
                  </td>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-600">
                {solicitudesActuales.length > 0 ? (
                  solicitudesActuales.map((solicitud) => {
                    const colorEstado = obtenerColorEstado(solicitud.idestado);
                    return (
                      <tr key={solicitud.idservicio} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center space-x-2">
                            {/* Botón Vale */}
                            <button
                              onClick={() => handleVerVale(solicitud.tokeng)}
                              className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-200 transition-colors duration-200"
                              title="Ver vale"
                            >
                              <FileText className="w-4 h-4" />
                            </button>

                            {/* Botón Tracking */}
                            <button
                              onClick={() => handleVerTracking(solicitud.tokeng)}
                              className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-200 transition-colors duration-200"
                              title="Ver tracking"
                            >
                              <MapPin className="w-4 h-4" />
                            </button>

                            {/* Botón Cancelar - Solo si idestado es 7 (pendiente) */}
                            {solicitud.idestado === 7 && (
                              <button
                                onClick={() => handleCancelar(solicitud)}
                                className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-200 transition-colors duration-200"
                                title="Cancelar servicio"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}


                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-mono text-gray-900 dark:text-white">
                            #{solicitud.idservicio}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            {solicitud.tservicio}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900 dark:text-white">
                            {solicitud.fecha}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            {solicitud.hora}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900 dark:text-white max-w-[150px] truncate" title={solicitud.solicitante}>
                            {solicitud.solicitante}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900 dark:text-white max-w-[150px] truncate" title={limpiarTexto(solicitud.traslado)}>
                            {limpiarTexto(solicitud.traslado)}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-600 dark:text-gray-400 max-w-[200px] truncate" title={solicitud.direccionorigen}>
                            {solicitud.direccionorigen}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-600 dark:text-gray-400 max-w-[150px] truncate" title={solicitud.rutaadicional || ''}>
                            {solicitud.rutaadicional || '-'}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-600 dark:text-gray-400 max-w-[200px] truncate" title={solicitud.direcciondestino}>
                            {solicitud.direcciondestino}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-600 dark:text-gray-400 max-w-[120px] truncate" title={solicitud.area && solicitud.area !== '0' ? solicitud.area : ''}>
                            {solicitud.area && solicitud.area !== '0' ? solicitud.area : '-'}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-600 dark:text-gray-400 max-w-[120px] truncate" title={solicitud.centrocostos && solicitud.centrocostos !== '0' ? solicitud.centrocostos : ''}>
                            {solicitud.centrocostos && solicitud.centrocostos !== '0' ? solicitud.centrocostos : '-'}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-600 dark:text-gray-400 max-w-[120px] truncate" title={solicitud.motivosolicitud || ''}>
                            {solicitud.motivosolicitud || '-'}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-600 dark:text-gray-400 max-w-[150px] truncate" title={solicitud.motivodetalle || ''}>
                            {solicitud.motivodetalle || '-'}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          <span className="text-sm text-gray-900 dark:text-white">
                            {solicitud.tipo}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right">
                          <span className="text-sm font-semibold text-gray-900 dark:text-white">
                            {formatearMoneda(solicitud.costototal)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          <span 
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${colorEstado.bg} ${colorEstado.text}`}
                          >
                            {solicitud.estado}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={15} className="px-6 py-12 text-center">
                      <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500 dark:text-gray-400">
                        {Object.values(filtrosTabla).some(f => f !== '') || Object.values(filtros).some(f => f !== '' && f !== 'todos')
                          ? 'No se encontraron servicios con los filtros aplicados' 
                          : 'No hay servicios del personal registrados'
                        }
                      </p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Paginación */}
          {totalPaginas > 1 && (
            <div className="bg-gray-50 dark:bg-gray-700 px-6 py-3 border-t border-gray-200 dark:border-gray-600">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-700 dark:text-gray-300">
                  Mostrando {indiceInicio + 1} a {Math.min(indiceFin, solicitudesFiltradas.length)} de {solicitudesFiltradas.length} resultados
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setPaginaActual(prev => Math.max(prev - 1, 1))}
                    disabled={paginaActual === 1}
                    className="px-3 py-1 text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed text-gray-900 dark:text-white"
                  >
                    Anterior
                  </button>
                  <span className="text-sm text-gray-700 dark:text-gray-300">
                    Página {paginaActual} de {totalPaginas}
                  </span>
                  <button
                    onClick={() => setPaginaActual(prev => Math.min(prev + 1, totalPaginas))}
                    disabled={paginaActual === totalPaginas}
                    className="px-3 py-1 text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed text-gray-900 dark:text-white"
                  >
                    Siguiente
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal de Cancelación */}
      {modalCancelacion.isOpen && modalCancelacion.solicitud && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            {/* Overlay */}
            <div 
              className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
              onClick={() => setModalCancelacion({ isOpen: false, solicitud: null })}
            />

            {/* Modal */}
            <div className="inline-block w-full max-w-md p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white dark:bg-gray-800 shadow-xl rounded-2xl">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Cancelar Servicio
                </h3>
                <button
                  onClick={() => setModalCancelacion({ isOpen: false, solicitud: null })}
                  className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors duration-200 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Información del servicio */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-6">
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                  Servicio #{modalCancelacion.solicitud.idservicio}
                </h4>
                <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <p><strong>Solicitante:</strong> {modalCancelacion.solicitud.solicitante}</p>
                  <p><strong>Traslado:</strong> {limpiarTexto(modalCancelacion.solicitud.traslado)}</p>
                  <p><strong>Fecha:</strong> {modalCancelacion.solicitud.fecha} - {modalCancelacion.solicitud.hora}</p>
                  <p><strong>Costo:</strong> {formatearMoneda(modalCancelacion.solicitud.costototal)}</p>
                </div>
              </div>

              {/* Formulario de cancelación */}
              <div className="space-y-4">
                {/* Motivo */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Motivo de cancelación *
                  </label>
                  {isLoadingMotivos ? (
                    <div className="flex items-center justify-center py-4">
                      <Loader2 className="w-5 h-5 animate-spin text-primary-600" />
                      <span className="ml-2 text-sm text-gray-600 dark:text-gray-400">
                        Cargando motivos...
                      </span>
                    </div>
                  ) : (
                    <select
                      value={motivoSeleccionado}
                      onChange={(e) => setMotivoSeleccionado(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      required
                    >
                      <option value="">Seleccionar motivo</option>
                      {motivosCancelacion.map((motivo, index) => (
                        <option key={index} value={motivo}>
                          {motivo}
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                {/* Observaciones */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Observaciones
                  </label>
                  <textarea
                    value={observaciones}
                    onChange={(e) => setObservaciones(e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none"
                    placeholder="Detalles adicionales sobre la cancelación..."
                  />
                </div>
              </div>

              {/* Botones */}
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setModalCancelacion({ isOpen: false, solicitud: null })}
                  className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleEnviarWhatsApp}
                  disabled={!motivoSeleccionado}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Enviar por WhatsApp
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast de Notificación */}
      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={() => setToast(prev => ({ ...prev, isVisible: false }))}
      />
    </div>
  );
};