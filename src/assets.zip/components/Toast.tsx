import React, { useEffect, useState } from 'react';
import { CheckCircle, XCircle, X } from 'lucide-react';

interface ToastProps {
  message: string;
  type: 'success' | 'error';
  isVisible: boolean;
  onClose: () => void;
  duration?: number;
}

/**
 * Componente Toast para mostrar notificaciones
 */
export const Toast: React.FC<ToastProps> = ({ 
  message, 
  type, 
  isVisible, 
  onClose, 
  duration = 4000 
}) => {
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    if (isVisible) {
      setIsAnimating(true);
      const timer = setTimeout(() => {
        handleClose();
      }, duration);

      return () => clearTimeout(timer);
    }
  }, [isVisible, duration]);

  const handleClose = () => {
    setIsAnimating(false);
    setTimeout(() => {
      onClose();
    }, 300);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed top-4 right-4 z-50">
      <div
        className={`
          transform transition-all duration-300 ease-in-out
          ${isAnimating ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}
          w-[360px] sm:w-[420px] bg-white dark:bg-gray-800 shadow-2xl rounded-xl pointer-events-auto
          ring-1 ring-black ring-opacity-5 overflow-hidden
        `}
      >
        <div className="p-4">
          <div className="flex items-start">
            <div className="flex-shrink-0 mt-[2px]">
              {type === 'success' ? (
                <CheckCircle className="h-6 w-6 text-green-500" />
              ) : (
                <XCircle className="h-6 w-6 text-red-500" />
              )}
            </div>
            <div className="ml-3 flex-1 min-w-0">
              <p className="text-[0.95rem] font-semibold text-gray-900 dark:text-white truncate">
                {type === 'success' ? 'Éxito' : 'Error'}
              </p>
              <p className="mt-1 text-sm leading-5 text-gray-600 dark:text-gray-300 break-words">
                {message}
              </p>
            </div>
            <div className="ml-4 flex-shrink-0">
              <button
                onClick={handleClose}
                className="bg-white dark:bg-gray-800 rounded-md inline-flex text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                aria-label="Cerrar notificación"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
        <div
          className={`h-1 ${type === 'success' ? 'bg-green-500' : 'bg-red-500'} transform origin-left transition-transform ease-linear ${isAnimating ? 'scale-x-0' : 'scale-x-100'}`}
          style={{ transitionDuration: `${duration}ms` }}
        />
      </div>
    </div>
  );
};