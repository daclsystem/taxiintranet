import React, { useState, useEffect } from 'react';
import { 
  Car, MapPin, Clock, User, LogOut, Menu, Home, FileText, 
  History, Users, DollarSign, CheckCircle, Shield, Building,
  MessageCircle, Phone, Mail, Loader2, AlertCircle, Calendar, BarChart3,
  TrendingUp, Activity
} from 'lucide-react';
import { limpiarSesion, obtenerSesion } from '../services/authService';
import { obtenerDatosPrincipales, obtenerReporte } from '../services/dashboardService';
import { PrincipalResponse, MenuOption, ReporteData } from '../types/dashboard';
import { ThemeToggle } from './ThemeToggle';
import { ConfirmDialog } from './ConfirmDialog';

// Lazy load del componente SolicitarServicio
const SolicitarServicio = React.lazy(() => import('./SolicitarServicio').then(module => ({ default: module.SolicitarServicio })));
const AreaManagement = React.lazy(() => import('./AreaManagement').then(module => ({ default: module.AreaManagement })));
const CentroCostosManagement = React.lazy(() => import('./CentroCostosManagement').then(module => ({ default: module.CentroCostosManagement })));
const PersonalManagement = React.lazy(() => import('./PersonalManagement').then(module => ({ default: module.PersonalManagement })));
const ServiciosPersonal = React.lazy(() => import('./ServiciosPersonal').then(module => ({ default: module.ServiciosPersonal })));
const MisServicios = React.lazy(() => import('./MisServicios').then(module => ({ default: module.MisServicios })));
const Historial = React.lazy(() => import('./Historial').then(module => ({ default: module.Historial })));
const HistorialPersonal = React.lazy(() => import('./HistorialPersonal').then(module => ({ default: module.HistorialPersonal })));
const ValidarServicios = React.lazy(() => import('./ValidarServicios').then(module => ({ default: module.ValidarServicios })));
const VerificarServicios = React.lazy(() => import('./VerificarServicios').then(module => ({ default: module.VerificarServicios })));
const Perfil = React.lazy(() => import('./Perfil').then(module => ({ default: module.Perfil })));

/**
 * Dashboard principal de Z Movilidad con menú dinámico basado en permisos
 */
export const Dashboard: React.FC = () => {
  const [datosUsuario, setDatosUsuario] = useState<PrincipalResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Inicializar directamente con el mes actual
  const obtenerMesActual = () => {
    const fechaActual = new Date();
    const añoActual = fechaActual.getFullYear();
    const mesActualNumero = fechaActual.getMonth(); // 0-11
    const nombresMeses = [
      'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
      'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];
    return `${nombresMeses[mesActualNumero]} ${añoActual}`;
  };

  const [mesSeleccionado, setMesSeleccionado] = useState<string>(obtenerMesActual());
  const [reporteData, setReporteData] = useState<ReporteData[]>([]);
  const [isLoadingReporte, setIsLoadingReporte] = useState(false);
  const session = obtenerSesion();
  const [mostrarConfirmacionSalir, setMostrarConfirmacionSalir] = useState(false);

  useEffect(() => {
    cargarDatosPrincipales();
  }, []);

  useEffect(() => {
    if (datosUsuario && mesSeleccionado) {
      cargarReporte(mesSeleccionado);
    }
  }, [datosUsuario, mesSeleccionado]);

  // Generar opciones de meses (solo actual y anterior)
  const generarOpcionesMeses = () => {
    const fechaActual = new Date();
    const añoActual = fechaActual.getFullYear();
    const mesActualNumero = fechaActual.getMonth(); // 0-11
    
    // Array de nombres de meses en español
    const nombresMeses = [
      'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
      'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];
    
    // Mes actual
    const mesActual = `${nombresMeses[mesActualNumero]} ${añoActual}`;
    
    // Mes anterior
    let mesAnteriorNumero = mesActualNumero - 1;
    let añoAnterior = añoActual;
    if (mesAnteriorNumero < 0) {
      mesAnteriorNumero = 11; // Diciembre
      añoAnterior = añoActual - 1;
    }
    const mesAnterior = `${nombresMeses[mesAnteriorNumero]} ${añoAnterior}`;
    
    return [
      { mesanio: mesActual },    // Mes actual primero (será el seleccionado por defecto)
      { mesanio: mesAnterior }   // Mes anterior segundo
    ];
  };

  const cargarDatosPrincipales = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const datos = await obtenerDatosPrincipales();
      setDatosUsuario(datos);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error desconocido');
    } finally {
      setIsLoading(false);
    }
  };

  const cargarReporte = async (consulta: string) => {
    try {
      setIsLoadingReporte(true);
      const reporte = await obtenerReporte(consulta);
      setReporteData(reporte.areported);
    } catch (error) {
      console.error('Error al cargar reporte:', error);
      setReporteData([]);
    } finally {
      setIsLoadingReporte(false);
    }
  };

  const handleLogout = () => {
    setMostrarConfirmacionSalir(true);
  };

  const confirmarSalir = () => {
    limpiarSesion();
    window.location.reload();
  };

  // Función para formatear moneda
  const formatearMoneda = (monto: number): string => {
    return `S/ ${monto.toFixed(2)}`;
  };

  // Función para obtener el máximo valor del gráfico
  const obtenerMaximoGrafico = (): number => {
    if (reporteData.length === 0) return 100;
    return Math.max(...reporteData.map(item => item.total));
  };

  // Generar opciones de menú basadas en permisos
  const generarOpcionesMenu = (): MenuOption[] => {
    if (!datosUsuario) return [];

    const { oaiprincipal } = datosUsuario;
    const opciones: MenuOption[] = [];

    // Opciones principales (siempre visibles)
    opciones.push(
      {
        id: 'solicitar',
        titulo: 'Solicitar',
        descripcion: 'Solicitar nuevo servicio',
        icono: Car,
        color: 'bg-primary-500 hover:bg-primary-600',
        categoria: 'principal'
      },
      {
        id: 'mis-servicios',
        titulo: 'Mis Servicios',
        descripcion: 'Mis servicios Pendientes y/o en Ejecución (Yo)',
        icono: MapPin,
        color: 'bg-secondary-500 hover:bg-secondary-600',
        categoria: 'principal'
      },
      {
        id: 'historial',
        titulo: 'Historial',
        descripcion: 'Historial de Mis Servicios (Yo)',
        icono: History,
        color: 'bg-gray-600 hover:bg-gray-700',
        categoria: 'principal'
      },
      {
        id: 'perfil',
        titulo: 'Perfil',
        descripcion: 'Configurar perfil de usuario',
        icono: User,
        color: 'bg-indigo-500 hover:bg-indigo-600',
        categoria: 'principal'
      }
    );

    // Opciones de administrador (ve todas las opciones)
    if (oaiprincipal.administrador) {
      opciones.push(
        {
          id: 'servicios-personal',
          titulo: 'Servicios Personal',
          descripcion: 'Servicios de los demás Usuarios (Otros)',
          icono: Users,
          color: 'bg-purple-500 hover:bg-purple-600',
          categoria: 'admin'
        },
        {
          id: 'historial-personal',
          titulo: 'Historial Servicios Personal',
          descripcion: 'Historial del personal (Otros)',
          icono: FileText,
          color: 'bg-indigo-500 hover:bg-indigo-600',
          categoria: 'admin'
        },
        {
          id: 'validar-servicios',
          titulo: 'Aprobación de Servicios',
          descripcion: 'El autorizado tiene una solicitud de servicio por confirmar de un pasajero',
          icono: CheckCircle,
          color: 'bg-green-500 hover:bg-green-600',
          categoria: 'admin'
        },
        {
          id: 'verificar-servicios',
          titulo: 'Revisión de Servicios',
          descripcion: 'Confirme la revisión de los Servicios (Todos)',
          icono: Shield,
          color: 'bg-teal-500 hover:bg-teal-600',
          categoria: 'admin'
        },
        {
          id: 'personal',
          titulo: 'Personal',
          descripcion: 'Gestionar personal',
          icono: Users,
          color: 'bg-cyan-500 hover:bg-cyan-600',
          categoria: 'admin'
        },
        {
          id: 'centro-costos',
          titulo: 'Centro Costos',
          descripcion: 'Gestionar centros de costo',
          icono: DollarSign,
          color: 'bg-emerald-500 hover:bg-emerald-600',
          categoria: 'admin'
        },
        {
          id: 'area',
          titulo: 'Área',
          descripcion: 'Gestionar áreas',
          icono: Building,
          color: 'bg-amber-500 hover:bg-amber-600',
          categoria: 'admin'
        }
      );
    } else {
      // Para usuarios que NO son administradores
      
      // Si es validador (no administrador)
      if (oaiprincipal.validador) {
        opciones.push({
          id: 'validar-servicios',
          titulo: 'Aprobación de Servicios',
          descripcion: 'El autorizado tiene una solicitud de servicio por confirmar de un pasajero',
          icono: CheckCircle,
          color: 'bg-green-500 hover:bg-green-600',
          categoria: 'validador'
        });
      }
      
      // Si es verificador (no administrador)
      if (oaiprincipal.verificador) {
        opciones.push({
          id: 'verificar-servicios',
          titulo: 'Revisión de Servicios',
          descripcion: 'Confirme la revisión de los Servicios (Todos)',
          icono: Shield,
          color: 'bg-teal-500 hover:bg-teal-600',
          categoria: 'verificador'
        });
      }
      
      // Si es jefe (no administrador)
      if (oaiprincipal.jefe) {
        opciones.push(
          {
            id: 'servicios-personal',
            titulo: 'Servicios Personal',
            descripcion: 'Servicios de los demás Usuarios (Otros)',
            icono: Users,
            color: 'bg-purple-500 hover:bg-purple-600',
            categoria: 'jefe'
          },
          {
            id: 'historial-personal',
            titulo: 'Historial Servicios Personal',
            descripcion: 'Historial del personal (Otros)',
            icono: FileText,
            color: 'bg-indigo-500 hover:bg-indigo-600',
            categoria: 'jefe'
          }
        );
      }
    }

    // Opciones de contacto (siempre visibles)
    opciones.push(
      {
        id: 'escribenos',
        titulo: 'Escríbenos',
        descripcion: 'Enviar mensaje de soporte',
        icono: MessageCircle,
        color: 'bg-pink-500 hover:bg-pink-600',
        categoria: 'contacto'
      },
      {
        id: 'llamanos',
        titulo: 'Llámanos',
        descripcion: 'Contacto telefónico',
        icono: Phone,
        color: 'bg-red-500 hover:bg-red-600',
        categoria: 'contacto'
      },
      {
        id: 'correo',
        titulo: 'Enviar Correo',
        descripcion: 'Contacto por email',
        icono: Mail,
        color: 'bg-blue-500 hover:bg-blue-600',
        categoria: 'contacto'
      }
    );

    return opciones;
  };

  const opcionesMenu = generarOpcionesMenu();

  // Estado para navegación
  const [vistaActual, setVistaActual] = useState<'dashboard' | 'solicitar' | 'area' | 'centro-costos' | 'personal' | 'servicios-personal' | 'mis-servicios' | 'historial' | 'historial-personal' | 'validar-servicios' | 'verificar-servicios' | 'perfil'>('dashboard');

  const handleNavegacion = (opcionId: string) => {
    switch (opcionId) {
      case 'solicitar':
        setVistaActual('solicitar');
        break;
      case 'area':
        setVistaActual('area');
        break;
      case 'centro-costos':
        setVistaActual('centro-costos');
        break;
      case 'personal':
        setVistaActual('personal');
        break;
      case 'servicios-personal':
        setVistaActual('servicios-personal');
        break;
      case 'mis-servicios':
        setVistaActual('mis-servicios');
        break;
      case 'historial':
        setVistaActual('historial');
        break;
      case 'historial-personal':
        setVistaActual('historial-personal');
        break;
      case 'validar-servicios':
        setVistaActual('validar-servicios');
        break;
      case 'verificar-servicios':
        setVistaActual('verificar-servicios');
        break;
      case 'perfil':
        setVistaActual('perfil');
        break;
      case 'escribenos':
        // Abrir WhatsApp
        window.open('https://api.whatsapp.com/send?phone=51987708676&text=necesito%20ayuda', '_blank');
        break;
      case 'llamanos':
        // Llamar al número
        window.open('tel:+51015144400', '_self');
        break;
      case 'correo':
        // Abrir cliente de correo
        window.open('mailto:reservas@zmovilidad.com', '_self');
        break;
      default:
        // Para otras opciones, mantener en dashboard por ahora
        console.log(`Navegando a: ${opcionId}`);
        break;
    }
  };

  // Agrupar opciones por categoría
  const opcionesPrincipales = opcionesMenu.filter(op => op.categoria === 'principal');
      const opcionesAdmin = opcionesMenu.filter(op => ['admin', 'validador', 'verificador', 'jefe'].includes(op.categoria));
  const opcionesContacto = opcionesMenu.filter(op => op.categoria === 'contacto');

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Cargando dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            Error al cargar datos
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-4">{error}</p>
          <button
            onClick={cargarDatosPrincipales}
            className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200"
          >
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  if (!datosUsuario) return null;

  const { oaiprincipal } = datosUsuario;

  // Mostrar componente de solicitar si está seleccionado
  if (vistaActual === 'solicitar') {
    return (
      <React.Suspense fallback={
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando solicitud de servicio...</p>
          </div>
        </div>
      }>
        <SolicitarServicio 
          onVolver={() => setVistaActual('dashboard')}
          onNavegar={(vista) => {
            if (vista === 'mis-servicios') {
              setVistaActual('mis-servicios');
            }
          }}
        />
      </React.Suspense>
    );
  }

  // Mostrar componente de área si está seleccionado
  if (vistaActual === 'area') {
    return (
      <React.Suspense fallback={
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando gestión de áreas...</p>
          </div>
        </div>
      }>
        <AreaManagement 
          onVolver={() => setVistaActual('dashboard')} 
        />
      </React.Suspense>
    );
  }

  // Mostrar componente de centro de costos si está seleccionado
  if (vistaActual === 'centro-costos') {
    return (
      <React.Suspense fallback={
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando gestión de centros de costos...</p>
          </div>
        </div>
      }>
        <CentroCostosManagement 
          onVolver={() => setVistaActual('dashboard')} 
        />
      </React.Suspense>
    );
  }

  // Mostrar componente de personal si está seleccionado
  if (vistaActual === 'personal') {
    return (
      <React.Suspense fallback={
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando gestión de personal...</p>
          </div>
        </div>
      }>
        <PersonalManagement 
          onVolver={() => setVistaActual('dashboard')} 
        />
      </React.Suspense>
    );
  }

  // Mostrar componente de servicios personal si está seleccionado
  if (vistaActual === 'servicios-personal') {
    return (
      <React.Suspense fallback={
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando servicios del personal...</p>
          </div>
        </div>
      }>
        <ServiciosPersonal 
          onVolver={() => setVistaActual('dashboard')} 
        />
      </React.Suspense>
    );
  }

  // Mostrar componente de mis servicios si está seleccionado
  if (vistaActual === 'mis-servicios') {
    return (
      <React.Suspense fallback={
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando mis servicios...</p>
          </div>
        </div>
      }>
        <MisServicios 
          onVolver={() => setVistaActual('dashboard')} 
        />
      </React.Suspense>
    );
  }

  // Mostrar componente de historial si está seleccionado
  if (vistaActual === 'historial') {
    return (
      <React.Suspense fallback={
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando historial...</p>
          </div>
        </div>
      }>
        <Historial 
          onVolver={() => setVistaActual('dashboard')} 
        />
      </React.Suspense>
    );
  }

  // Mostrar componente de historial personal si está seleccionado
  if (vistaActual === 'historial-personal') {
    return (
      <React.Suspense fallback={
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando historial del personal...</p>
          </div>
        </div>
      }>
        <HistorialPersonal 
          onVolver={() => setVistaActual('dashboard')} 
        />
      </React.Suspense>
    );
  }

  // Mostrar componente de validar servicios si está seleccionado
  if (vistaActual === 'validar-servicios') {
    return (
      <React.Suspense fallback={
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando validación de servicios...</p>
          </div>
        </div>
      }>
        <ValidarServicios 
          onVolver={() => setVistaActual('dashboard')} 
        />
      </React.Suspense>
    );
  }

  // Mostrar componente de verificar servicios si está seleccionado
  if (vistaActual === 'verificar-servicios') {
    return (
      <React.Suspense fallback={
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando verificación de servicios...</p>
          </div>
        </div>
      }>
        <VerificarServicios 
          onVolver={() => setVistaActual('dashboard')} 
        />
      </React.Suspense>
    );
  }

  // Mostrar componente de perfil si está seleccionado
  if (vistaActual === 'perfil') {
    return (
      <React.Suspense fallback={
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando perfil...</p>
          </div>
        </div>
      }>
        <Perfil 
          onVolver={() => setVistaActual('dashboard')} 
        />
      </React.Suspense>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <img 
                src="https://clientes.zmovilidad.app/media/logoz.png" 
                alt="Z Movilidad" 
                className="h-10 w-10"
              />
              <h1 className="ml-3 text-xl font-bold text-gray-900 dark:text-white">
                Z Movilidad
              </h1>
            </div>

            {/* User Info */}
            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <div className="flex items-center space-x-3">
                <img
                  src={oaiprincipal.foto}
                  alt="Foto de perfil"
                  className="w-8 h-8 rounded-full object-cover"
                />
                <div className="hidden sm:block">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {oaiprincipal.datcliente}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {oaiprincipal.nombrecomercial}
                  </p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors duration-200"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Salir</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            ¡Bienvenido, {oaiprincipal.datcliente}!
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Selecciona una opción para comenzar
          </p>
        </div>

        {/* Servicios Principales */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Servicios Principales
          </h3>
          {/* Cambio para forzar recarga v2 */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {opcionesPrincipales.map((opcion) => {
              const IconComponent = opcion.icono;
              return (
                <button
                  key={opcion.id}
                  onClick={() => handleNavegacion(opcion.id)}
                  className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200 text-left group"
                >
                  <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg ${opcion.color} mb-4 group-hover:scale-110 transition-transform duration-200`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    {opcion.titulo}
                  </h4>
                  <p style={{
                    color: '#9CA3AF',
                    fontSize: '14px',
                    lineHeight: '20px',
                    fontWeight: 'normal',
                    opacity: '1'
                  }}>
                    {opcion.descripcion}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Opciones Administrativas */}
        {opcionesAdmin.length > 0 && (
          <div className="mb-8">
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Administración
                </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {opcionesAdmin.map((opcion) => {
                const IconComponent = opcion.icono;
                return (
                  <button
                    key={opcion.id}
                    onClick={() => handleNavegacion(opcion.id)}
                    className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200 text-left group"
                  >
                    <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg ${opcion.color} mb-4 group-hover:scale-110 transition-transform duration-200`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                      {opcion.titulo}
                    </h4>
                    <p style={{
                      color: '#9CA3AF',
                      fontSize: '14px',
                      lineHeight: '20px',
                      fontWeight: 'normal',
                      opacity: '1'
                    }}>
                      {opcion.descripcion}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Opciones de Contacto */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Soporte y Contacto
          </h3>
          <div className="grid md:grid-cols-3 gap-4">
            {opcionesContacto.map((opcion) => {
              const IconComponent = opcion.icono;
              return (
                <button
                  key={opcion.id}
                  onClick={() => handleNavegacion(opcion.id)}
                  className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200 text-left group"
                >
                  <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg ${opcion.color} mb-4 group-hover:scale-110 transition-transform duration-200`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    {opcion.titulo}
                  </h4>
                  <p style={{
                    color: '#9CA3AF',
                    fontSize: '14px',
                    lineHeight: '20px',
                    fontWeight: 'normal',
                    opacity: '1'
                  }}>
                    {opcion.descripcion}
                  </p>
                </button>
              );
            })}
          </div>
        </div>



        {/* Filtro de Mes/Año y Gráfico */}
        {datosUsuario && (
          <div className="mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center">
                  <Calendar className="w-5 h-5 mr-2" />
                  Reporte Mensual
                </h3>
                <div className="flex items-center space-x-3">
                  <select
                    value={mesSeleccionado}
                    onChange={(e) => setMesSeleccionado(e.target.value)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    {generarOpcionesMeses().map((mes) => (
                      <option key={mes.mesanio} value={mes.mesanio}>
                        {mes.mesanio}
                      </option>
                    ))}
                  </select>
                  {isLoadingReporte && (
                    <Loader2 className="w-5 h-5 animate-spin text-primary-600" />
                  )}
                </div>
              </div>

              {/* Gráfico de Barras */}
              {reporteData.length > 0 ? (
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                  <div className="relative h-64">
                    {/* Línea de cantidad de servicios */}
                    <svg className="absolute inset-0 w-full h-full" style={{ zIndex: 2 }}>
                      <defs>
                        <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.8" />
                          <stop offset="100%" stopColor="#d97706" stopOpacity="0.8" />
                        </linearGradient>
                      </defs>
                      {reporteData.length > 1 && (
                        <polyline
                          fill="none"
                          stroke="url(#lineGradient)"
                          strokeWidth="3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          points={reporteData.map((item, index) => {
                            const maxCuenta = Math.max(...reporteData.map(d => d.cuenta));
                            const x = (index / (reporteData.length - 1)) * 100;
                            const y = 100 - ((item.cuenta / maxCuenta) * 80);
                            return `${x}%,${y}%`;
                          }).join(' ')}
                        />
                      )}
                      {/* Puntos en la línea */}
                      {reporteData.map((item, index) => {
                        const maxCuenta = Math.max(...reporteData.map(d => d.cuenta));
                        const x = (index / (reporteData.length - 1)) * 100;
                        const y = 100 - ((item.cuenta / maxCuenta) * 80);
                        return (
                          <g key={`point-${index}`}>
                            <circle
                              cx={`${x}%`}
                              cy={`${y}%`}
                              r="4"
                              fill="#f59e0b"
                              stroke="#ffffff"
                              strokeWidth="2"
                            />
                            <text
                              x={`${x}%`}
                              y={`${y - 8}%`}
                              textAnchor="middle"
                              className="text-xs fill-current text-orange-600 dark:text-orange-400 font-semibold"
                            >
                              {item.cuenta} viaje{item.cuenta !== 1 ? 's' : ''}
                            </text>
                          </g>
                        );
                      })}
                    </svg>
                    
                    {/* Barras de montos */}
                    <div className="flex items-end justify-between h-full space-x-2" style={{ zIndex: 1 }}>
                    {reporteData.map((item) => {
                      const altura = (item.total / obtenerMaximoGrafico()) * 100;
                      return (
                        <div key={item.dia} className="flex flex-col items-center flex-1">
                          <div className="flex flex-col items-center mb-2 min-h-[60px] justify-end">
                            <span className="text-xs text-gray-600 dark:text-gray-400 mb-1">
                              {formatearMoneda(item.total)}
                            </span>
                          </div>
                          <div
                            className="w-full bg-gradient-to-t from-blue-500 to-blue-400 rounded-t-md transition-all duration-500 hover:from-blue-600 hover:to-blue-500 opacity-80"
                            style={{ height: `${altura}%`, minHeight: '4px' }}
                          />
                          <div className="mt-2 text-sm font-semibold text-gray-700 dark:text-gray-300">
                            {item.dia}
                          </div>
                        </div>
                      );
                    })}
                    </div>
                  </div>
                  
                  {/* Leyenda */}
                  <div className="mt-4 flex justify-between items-center">
                    <div className="flex items-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
                      <div className="flex items-center">
                        <div className="w-4 h-4 bg-gradient-to-t from-blue-500 to-blue-400 rounded mr-2"></div>
                        <span>Montos (S/)</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-4 h-1 bg-gradient-to-r from-orange-500 to-orange-600 rounded mr-2"></div>
                        <span>Cantidad de viajes</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
                      <div className="flex items-center">
                        <TrendingUp className="w-4 h-4 mr-1" />
                        Total: {formatearMoneda(reporteData.reduce((sum, item) => sum + item.total, 0))}
                      </div>
                      <div className="flex items-center">
                        <Activity className="w-4 h-4 mr-1" />
                        Viajes: {reporteData.reduce((sum, item) => sum + item.cuenta, 0)}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  {isLoadingReporte ? 'Cargando reporte...' : 'No hay datos para el mes seleccionado'}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tablas de Servicios */}
        {datosUsuario && (
          <div className="grid lg:grid-cols-2 gap-6 mb-8">
            {/* Servicios en Proceso */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                <Clock className="w-5 h-5 mr-2 text-orange-500" />
                Servicios en Proceso ({datosUsuario.aaiprocesod.length})
              </h3>
              {datosUsuario.aaiprocesod.length > 0 ? (
                <div className="overflow-x-auto overflow-y-auto max-h-[400px]">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-gray-200 dark:border-gray-600">
                        <th className="text-left py-2 text-gray-600 dark:text-gray-400"># Servicio</th>
                        <th className="text-left py-2 text-gray-600 dark:text-gray-400">Fecha</th>
                        <th className="text-left py-2 text-gray-600 dark:text-gray-400">Hora</th>
                        <th className="text-left py-2 text-gray-600 dark:text-gray-400">Origen</th>
                        <th className="text-right py-2 text-gray-600 dark:text-gray-400">Costo</th>
                        <th className="text-center py-2 text-gray-600 dark:text-gray-400">Estado</th>
                      </tr>
                    </thead>
                    <tbody>
                      {datosUsuario.aaiprocesod.map((servicio) => (
                        <tr key={servicio.idservicio} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="py-3 text-gray-900 dark:text-white font-mono text-xs">#{servicio.idservicio}</td>
                          <td className="py-3 text-gray-900 dark:text-white">{servicio.fecha}</td>
                          <td className="py-3 text-gray-900 dark:text-white">{servicio.hora}</td>
                          <td className="py-3 text-gray-600 dark:text-gray-400 max-w-[200px] truncate" title={servicio.direccionorigen}>
                            {servicio.direccionorigen}
                          </td>
                          <td className="py-3 text-right font-semibold text-gray-900 dark:text-white">
                            {formatearMoneda(servicio.costototal)}
                          </td>
                          <td className="py-3 text-center">
                            <span 
                              className="px-2 py-1 rounded-full text-xs font-medium"
                              style={{ 
                                backgroundColor: servicio.colorcelda, 
                                color: servicio.colortexto 
                              }}
                            >
                              {servicio.estado}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">
                    No hay servicios en proceso
                  </p>
                  <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">
                    Los servicios activos aparecerán aquí
                  </p>
                </div>
              )}
            </div>

            {/* Historial de Servicios */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                <History className="w-5 h-5 mr-2 text-green-500" />
                Historial Reciente ({datosUsuario.aaihistoriald.length})
              </h3>
              {datosUsuario.aaihistoriald.length > 0 ? (
                <div className="overflow-x-auto overflow-y-auto max-h-[400px]">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-gray-200 dark:border-gray-600">
                        <th className="text-left py-2 text-gray-600 dark:text-gray-400"># Servicio</th>
                        <th className="text-left py-2 text-gray-600 dark:text-gray-400">Fecha</th>
                        <th className="text-left py-2 text-gray-600 dark:text-gray-400">Hora</th>
                        <th className="text-left py-2 text-gray-600 dark:text-gray-400">Origen</th>
                        <th className="text-right py-2 text-gray-600 dark:text-gray-400">Costo</th>
                        <th className="text-center py-2 text-gray-600 dark:text-gray-400">Estado</th>
                      </tr>
                    </thead>
                    <tbody>
                      {datosUsuario.aaihistoriald.slice(0, 10).map((servicio) => (
                        <tr key={servicio.idservicio} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="py-3 text-gray-900 dark:text-white font-mono text-xs">#{servicio.idservicio}</td>
                          <td className="py-3 text-gray-900 dark:text-white">{servicio.fecha}</td>
                          <td className="py-3 text-gray-900 dark:text-white">{servicio.hora}</td>
                          <td className="py-3 text-gray-600 dark:text-gray-400 max-w-[200px] truncate" title={servicio.direccionorigen}>
                            {servicio.direccionorigen}
                          </td>
                          <td className="py-3 text-right font-semibold text-gray-900 dark:text-white">
                            {formatearMoneda(servicio.costototal)}
                          </td>
                          <td className="py-3 text-center">
                            <span 
                              className="px-2 py-1 rounded-full text-xs font-medium"
                              style={{ 
                                backgroundColor: servicio.colorcelda, 
                                color: servicio.colortexto 
                              }}
                            >
                              {servicio.estado}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <History className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">
                    No hay servicios en el historial
                  </p>
                  <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">
                    Los servicios completados aparecerán aquí
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

      </main>

      {/* Diálogo de Confirmación para Salir */}
      <ConfirmDialog
        isOpen={mostrarConfirmacionSalir}
        title="Confirmar Salida"
        message="¿Estás seguro de que deseas cerrar sesión? Tendrás que volver a iniciar sesión para acceder."
        confirmText="Sí, salir"
        cancelText="Cancelar"
        onConfirm={confirmarSalir}
        onCancel={() => setMostrarConfirmacionSalir(false)}
        type="warning"
      />
    </div>
  );
};