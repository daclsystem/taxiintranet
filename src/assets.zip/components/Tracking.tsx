import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Loader2, AlertCircle, MapPin, Clock, User, Car, Phone } from 'lucide-react';
import { obtenerTracking, obtenerRuta } from '../services/trackingService';
import { TrackingResponse, RutaResponse } from '../types/tracking';
import { ThemeToggle } from './ThemeToggle';
import { GoogleMap } from './GoogleMap';

interface TrackingProps {
  token: string;
  onVolver: () => void;
}

/**
 * Componente Tracking - Muestra el seguimiento del servicio
 */
export const Tracking: React.FC<TrackingProps> = ({ token, onVolver }) => {
  const [trackingData, setTrackingData] = useState<TrackingResponse | null>(null);
  const [rutaData, setRutaData] = useState<RutaResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const mapKeyRef = useRef<string>('');

  useEffect(() => {
    cargarTracking();
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [token]);

  useEffect(() => {
    if (trackingData) {
      const { otservicio } = trackingData;
      
      // Si el estado es 8, 9, 10, 11 - refrescar cada 20 segundos
      if ([8, 9, 10, 11].includes(otservicio.idestado)) {
        intervalRef.current = setInterval(() => {
          cargarTracking();
        }, 20000);
      } else {
        // Limpiar intervalo si no necesita refresco
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
          intervalRef.current = null;
        }
      }

      // Si el estado es 8 (En camino), obtener ruta del conductor al primer punto
      if (otservicio.idestado === 8 && trackingData.aotpuntos.length > 0 && 
          otservicio.latitude && otservicio.longitude && 
          otservicio.latitude !== 0 && otservicio.longitude !== 0) {
        const primerPunto = trackingData.aotpuntos[0];
        console.log('Calculando ruta desde conductor:', otservicio.latitude, otservicio.longitude);
        console.log('Hacia primer punto:', primerPunto.latitude, primerPunto.longitude);
        
        if (primerPunto.latitude && primerPunto.longitude && 
            primerPunto.latitude !== 0 && primerPunto.longitude !== 0) {
          obtenerRutaConductor(
            otservicio.latitude,
            otservicio.longitude,
            primerPunto.latitude,
            primerPunto.longitude
          );
        }
      }

      // Generar key única para el mapa solo cuando cambian los puntos
      const newMapKey = `${trackingData.aotpuntos.map(p => `${p.latitude}-${p.longitude}`).join('|')}`;
      if (mapKeyRef.current !== newMapKey) {
        mapKeyRef.current = newMapKey;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [trackingData]);

  const cargarTracking = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await obtenerTracking(token);
      setTrackingData(data);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error desconocido');
    } finally {
      setIsLoading(false);
    }
  };

  const obtenerRutaConductor = async (
    conductorLat: number,
    conductorLng: number,
    destinoLat: number,
    destinoLng: number
  ) => {
    try {
      console.log('Llamando API de ruta:', conductorLat, conductorLng, 'hacia', destinoLat, destinoLng);
      const ruta = await obtenerRuta(conductorLat, conductorLng, destinoLat, destinoLng);
      console.log('Respuesta de ruta:', ruta);
      setRutaData(ruta);
    } catch (error) {
      console.error('Error al obtener ruta:', error);
      // Limpiar datos de ruta en caso de error
      setRutaData(null);
    }
  };

  const formatearMoneda = (monto: number): string => {
    return `S/ ${monto.toFixed(2)}`;
  };

  const limpiarTexto = (texto: string): string => {
    return texto
      .replace(/&#x0D;\n/g, '') // Carriage Return + Line Feed codificado HTML
      .replace(/&#13;&#10;/g, '') // Otra codificación HTML de CRLF
      .replace(/\r\n/g, ' ') // Carriage Return + Line Feed estándar
      .replace(/\n/g, ' ') // Line Feed
      .replace(/\r/g, ' ') // Carriage Return
      .replace(/\s+/g, ' ') // Múltiples espacios a uno solo
      .trim();
  };

  if (isLoading && !trackingData) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Cargando tracking...</p>
        </div>
      </div>
    );
  }

  if (error && !trackingData) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            Error al cargar tracking
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-4">{error}</p>
          <button
            onClick={cargarTracking}
            className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200"
          >
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  if (!trackingData) return null;

  const { otservicio, aotpuntos, asrutagps } = trackingData;
  const esPendiente = otservicio.idestado === 7;
  const esEnCamino = otservicio.idestado === 8;
  const esCompletado = [12, 13, 14].includes(otservicio.idestado);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={onVolver}
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors duration-200"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Volver
              </button>
              <h1 className="ml-4 text-xl font-bold text-gray-900 dark:text-white">
                Tracking
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              {[8, 9, 10, 11].includes(otservicio.idestado) && (
                <div className="flex items-center text-sm text-green-600 dark:text-green-400">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                  Actualizando cada 20s
                </div>
              )}
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          
          {/* Panel de Información */}
          <div className="lg:col-span-1 space-y-6">
            
            {/* Estado del Servicio */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
              <div className="text-center mb-4">
                <div 
                  className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium mb-4"
                  style={{ 
                    backgroundColor: otservicio.colorcelda, 
                    color: otservicio.colortexto 
                  }}
                >
                  {otservicio.estado}
                </div>
                
                <div className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                  {formatearMoneda(otservicio.costototal)}
                </div>
                
                {esEnCamino && rutaData && rutaData.time && rutaData.distance && (
                  <div className="text-lg font-semibold text-primary-600 dark:text-primary-400 mb-2">
                    <div className="flex items-center justify-center space-x-2">
                      <Clock className="w-4 h-4" />
                      <span>{Math.round(rutaData.time)} min</span>
                      <span>•</span>
                      <span>{rutaData.distance.toFixed(1)} km</span>
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      Al primer punto
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-3 text-sm text-gray-700 dark:text-gray-300">
                <div className="flex items-center font-medium">
                  <Clock className="w-4 h-4 mr-2 text-gray-400" />
                  <span>Fecha: {otservicio.fecha}</span>
                  <span className="ml-4">Hora: {otservicio.hora}</span>
                </div>
                <div className="flex items-center font-medium">
                  <User className="w-4 h-4 mr-2 text-gray-400" />
                  <span>Tipo pago: {otservicio.tipo}</span>
                </div>
              </div>
            </div>

            {/* Información del Conductor - Solo si no es pendiente y no está completado */}
            {!esPendiente && (
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
                <div className="flex items-center space-x-4 mb-4">
                  <img
                    src={otservicio.foto}
                    alt="Conductor"
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                      {otservicio.nombres}
                    </h3>
                    <div className="flex items-center text-sm text-gray-700 dark:text-gray-300 font-medium">
                      <Car className="w-4 h-4 mr-1" />
                      {otservicio.nplaca}
                    </div>
                    {/* Solo mostrar teléfono si está en camino y no completado */}
                    {esEnCamino && !esCompletado && (
                      <div className="flex items-center text-sm text-gray-700 dark:text-gray-300 font-medium">
                        <Phone className="w-4 h-4 mr-1" />
                        {otservicio.telefonoprincipal}
                      </div>
                    )}
                  </div>
                </div>
                <div className="text-sm text-gray-700 dark:text-gray-300 font-medium">
                  {otservicio.datmovil}
                </div>
              </div>
            )}

            {/* Puntos del Recorrido */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Recorrido</h3>
              <div className="space-y-3">
                {aotpuntos.map((punto, index) => (
                  <div key={punto.item} className="flex items-start space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center mt-0.5 ${
                      index === 0 
                        ? 'bg-green-100 dark:bg-green-900' 
                        : index === aotpuntos.length - 1
                          ? 'bg-red-100 dark:bg-red-900'
                          : 'bg-blue-100 dark:bg-blue-900'
                    }`}>
                      <MapPin className={`w-4 h-4 ${
                        index === 0 
                          ? 'text-green-600 dark:text-green-400' 
                          : index === aotpuntos.length - 1
                            ? 'text-red-600 dark:text-red-400'
                            : 'text-blue-600 dark:text-blue-400'
                      }`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">
                        {index === 0 ? 'Origen' : index === aotpuntos.length - 1 ? 'Destino' : `Punto ${index + 1}`}
                      </p>
                      <p className="text-sm text-gray-700 dark:text-gray-300 break-words font-medium">
                        {punto.direccion}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Mapa */}
          <div className="lg:col-span-2 h-[800px]">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden h-full">
              {trackingData && (
                <GoogleMap
                  key={mapKeyRef.current}
                  origen={aotpuntos.length > 0 ? {
                    lat: aotpuntos[0].latitude,
                    lng: aotpuntos[0].longitude,
                    direccion: aotpuntos[0].direccion
                  } : undefined}
                  destino={aotpuntos.length > 1 ? {
                    lat: aotpuntos[aotpuntos.length - 1].latitude,
                    lng: aotpuntos[aotpuntos.length - 1].longitude,
                    direccion: aotpuntos[aotpuntos.length - 1].direccion
                  } : undefined}
                  conductor={!esPendiente && !esCompletado && otservicio.latitude && otservicio.longitude ? {
                    lat: otservicio.latitude,
                    lng: otservicio.longitude,
                    nombre: otservicio.nombres,
                    angulo: otservicio.angulo
                  } : undefined}
                  todosLosPuntos={aotpuntos.map(punto => ({
                    lat: punto.latitude,
                    lng: punto.longitude,
                    direccion: punto.direccion
                  }))}
                  rutaConductor={esEnCamino && rutaData?.route ? rutaData.route.map(point => ({
                    lat: point.y,
                    lng: point.x
                  })) : []}
                  rutaGPS={esCompletado && asrutagps.length > 0 ? asrutagps.map(punto => ({
                    lat: punto.latitude,
                    lng: punto.longitude
                  })) : undefined}
                  mostrarRutaCompleta={esCompletado}
                  className="h-full"
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
