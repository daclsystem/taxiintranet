import React, { useState, useEffect } from 'react';
import { ArrowLeft, Loader2, AlertCircle, Calendar, Clock, MapPin, User, Car, DollarSign, Phone, Mail, Globe, Printer } from 'lucide-react';
import { obtenerVale } from '../services/valeService';
import { ValeResponse } from '../types/vale';
import { ThemeToggle } from './ThemeToggle';

interface ValeProps {
  token: string;
  onVolver: () => void;
}

/**
 * Componente Vale - Muestra el vale del servicio
 */
export const Vale: React.FC<ValeProps> = ({ token, onVolver }) => {
  const [valeData, setValeData] = useState<ValeResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    cargarVale();
  }, [token]);

  const cargarVale = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await obtenerVale(token);
      setValeData(data);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error desconocido');
    } finally {
      setIsLoading(false);
    }
  };

  const formatearMoneda = (monto: number): string => {
    return `S/ ${monto.toFixed(2)}`;
  };

  const limpiarTexto = (texto: string): string => {
    return texto
      .replace(/&#x0D;\n/g, '') // Carriage Return + Line Feed codificado HTML
      .replace(/&#13;&#10;/g, '') // Otra codificación HTML de CRLF
      .replace(/\r\n/g, ' ') // Carriage Return + Line Feed estándar
      .replace(/\n/g, ' ') // Line Feed
      .replace(/\r/g, ' ') // Carriage Return
      .replace(/\s+/g, ' ') // Múltiples espacios a uno solo
      .trim();
  };

  const handleImprimir = () => {
    window.print();
  };

  const handleAyuda = () => {
    window.open('https://api.whatsapp.com/send?phone=51932116459&text=necesito%20ayuda', '_blank');
  };

  const handleWeb = () => {
    window.open('https://zmovilidad.com', '_blank');
  };

  const handleCorreo = () => {
    window.open('mailto:reservas@zmovilidad.com', '_self');
  };

  const handleLlamada = () => {
    window.open('tel:+15144400', '_self');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Cargando vale...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            Error al cargar vale
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-4">{error}</p>
          <button
            onClick={cargarVale}
            className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200"
          >
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  if (!valeData) return null;

  const { ovservicio } = valeData;
  const esPendiente = ovservicio.idestado === 7;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header - Solo visible en pantalla */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 print:hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={onVolver}
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors duration-200"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Volver
              </button>
              <h1 className="ml-4 text-xl font-bold text-gray-900 dark:text-white">
                Vale de Servicio #{ovservicio.idservicio}
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={handleImprimir}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                <Printer className="w-4 h-4 mr-2" />
                Imprimir
              </button>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {/* Contenido del Vale */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 print:py-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 print:shadow-none print:border-gray-400">
          
          {/* Header del Vale */}
          <div className="text-center py-8 border-b border-gray-200 dark:border-gray-600">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              {ovservicio.solicitante}, gracias por preferirnos
            </h1>
            <div className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              #{ovservicio.idservicio}
            </div>
            <div className="text-4xl font-bold text-primary-600 mb-6">
              {formatearMoneda(ovservicio.costototal)}
            </div>
            
            <div className="flex justify-center space-x-8 text-sm">
              <div className="flex items-center text-gray-700 dark:text-gray-300">
                <Calendar className="w-4 h-4 mr-2 text-gray-500" />
                <span className="font-semibold">Fecha</span>
                <span className="ml-2">{ovservicio.fecha}</span>
              </div>
              <div className="flex items-center text-gray-700 dark:text-gray-300">
                <Clock className="w-4 h-4 mr-2 text-gray-500" />
                <span className="font-semibold">Hora</span>
                <span className="ml-2">{ovservicio.hora}</span>
              </div>
            </div>
          </div>

          {/* Información del Servicio */}
          <div className="p-8">
            <div className="grid md:grid-cols-2 gap-8">
              
              {/* Información Básica */}
              <div className="space-y-4">
                <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                  <span className="font-medium text-gray-700 dark:text-gray-300">Cliente</span>
                  <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.nombrecomercial}</span>
                </div>
                
                <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                  <span className="font-medium text-gray-700 dark:text-gray-300">Traslado</span>
                  <span className="text-gray-900 dark:text-white font-semibold text-right">
                    {limpiarTexto(ovservicio.personal)}
                  </span>
                </div>

                {/* Campos corporativos - Solo mostrar si tipo es Corporativo */}
                {ovservicio.tipo.toLowerCase() === 'corporativo' && (
                  <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                    <span className="font-medium text-gray-700 dark:text-gray-300">Área</span>
                    <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.area && ovservicio.area !== '0' ? ovservicio.area : '-'}</span>
                  </div>
                )}

                {ovservicio.tipo.toLowerCase() === 'corporativo' && (
                  <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                    <span className="font-medium text-gray-700 dark:text-gray-300">Centro costos</span>
                    <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.centrocostos && ovservicio.centrocostos !== '0' ? ovservicio.centrocostos : '-'}</span>
                  </div>
                )}

                {ovservicio.tipo.toLowerCase() === 'corporativo' && (
                  <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                    <span className="font-medium text-gray-700 dark:text-gray-300">Motivo</span>
                    <span className="text-gray-900 dark:text-white font-semibold text-right">{ovservicio.motivosolicitud || '-'}</span>
                  </div>
                )}

                {ovservicio.tipo.toLowerCase() === 'corporativo' && (
                  <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                    <span className="font-medium text-gray-700 dark:text-gray-300">Detalle motivo</span>
                    <span className="text-gray-900 dark:text-white font-semibold text-right">{ovservicio.motivodetalle || '-'}</span>
                  </div>
                )}
              </div>

              {/* Ubicaciones */}
              <div className="space-y-4">
                <div className="py-3 border-b border-gray-200 dark:border-gray-600">
                  <span className="font-medium text-gray-700 dark:text-gray-300 block mb-2">Origen</span>
                  <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.direccionorigen}</span>
                </div>

                {ovservicio.ruta && (
                  <div className="py-3 border-b border-gray-200 dark:border-gray-600">
                    <span className="font-medium text-gray-700 dark:text-gray-300 block mb-2">Ruta adicional</span>
                    <div className="text-gray-900 dark:text-white font-semibold whitespace-pre-line">
                      {limpiarTexto(ovservicio.ruta)}
                    </div>
                  </div>
                )}

                <div className="py-3 border-b border-gray-200 dark:border-gray-600">
                  <span className="font-medium text-gray-700 dark:text-gray-300 block mb-2">Destino</span>
                  <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.direcciondestino}</span>
                </div>
              </div>
            </div>

            {/* Información del Móvil - Solo si no es pendiente */}
            {!esPendiente && (
              <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-600">
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300">Móvil</span>
                      <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.movil}</span>
                    </div>

                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300">Inicio servicio</span>
                      <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.fechorproceso}</span>
                    </div>

                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300">Fin del servicio</span>
                      <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.fechorfinalizado}</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between items-center py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300">Conductor</span>
                      <div className="flex items-center space-x-3">
                        <img
                          src={ovservicio.foto}
                          alt="Conductor"
                          className="w-12 h-12 rounded-full object-cover border-2 border-gray-300 dark:border-gray-600"
                        />
                        <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.nombres}</span>
                      </div>
                    </div>

                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300">Placa</span>
                      <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.nplaca}</span>
                    </div>

                    <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                      <span className="font-medium text-gray-700 dark:text-gray-300">Vehículo</span>
                      <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.datmovil}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Costos */}
            <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-600">
              <div className="space-y-4">
                <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                  <span className="font-medium text-gray-700 dark:text-gray-300">Pago</span>
                  <span className="text-gray-900 dark:text-white font-semibold">{ovservicio.tipo}</span>
                </div>

                <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                  <span className="font-medium text-gray-700 dark:text-gray-300">Costo</span>
                  <span className="text-gray-900 dark:text-white font-semibold">{formatearMoneda(ovservicio.subtotal)}</span>
                </div>

                <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                  <span className="font-medium text-gray-700 dark:text-gray-300">Peaje</span>
                  <span className="text-gray-900 dark:text-white font-semibold">{formatearMoneda(ovservicio.peaje)}</span>
                </div>

                <div className="flex justify-between py-3 border-b border-gray-200 dark:border-gray-600">
                  <span className="font-medium text-gray-700 dark:text-gray-300">Parqueo</span>
                  <span className="text-gray-900 dark:text-white font-semibold">{formatearMoneda(ovservicio.parqueo)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Footer con iconos de acción */}
          <div className="bg-gray-50 dark:bg-gray-700 px-8 py-6 rounded-b-xl print:hidden">
            <div className="flex justify-center space-x-8">
              <button 
                onClick={handleAyuda}
                className="flex flex-col items-center p-4 text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors duration-200"
              >
                <div className="w-12 h-12 bg-gray-200 dark:bg-gray-600 rounded-full flex items-center justify-center mb-2">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <span className="text-sm">Ayuda</span>
              </button>

              <button 
                onClick={handleWeb}
                className="flex flex-col items-center p-4 text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors duration-200"
              >
                <div className="w-12 h-12 bg-gray-200 dark:bg-gray-600 rounded-full flex items-center justify-center mb-2">
                  <Globe className="w-6 h-6" />
                </div>
                <span className="text-sm">Web</span>
              </button>

              <button 
                onClick={handleCorreo}
                className="flex flex-col items-center p-4 text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors duration-200"
              >
                <div className="w-12 h-12 bg-gray-200 dark:bg-gray-600 rounded-full flex items-center justify-center mb-2">
                  <Mail className="w-6 h-6" />
                </div>
                <span className="text-sm">Email</span>
              </button>

              <button 
                onClick={handleLlamada}
                className="flex flex-col items-center p-4 text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors duration-200"
              >
                <div className="w-12 h-12 bg-gray-200 dark:bg-gray-600 rounded-full flex items-center justify-center mb-2">
                  <Phone className="w-6 h-6" />
                </div>
                <span className="text-sm">Llamada</span>
              </button>

              <button 
                onClick={handleImprimir}
                className="flex flex-col items-center p-4 text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors duration-200"
              >
                <div className="w-12 h-12 bg-gray-200 dark:bg-gray-600 rounded-full flex items-center justify-center mb-2">
                  <Printer className="w-6 h-6" />
                </div>
                <span className="text-sm">Imprimir</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};