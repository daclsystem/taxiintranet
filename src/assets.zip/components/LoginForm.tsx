import React, { useState } from 'react';
import { Phone, Mail, Loader2, ArrowRight, Eye, EyeOff, ArrowLeft, X } from 'lucide-react';
import { solicitarCodigo, verificarCodigo, guardarSesion, loginPorEmail, recuperarPassword, actualizarPassword } from '../services/authService';
import { CodeInput } from './CodeInput';
import { Toast } from './Toast';

interface FormData {
  telefono: string;
  email: string;
  password: string;
  codigo: string;
  nuevaPassword: string;
  codigoRecuperacion: string;
}

interface FormErrors {
  telefono?: string;
  email?: string;
  password?: string;
  codigo?: string;
  nuevaPassword?: string;
  codigoRecuperacion?: string;
  general?: string;
}

type LoginMethod = 'email' | 'phone';
type AuthStep = 'login' | 'verify-code' | 'recover-password';

/**
 * Componente de login moderno para Z Movilidad
 * Soporta autenticación por email/contraseña y por teléfono/SMS
 */
export const LoginForm: React.FC = () => {
  const [loginMethod, setLoginMethod] = useState<LoginMethod>('email');
  const [authStep, setAuthStep] = useState<AuthStep>('login');
  const [formData, setFormData] = useState<FormData>({
    telefono: '',
    email: '',
    password: '',
    codigo: '',
    nuevaPassword: '',
    codigoRecuperacion: ''
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [idPersonalRecuperacion, setIdPersonalRecuperacion] = useState<number | null>(null);
  const [toast, setToast] = useState<{
    isVisible: boolean;
    message: string;
    type: 'success' | 'error';
  }>({
    isVisible: false,
    message: '',
    type: 'success'
  });

  const validateEmailForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.email) {
      newErrors.email = 'El usuario es requerido';
    }

    if (!formData.password.trim()) {
      newErrors.password = 'La contraseña es requerida';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validatePhoneForm = (): boolean => {
    const newErrors: FormErrors = {};

    const phoneRegex = /^9\d{8}$/;
    if (!formData.telefono) {
      newErrors.telefono = 'El número de teléfono es requerido';
    } else if (!phoneRegex.test(formData.telefono)) {
      newErrors.telefono = 'Ingresa un número válido (9 dígitos, comenzando con 9)';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateEmailForm()) return;

    setIsLoading(true);
    setErrors({});

    try {
      const response = await loginPorEmail(formData.email, formData.password);
      
      if (response.estatus === 200) {
        guardarSesion({
          idpersonal: response.idpersonal,
          idcliente: response.idcliente,
          key: response.key || ''
        });
        
        window.location.reload();
      } else {
        setErrors({ 
          general: response.message || 'Error al iniciar sesión. Verifica tus credenciales.' 
        });
      }
    } catch (error) {
      setErrors({ 
        general: error instanceof Error ? error.message : 'Error de conexión' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handlePhoneLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validatePhoneForm()) return;

    setIsLoading(true);
    setErrors({});

    try {
      const response = await solicitarCodigo(formData.telefono);
      
      if (response.estatus === 200) {
        setAuthStep('verify-code');
      } else {
        setErrors({ 
          general: response.message || 'Error al enviar código. Intenta nuevamente.' 
        });
      }
    } catch (error) {
      setErrors({ 
        general: error instanceof Error ? error.message : 'Error de conexión' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCodeComplete = async (codigo: string) => {
    setFormData(prev => ({ ...prev, codigo }));
    
    setIsLoading(true);
    setErrors({});

    try {
      const response = await verificarCodigo({
        telefono: formData.telefono,
        codigo,
        vapp: '0.0.0',
        notificacion: '',
        plataforma: 'intranet'
      });

      if (response.estatus === 200) {
        guardarSesion({
          idpersonal: response.idpersonal,
          idcliente: response.idcliente,
          key: response.key || ''
        });
        
        window.location.reload();
      } else {
        setErrors({ 
          general: response.message || 'Código incorrecto. Intenta nuevamente.' 
        });
      }
    } catch (error) {
      setErrors({ 
        general: error instanceof Error ? error.message : 'Error de conexión' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    // Validar que hay un usuario
    if (!formData.email.trim()) {
      setErrors({ email: 'Ingresa tu usuario para recuperar la contraseña' });
      return;
    }

    setIsLoading(true);
    setErrors({});

    try {
      const response = await recuperarPassword(formData.email);
      
      if (response.estatus === 200) {
        setIdPersonalRecuperacion(response.idpersonal);
        setAuthStep('recover-password');
        setToast({
          isVisible: true,
          message: 'Código de recuperación enviado a tu correo',
          type: 'success'
        });
      } else {
        setErrors({ 
          general: response.message || 'Error al enviar código de recuperación' 
        });
      }
    } catch (error) {
      setErrors({ 
        general: error instanceof Error ? error.message : 'Error de conexión' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validaciones
    const newErrors: FormErrors = {};
    
    if (!formData.codigoRecuperacion.trim()) {
      newErrors.codigoRecuperacion = 'El código es requerido';
    } else if (formData.codigoRecuperacion.length !== 6) {
      newErrors.codigoRecuperacion = 'El código debe tener 6 dígitos';
    }
    
    if (!formData.nuevaPassword.trim()) {
      newErrors.nuevaPassword = 'La nueva contraseña es requerida';
    } else if (formData.nuevaPassword.length < 6) {
      newErrors.nuevaPassword = 'La contraseña debe tener al menos 6 caracteres';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    if (!idPersonalRecuperacion) {
      setErrors({ general: 'Error en el proceso de recuperación' });
      return;
    }

    setIsLoading(true);
    setErrors({});

    try {
      const response = await actualizarPassword(
        idPersonalRecuperacion,
        formData.codigoRecuperacion,
        formData.nuevaPassword
      );
      
      if (response.estatus === 200) {
        setToast({
          isVisible: true,
          message: 'Contraseña actualizada exitosamente',
          type: 'success'
        });
        
        // Resetear formulario y volver al login
        setTimeout(() => {
          resetForm();
        }, 2000);
      } else {
        setErrors({ 
          general: response.message || 'Error al actualizar contraseña' 
        });
      }
    } catch (error) {
      setErrors({ 
        general: error instanceof Error ? error.message : 'Error de conexión' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const resetForm = () => {
    setAuthStep('login');
    setFormData({ 
      telefono: '', 
      email: '', 
      password: '', 
      codigo: '',
      nuevaPassword: '',
      codigoRecuperacion: ''
    });
    setErrors({});
    setIdPersonalRecuperacion(null);
  };

  // Modal de recuperación de contraseña
  if (authStep === 'recover-password') {
    return (
      <>
        <div className="min-h-screen flex items-center justify-center p-6">
          <div className="w-full max-w-md">
            <div className="backdrop-blur-xl bg-white/10 dark:bg-black/20 rounded-3xl p-8 shadow-2xl border border-white/20">
              
              {/* Header */}
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-20 h-20 mb-4">
                  <img 
                    src="https://clientes.zmovilidad.app/media/logoz.png" 
                    alt="Z Movilidad" 
                    className="w-20 h-20 object-contain"
                  />
                </div>
                <h1 className="text-2xl font-bold text-white mb-2">Recuperar Contraseña</h1>
                <p className="text-white/80 text-sm">
                  Ingresa el código enviado a<br />
                  <span className="font-semibold">{formData.email}</span>
                </p>
              </div>

              {/* Error General */}
              {errors.general && (
                <div className="mb-6 p-4 bg-red-500/20 backdrop-blur-sm rounded-xl border border-red-500/30">
                  <p className="text-sm text-red-200 text-center">{errors.general}</p>
                </div>
              )}

              <form onSubmit={handleUpdatePassword} className="space-y-6">
                {/* Código de Recuperación */}
                <div className="space-y-2">
                  <label htmlFor="codigoRecuperacion" className="block text-sm font-medium text-white/90">
                    Código de verificación
                  </label>
                  <input
                    type="text"
                    id="codigoRecuperacion"
                    value={formData.codigoRecuperacion}
                    onChange={(e) => handleInputChange('codigoRecuperacion', e.target.value.replace(/\D/g, ''))}
                    maxLength={6}
                    className={`
                      block w-full px-4 py-4 rounded-xl text-white placeholder-white/50
                      bg-white/10 backdrop-blur-sm border border-white/20
                      focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent
                      transition-all duration-200 text-center text-lg font-mono
                      ${errors.codigoRecuperacion ? 'ring-2 ring-red-400 border-red-400' : ''}
                    `}
                    placeholder="123456"
                    autoComplete="off"
                  />
                  {errors.codigoRecuperacion && (
                    <p className="text-sm text-red-300">{errors.codigoRecuperacion}</p>
                  )}
                </div>

                {/* Nueva Contraseña */}
                <div className="space-y-2">
                  <label htmlFor="nuevaPassword" className="block text-sm font-medium text-white/90">
                    Nueva contraseña
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      id="nuevaPassword"
                      value={formData.nuevaPassword}
                      onChange={(e) => handleInputChange('nuevaPassword', e.target.value)}
                      className={`
                        block w-full pl-4 pr-12 py-4 rounded-xl text-white placeholder-white/50
                        bg-white/10 backdrop-blur-sm border border-white/20
                        focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent
                        transition-all duration-200
                        ${errors.nuevaPassword ? 'ring-2 ring-red-400 border-red-400' : ''}
                      `}
                      placeholder="Nueva contraseña"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute inset-y-0 right-0 pr-4 flex items-center text-white/60 hover:text-white/80"
                    >
                      {showNewPassword ? (
                        <EyeOff className="h-5 w-5" />
                      ) : (
                        <Eye className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                  {errors.nuevaPassword && (
                    <p className="text-sm text-red-300">{errors.nuevaPassword}</p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex justify-center items-center py-4 px-6 rounded-xl text-white font-semibold bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2 focus:ring-offset-transparent transform transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none shadow-lg hover:shadow-xl group"
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <span>Actualizar Contraseña</span>
                      <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
                    </>
                  )}
                </button>
              </form>

              {/* Actions */}
              <div className="mt-6">
                <button
                  onClick={() => resetForm()}
                  disabled={isLoading}
                  className="w-full flex justify-center items-center py-3 px-6 rounded-xl text-white/80 font-medium border border-white/20 hover:bg-white/10 transition-all duration-200 disabled:opacity-50"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Volver al login
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Toast */}
        <Toast
          message={toast.message}
          type={toast.type}
          isVisible={toast.isVisible}
          onClose={() => setToast(prev => ({ ...prev, isVisible: false }))}
        />
      </>
    );
  }

  if (authStep === 'verify-code') {
    return (
      <>
        <div className="min-h-screen flex items-center justify-center p-6">
          <div className="w-full max-w-md">
            <div className="backdrop-blur-xl bg-white/10 dark:bg-black/20 rounded-3xl p-8 shadow-2xl border border-white/20">
              
              {/* Header */}
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-20 h-20 mb-4">
                  <img 
                    src="https://clientes.zmovilidad.app/media/logoz.png" 
                    alt="Z Movilidad" 
                    className="w-20 h-20 object-contain"
                  />
                </div>
                <h1 className="text-2xl font-bold text-white mb-2">Verificación</h1>
                <p className="text-white/80 text-sm">
                  Ingresa el código enviado a<br />
                  <span className="font-semibold">+51 {formData.telefono}</span>
                </p>
              </div>

              {/* Error General */}
              {errors.general && (
                <div className="mb-6 p-4 bg-red-500/20 backdrop-blur-sm rounded-xl border border-red-500/30">
                  <p className="text-sm text-red-200 text-center">{errors.general}</p>
                </div>
              )}

              {/* Code Input */}
              <div className="mb-8">
                <CodeInput 
                  length={6} 
                  onComplete={handleCodeComplete}
                  disabled={isLoading}
                />
              </div>

              {/* Actions */}
              <div className="space-y-4">
                <button
                  onClick={() => resetForm()}
                  disabled={isLoading}
                  className="w-full flex justify-center items-center py-3 px-6 rounded-xl text-white/80 font-medium border border-white/20 hover:bg-white/10 transition-all duration-200 disabled:opacity-50"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Cambiar número
                </button>

                <button
                  onClick={() => handlePhoneLogin({ preventDefault: () => {} } as React.FormEvent)}
                  disabled={isLoading}
                  className="w-full text-center text-white/70 hover:text-white text-sm transition-colors duration-200"
                >
                  Reenviar código
                </button>
              </div>

              {isLoading && (
                <div className="flex justify-center mt-6">
                  <Loader2 className="w-6 h-6 animate-spin text-white/60" />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Toast */}
        <Toast
          message={toast.message}
          type={toast.type}
          isVisible={toast.isVisible}
          onClose={() => setToast(prev => ({ ...prev, isVisible: false }))}
        />
      </>
    );
  }

  return (
    <>
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="backdrop-blur-xl bg-white/10 dark:bg-black/20 rounded-3xl p-8 shadow-2xl border border-white/20">
            
            {/* Header */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-20 h-20 mb-4 transform hover:scale-105 transition-transform duration-300 bg-transparent">
                <img 
                  src="https://clientes.zmovilidad.app/media/logoz.png" 
                  alt="Z Movilidad" 
                  className="w-20 h-20 object-contain bg-transparent"
                />
              </div>
              <h1 className="text-2xl font-bold text-white mb-2">Z Movilidad</h1>
              <p className="text-white/80 text-sm">Tu servicio de transporte confiable</p>
            </div>

            {/* Error General */}
            {errors.general && (
              <div className="mb-6 p-4 bg-red-500/20 backdrop-blur-sm rounded-xl border border-red-500/30">
                <p className="text-sm text-red-200 text-center">{errors.general}</p>
              </div>
            )}

            {/* Formulario de Login por Email */}
            <form onSubmit={handleEmailLogin} className="space-y-6">
              <div className="space-y-2">
                <label htmlFor="email" className="block text-sm font-medium text-white/90">
                  Usuario
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-white/60" />
                  </div>
                  <input
                    type="text"
                    id="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    autoComplete="off"
                    spellCheck="false"
                    className={`
                      block w-full pl-12 pr-4 py-4 rounded-xl text-white placeholder-white/50
                      bg-white/10 backdrop-blur-sm border border-white/20
                      focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent
                      transition-all duration-200
                      ${errors.email ? 'ring-2 ring-red-400 border-red-400' : ''}
                    `}
                    placeholder="Tu usuario"
                  />
                </div>
                {errors.email && (
                  <p className="text-sm text-red-300">{errors.email}</p>
                )}
              </div>

              <div className="space-y-2">
                <label htmlFor="password" className="block text-sm font-medium text-white/90">
                  Contraseña
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    id="password"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    className={`
                      block w-full pl-4 pr-12 py-4 rounded-xl text-white placeholder-white/50
                      bg-white/10 backdrop-blur-sm border border-white/20
                      focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent
                      transition-all duration-200
                      ${errors.password ? 'ring-2 ring-red-400 border-red-400' : ''}
                    `}
                    placeholder="Tu contraseña"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-4 flex items-center text-white/60 hover:text-white/80"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
                {errors.password && (
                  <p className="text-sm text-red-300">{errors.password}</p>
                )}
              </div>

              <div className="text-right">
                <button
                  type="button"
                  onClick={handleForgotPassword}
                  disabled={isLoading}
                  className="text-sm text-white/70 hover:text-white transition-colors duration-200 underline underline-offset-2"
                >
                  ¿Olvidaste tu contraseña?
                </button>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex justify-center items-center py-4 px-6 rounded-xl text-white font-semibold bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2 focus:ring-offset-transparent transform transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none shadow-lg hover:shadow-xl group"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <span>Acceder</span>
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
                  </>
                )}
              </button>
            </form>

            {/* Footer */}
            <div className="mt-8 text-center">
              <p className="text-sm text-white/70">
                ¿Necesitas ayuda?{' '}
                <button 
                  onClick={() => window.open('mailto:administracion@zmovilidad.com?subject=Soporte%20Z%20Movilidad&body=Hola,%20necesito%20ayuda%20con%20el%20sistema%20de%20Z%20Movilidad.', '_blank')}
                  className="text-white hover:text-orange-300 font-medium transition-colors duration-200 underline underline-offset-2"
                >
                  Contacta soporte
                </button>
              </p>
            </div>
          </div>

          {/* Elementos decorativos */}
          <div className="absolute top-20 left-10 w-20 h-20 bg-orange-400/20 rounded-full blur-xl"></div>
          <div className="absolute bottom-20 right-10 w-32 h-32 bg-yellow-400/20 rounded-full blur-xl"></div>
        </div>
      </div>

      {/* Toast */}
      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={() => setToast(prev => ({ ...prev, isVisible: false }))}
      />
    </>
  );
};