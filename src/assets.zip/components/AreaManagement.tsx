import React, { useState, useEffect } from 'react';
import { 
  Building, Search, Plus, Download, Edit, Loader2, AlertCircle, 
  ArrowLeft, Filter, RefreshCw, Eye, EyeOff, Trash2, X
} from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';
import { Toast } from './Toast';
import { ConfirmDialog } from './ConfirmDialog';
import { obtenerAreas, exportarAreasXLS, guardarArea } from '../services/areaService';
import { Area, AreaFormData } from '../types/area';

interface AreaManagementProps {
  onVolver: () => void;
}

/**
 * Componente para gestión de áreas
 * Permite consultar, crear, editar y exportar áreas
 */
export const AreaManagement: React.FC<AreaManagementProps> = ({ onVolver }) => {
  const [areas, setAreas] = useState<Area[]>([]);
  const [areasFiltradas, setAreasFiltradas] = useState<Area[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busqueda, setBusqueda] = useState('');
  const [filtroEstado, setFiltroEstado] = useState<'todos' | 'activos' | 'inactivos'>('todos');
  const [mostrarModal, setMostrarModal] = useState(false);
  const [areaEditando, setAreaEditando] = useState<Area | null>(null);
  const [paginaActual, setPaginaActual] = useState(1);
  const [itemsPorPagina] = useState(50);
  const [mostrarConfirmacion, setMostrarConfirmacion] = useState(false);
  const [toast, setToast] = useState<{
    isVisible: boolean;
    message: string;
    type: 'success' | 'error';
  }>({
    isVisible: false,
    message: '',
    type: 'success'
  });

  const [filtrosTabla, setFiltrosTabla] = useState({
    area: '',
    modalidad: '',
    nServicios: '',
    monto: ''
  });

  const [formData, setFormData] = useState<AreaFormData>({
    area: '',
    modalidad: '',
    colorcelda: '#FFFF80',
    colortexto: '#000000',
    idestado: 1
  });

  useEffect(() => {
    cargarAreas();
  }, []);

  useEffect(() => {
    filtrarAreas();
  }, [areas, busqueda, filtroEstado, filtrosTabla]);

  const cargarAreas = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await obtenerAreas();
      setAreas(response.aarea);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error desconocido');
    } finally {
      setIsLoading(false);
    }
  };

  const filtrarAreas = () => {
    let resultado = [...areas];

    // Filtrar por búsqueda
    if (busqueda.trim()) {
      resultado = resultado.filter(area =>
        area.area.toLowerCase().includes(busqueda.toLowerCase()) ||
        area.modalidad.toLowerCase().includes(busqueda.toLowerCase()) ||
        area.idarea.toString().includes(busqueda)
      );
    }

    // Filtrar por estado
    if (filtroEstado === 'activos') {
      resultado = resultado.filter(area => area.idestado === 1);
    } else if (filtroEstado === 'inactivos') {
      resultado = resultado.filter(area => area.idestado === 2);
    }

    setAreasFiltradas(resultado);
    setPaginaActual(1);
  };

  const handleNuevaArea = () => {
    setAreaEditando(null);
    setFormData({
      area: '',
      modalidad: '',
      colorcelda: '#FFFF80',
      colortexto: '#000000',
      idestado: 1
    });
    setMostrarModal(true);
  };

  const handleEditarArea = (area: Area) => {
    setAreaEditando(area);
    setFormData({
      area: area.area,
      modalidad: area.modalidad,
      colorcelda: area.colorcelda,
      colortexto: area.colortexto,
      idestado: area.idestado
    });
    setMostrarModal(true);
  };

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validaciones
    if (!formData.area.trim()) {
      setError('El nombre del área es requerido');
      return;
    }

    setMostrarConfirmacion(true);
  };

  const confirmarGuardar = async () => {
    try {
      setMostrarConfirmacion(false);
      setError(null);
      
      const areaData = {
        idarea: areaEditando ? areaEditando.idarea : 0,
        area: formData.area.trim(),
        idestado: formData.idestado
      };

      await guardarArea(areaData);
      
      setMostrarModal(false);
      setToast({
        isVisible: true,
        message: areaEditando 
          ? 'Área actualizada exitosamente' 
          : 'Área registrada exitosamente',
        type: 'success'
      });
      await cargarAreas();
      
    } catch (error) {
      setToast({
        isVisible: true,
        message: error instanceof Error ? error.message : 'Error al guardar el área',
        type: 'error'
      });
    }
  };

  const handleExportar = () => {
    exportarAreasXLS(areasFiltradas);
  };

  // Paginación
  const totalPaginas = Math.ceil(areasFiltradas.length / itemsPorPagina);
  const indiceInicio = (paginaActual - 1) * itemsPorPagina;
  const indiceFin = indiceInicio + itemsPorPagina;
  const areasActuales = areasFiltradas.slice(indiceInicio, indiceFin);

  const formatearMoneda = (monto: number): string => {
    return `S/ ${monto.toFixed(2)}`;
  };

  if (isLoading && areas.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Cargando áreas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={onVolver}
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors duration-200"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Volver
              </button>
              <h1 className="ml-4 text-xl font-bold text-gray-900 dark:text-white flex items-center">
                <Building className="w-6 h-6 mr-2" />
                Gestión de Áreas
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {areasFiltradas.length} área{areasFiltradas.length !== 1 ? 's' : ''}
              </span>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <div className="w-[95%] mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Controles */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 mb-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            {/* Búsqueda */}
            <div className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={busqueda}
                  onChange={(e) => setBusqueda(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="Buscar por área, modalidad o ID..."
                />
              </div>
            </div>

            {/* Filtros y Acciones */}
            <div className="flex items-center space-x-3">
              {/* Filtro de Estado */}
              <select
                value={filtroEstado}
                onChange={(e) => setFiltroEstado(e.target.value as 'todos' | 'activos' | 'inactivos')}
                className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="todos">Todos los estados</option>
                <option value="activos">Solo activos</option>
                <option value="inactivos">Solo inactivos</option>
              </select>

              {/* Botón Consultar */}
              <button
                onClick={cargarAreas}
                disabled={isLoading}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                Consultar
              </button>

              {/* Botón Nuevo */}
              <button
                onClick={handleNuevaArea}
                className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nuevo
              </button>

              {/* Botón Exportar */}
              <button
                onClick={handleExportar}
                className="flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors duration-200"
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar
              </button>
            </div>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 mr-2" />
              <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
            </div>
          </div>
        )}

        {/* Tabla */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div className="overflow-x-auto overflow-y-auto max-h-[600px]">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700 sticky top-0 z-10">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Área
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Modalidad
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    N° Servicios
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Monto
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Estado
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Acciones
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-600">
                {areasActuales.length > 0 ? (
                  areasActuales.map((area) => (
                    <tr key={area.idarea} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span 
                          className="text-sm text-gray-900 dark:text-white max-w-xs truncate block"
                          title={area.area}
                        >
                          {area.area}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">
                        {area.modalidad || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-900 dark:text-white">
                        {area.nservicios}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-semibold text-gray-900 dark:text-white">
                        {formatearMoneda(area.monto)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          area.idestado === 1 
                            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' 
                            : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                        }`}>
                          {area.idestado === 1 ? (
                            <>
                              <Eye className="w-3 h-3 mr-1" />
                              Activo
                            </>
                          ) : (
                            <>
                              <EyeOff className="w-3 h-3 mr-1" />
                              Inactivo
                            </>
                          )}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <div className="flex items-center space-x-2">
                          {/* Botón Editar */}
                          <button
                            onClick={() => handleEditarArea(area)}
                            className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-200 transition-colors duration-200"
                            title="Editar área"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center">
                      <Building className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500 dark:text-gray-400">
                        {busqueda || filtroEstado !== 'todos' 
                          ? 'No se encontraron áreas con los filtros aplicados' 
                          : 'No hay áreas registradas'
                        }
                      </p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Paginación */}
          {totalPaginas > 1 && (
            <div className="bg-gray-50 dark:bg-gray-700 px-6 py-3 border-t border-gray-200 dark:border-gray-600">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-700 dark:text-gray-300">
                  Mostrando {indiceInicio + 1} a {Math.min(indiceFin, areasFiltradas.length)} de {areasFiltradas.length} resultados
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setPaginaActual(prev => Math.max(prev - 1, 1))}
                    disabled={paginaActual === 1}
                    className="px-3 py-1 text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed text-gray-900 dark:text-white"
                  >
                    Anterior
                  </button>
                  <span className="text-sm text-gray-700 dark:text-gray-300">
                    Página {paginaActual} de {totalPaginas}
                  </span>
                  <button
                    onClick={() => setPaginaActual(prev => Math.min(prev + 1, totalPaginas))}
                    disabled={paginaActual === totalPaginas}
                    className="px-3 py-1 text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed text-gray-900 dark:text-white"
                  >
                    Siguiente
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal para Nuevo/Editar */}
      {mostrarModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            {/* Overlay */}
            <div 
              className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
              onClick={() => setMostrarModal(false)}
            />

            {/* Modal */}
            <div className="inline-block w-full max-w-md p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white dark:bg-gray-800 shadow-xl rounded-2xl">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
                {areaEditando ? 'Editar Área' : 'Nueva Área'}
              </h3>

              <form onSubmit={handleSubmitForm} className="space-y-4">
                {/* Nombre del Área */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Nombre del Área *
                  </label>
                  <input
                    type="text"
                    value={formData.area}
                    onChange={(e) => setFormData(prev => ({ ...prev, area: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Ingresa el nombre del área"
                    required
                  />
                </div>

                {/* Estado - Solo mostrar cuando se edita */}
                {areaEditando && (
                  <div>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.idestado === 1}
                        onChange={(e) => setFormData(prev => ({ 
                          ...prev, 
                          idestado: e.target.checked ? 1 : 2 
                        }))}
                        className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                      />
                      <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                        Área activa
                      </span>
                    </label>
                  </div>
                )}

                {/* Botones */}
                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setMostrarModal(false)}
                    className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={false}
                    className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200 disabled:opacity-50 flex items-center"
                  >
                    {areaEditando ? 'Actualizar' : 'Crear'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Diálogo de Confirmación */}
      <ConfirmDialog
        isOpen={mostrarConfirmacion}
        title={areaEditando ? 'Confirmar Actualización' : 'Confirmar Registro'}
        message={areaEditando 
          ? `¿Estás seguro de que deseas actualizar el área "${formData.area}"?`
          : `¿Estás seguro de que deseas registrar el área "${formData.area}"?`
        }
        confirmText={areaEditando ? 'Actualizar' : 'Registrar'}
        onConfirm={confirmarGuardar}
        onCancel={() => setMostrarConfirmacion(false)}
        type="info"
      />

      {/* Toast de Notificación */}
      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={() => setToast(prev => ({ ...prev, isVisible: false }))}
      />
    </div>
  );
};