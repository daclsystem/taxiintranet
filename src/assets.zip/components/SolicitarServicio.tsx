import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, MapPin, Clock, Car, Calendar, 
  Loader2, AlertCircle, Send,
  CheckCircle, Eye, X
} from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';
import { AutocompleteInput } from './AutocompleteInput';
import { PersonalSearchInput } from './PersonalSearchInput';
import { FavoritosModal } from './FavoritosModal';
import { GoogleMap } from './GoogleMap';
import { Toast } from './Toast';
import { 
  obtenerConfiguracionSolicitud, 
  detectarZona,
  calcularRuta,
  calcularTarifa,
  guardarSolicitud
} from '../services/solicitarService';
import { obtenerSesion } from '../services/authService';
import { guardarPersonal as guardarPersonalService } from '../services/personalService';
import { 
  ConfiguracionSolicitudResponse, 
  SolicitudFormData, 
  Ubicacion,
  SolicitudRequest,
  SolicitudResponse
} from '../types/solicitar';

interface SolicitarServicioProps {
  onVolver: () => void;
  onNavegar: (vista: string) => void;
}

/**
 * Componente principal para solicitar servicios de transporte
 * Incluye formulario completo, mapa interactivo y cálculo de tarifas
 */
export const SolicitarServicio: React.FC<SolicitarServicioProps> = ({ onVolver, onNavegar }) => {
  try {
    const session = obtenerSesion();
    
    // Verificar sesión al cargar el componente
    useEffect(() => {
      if (!session || !session.key || !session.idpersonal || !session.idcliente) {
        console.error('Sesión inválida:', session);
        setError('Sesión no válida. Por favor, inicia sesión nuevamente.');
        return;
      }
      console.log('Sesión válida:', {
        idpersonal: session.idpersonal,
        idcliente: session.idcliente,
        key: session.key ? 'presente' : 'ausente'
      });
    }, []);

    const [configuracion, setConfiguracion] = useState<ConfiguracionSolicitudResponse | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [isSubmitting, setIsSubmitting] = useState(false);
    
    // Estados para fecha y hora actual
    const [fechaActual, setFechaActual] = useState<string>('');
    const [horaActual, setHoraActual] = useState<string>('');
    
    // Estados para ubicaciones
    const [ubicacionOrigen, setUbicacionOrigen] = useState<Ubicacion | null>(null);
    const [ubicacionDestino, setUbicacionDestino] = useState<Ubicacion | null>(null);
    const [zonaOrigen, setZonaOrigen] = useState<string>('');
    const [zonaDestino, setZonaDestino] = useState<string>('');
    const [rutaInfo, setRutaInfo] = useState<{
      distancia: number;
      tiempo: number;
      zonaOrigen?: string;
      zonaDestino?: string;
    } | null>(null);
    const [isUpdatingFromMarker, setIsUpdatingFromMarker] = useState(false);
    
    // Estados para tarifa
    const [tarifaInfo, setTarifaInfo] = useState<{
      tarifa: number;
      courier: number;
      total: number;
      isLoading: boolean;
    }>({
      tarifa: 0,
      courier: 0,
      total: 0,
      isLoading: false
    });

    // Estados para modales
    const [modalFavoritos, setModalFavoritos] = useState<{
      isOpen: boolean;
      tipo: 'origen' | 'destino';
    }>({
      isOpen: false,
      tipo: 'origen'
    });

    // Estado para modal de agregar personal
    const [modalAgregarPersonal, setModalAgregarPersonal] = useState<{
      isOpen: boolean;
      apellidos: string;
      nombres: string;
      telefono: string;
      tipo: string;
      searchTerm?: string;
    }>({
      isOpen: false,
      apellidos: '',
      nombres: '',
      telefono: '',
      tipo: 'Invitado',
      searchTerm: ''
    });

    // Estado para diálogo de confirmación
    const [dialogoConfirmacion, setDialogoConfirmacion] = useState<{
      isOpen: boolean;
      tipo: 'confirmar' | 'exito';
      response: SolicitudResponse | null;
    }>({
      isOpen: false,
      tipo: 'confirmar',
      response: null
    });

    const [formData, setFormData] = useState<SolicitudFormData>({
      origen: '',
      destino: '',
      tipoServicio: 'inmediato',
      fechaReserva: '',
      horaReserva: '',
      tipoPago: '',
      tipoMovil: '',
      modoUsuario: '',
      tipoServicioDetalle: '',
      observaciones: '',
      centroCostos: '',
      area: '',
      motivo: '',
      detalleMotivo: '',
      personal: undefined
    });

    const [toast, setToast] = useState<{
      isVisible: boolean;
      message: string;
      type: 'success' | 'error';
    }>({
      isVisible: false,
      message: '',
      type: 'success'
    });

    // Establecer fecha y hora actual al cargar
    useEffect(() => {
      const ahora = new Date();
      const fecha = ahora.toISOString().split('T')[0]; // YYYY-MM-DD
      const hora = ahora.toTimeString().slice(0, 5); // HH:MM
      
      setFechaActual(fecha);
      setHoraActual(hora);
      setFormData(prev => ({ 
        ...prev, 
        fechaReserva: fecha,
        horaReserva: hora
      }));
    }, []);

    useEffect(() => {
      cargarConfiguracion();
    }, []);

    // Función para calcular tarifa del servicio
    const calcularTarifaServicio = async () => {
      if (!ubicacionOrigen || !ubicacionDestino || !rutaInfo || !configuracion) {
        console.log('Faltan datos para calcular tarifa');
        return;
      }

      try {
        setTarifaInfo(prev => ({ ...prev, isLoading: true }));
        
        // Obtener sesión fresca
        const sessionActual = obtenerSesion();
        if (!sessionActual || !sessionActual.idcliente) {
          throw new Error('Sesión no válida');
        }

        const tarifaData = {
          modalidad: formData.tipoServicioDetalle === 'Courier' ? 'Courier' : 'Traslado',
          idcliente: sessionActual.idcliente,
          tpago: formData.tipoPago,
          fecha: formData.tipoServicio === 'reserva' ? formData.fechaReserva! : fechaActual,
          hora: formData.tipoServicio === 'reserva' ? formData.horaReserva! : horaActual,
          nusuarios: 1,
          zorigen: zonaOrigen || rutaInfo.zonaOrigen || '',
          zdestino: zonaDestino || rutaInfo.zonaDestino || '',
          tipomovil: formData.tipoMovil,
          tservicio: formData.tipoServicio === 'reserva' ? 1 : 0,
          ttarifario: 'Traslado',
          plataforma: 'Appintranet',
          distancia: rutaInfo.distancia,
          tiempo: rutaInfo.tiempo
        };

        console.log('Calculando tarifa con datos:', tarifaData);

        const tarifaResponse = await calcularTarifa(tarifaData);

        console.log('Respuesta de tarifa:', tarifaResponse);

        setTarifaInfo({
          tarifa: tarifaResponse.tarifa || 0,
          courier: tarifaResponse.courier || 0,
          total: (tarifaResponse.tarifa || 0) + (tarifaResponse.courier || 0),
          isLoading: false
        });
      } catch (error) {
        console.error('Error al calcular tarifa:', error);
        setTarifaInfo(prev => ({ ...prev, isLoading: false }));
        setToast({
          isVisible: true,
          message: 'Error al calcular tarifa del servicio',
          type: 'error'
        });
      }
    };

    // Funciones para manejar el modal de agregar personal
    const abrirModalAgregarPersonal = (searchTerm?: string) => {
      if (searchTerm) {
        // Intentar separar apellidos y nombres del término de búsqueda
        const partes = searchTerm.trim().split(' ');
        let apellidos = '';
        let nombres = '';
        
        if (partes.length === 1) {
          // Solo un nombre, asumir que es nombre
          nombres = partes[0];
        } else if (partes.length === 2) {
          // Dos partes, asumir apellido nombre
          apellidos = partes[0];
          nombres = partes[1];
        } else if (partes.length > 2) {
          // Más de dos partes, asumir que el último es nombre y el resto apellidos
          nombres = partes[partes.length - 1];
          apellidos = partes.slice(0, -1).join(' ');
        }
        
        setModalAgregarPersonal({
          isOpen: true,
          apellidos,
          nombres,
          telefono: '',
          tipo: 'Invitado',
          searchTerm
        });
      } else {
        setModalAgregarPersonal({
          isOpen: true,
          apellidos: '',
          nombres: '',
          telefono: '',
          tipo: 'Invitado',
          searchTerm: ''
        });
      }
    };

    const cerrarModalAgregarPersonal = () => {
      setModalAgregarPersonal({
        isOpen: false,
        apellidos: '',
        nombres: '',
        telefono: '',
        tipo: 'Invitado',
        searchTerm: ''
      });
    };

    const handleInputChangePersonal = (campo: 'apellidos' | 'nombres' | 'telefono' | 'tipo', valor: string) => {
      setModalAgregarPersonal(prev => ({ ...prev, [campo]: valor }));
    };

    const guardarPersonal = async () => {
      try {
        // Validar que todos los campos estén completos
        if (!modalAgregarPersonal.apellidos || !modalAgregarPersonal.nombres || !modalAgregarPersonal.telefono) {
          setToast({
            isVisible: true,
            message: 'Todos los campos son obligatorios',
            type: 'error'
          });
          return;
        }

        // Obtener sesión
        const session = obtenerSesion();
        if (!session || !session.idcliente) {
          setToast({
            isVisible: true,
            message: 'Sesión no válida',
            type: 'error'
          });
          return;
        }

        // Preparar datos del personal (similar a PersonalManagement)
        const personalData = {
          idpersonal: 0, // Nuevo registro
          idcliente: session.idcliente,
          tipodocumento: 'DNI', // Por defecto
          ndocumento: '', // Opcional para este contexto
          apellidos: modalAgregarPersonal.apellidos.trim(),
          nombres: modalAgregarPersonal.nombres.trim(),
          telefono: modalAgregarPersonal.telefono.trim(),
          email: '', // Opcional
          emailverificador: '', // Opcional
          datjefe: '', // Opcional
          area: '', // Opcional
          centrocostos: '', // Opcional
          administrador: false, // Por defecto
          jefe: false, // Por defecto
          validador: false, // Por defecto
          credito: false, // Por defecto
          idestado: 1, // Activo por defecto
          tipo: modalAgregarPersonal.tipo, // Usar el valor seleccionado del combobox
          cargo: '' // Opcional
        };

        // Importar y usar el servicio existente
        const response = await guardarPersonalService(personalData);
        
        // Mostrar mensaje de éxito
        setToast({
          isVisible: true,
          message: 'Personal agregado exitosamente',
          type: 'success'
        });

        // Cerrar modal
        cerrarModalAgregarPersonal();

        // Recargar la configuración para que aparezca en el dropdown
        await actualizarListaPersonal();
        
        // Después de recargar, buscar y seleccionar automáticamente el nuevo usuario
        setTimeout(async () => {
          if (configuracion) {
            const apellidos = modalAgregarPersonal.apellidos.trim();
            const nombres = modalAgregarPersonal.nombres.trim();
            const nombreCompleto = `${apellidos} ${nombres}`;
            
            // Buscar el nuevo personal en la lista actualizada
            const nuevoPersonal = configuracion.aipersonal.find(p => {
              const personalName = p.personal.trim().toLowerCase();
              const searchCompleto = nombreCompleto.toLowerCase();
              
              // Búsqueda por nombre completo
              if (personalName === searchCompleto) return true;
              if (personalName.includes(searchCompleto)) return true;
              
              // Búsqueda por partes del nombre
              const partesPersonal = personalName.split(' ');
              const partesBusqueda = searchCompleto.split(' ');
              
              return partesBusqueda.every(parte => 
                partesPersonal.some(partePersonal => partePersonal.includes(parte))
              );
            });
            
            if (nuevoPersonal) {
              // Actualizar el formulario para seleccionar el nuevo usuario
              setFormData(prev => ({
                ...prev,
                personal: nuevoPersonal.idpersonal
              }));
              
              setToast({
                isVisible: true,
                message: `${nuevoPersonal.personal} ha sido seleccionado automáticamente`,
                type: 'success'
              });
            } else {
              setToast({
                isVisible: true,
                message: `Usuario agregado exitosamente. Por favor, selecciónelo manualmente del listado.`,
                type: 'success'
              });
            }
          }
        }, 200);
        
      } catch (error) {
        setToast({
          isVisible: true,
          message: error instanceof Error ? error.message : 'Error al agregar personal',
          type: 'error'
        });
      }
    };

    // Efecto para recalcular tarifa cuando cambien los valores relevantes
    useEffect(() => {
      if (ubicacionOrigen && ubicacionDestino && rutaInfo && configuracion) {
        console.log('Recalculando tarifa por cambio en dependencias');
        calcularTarifaServicio();
      }
    }, [
      ubicacionOrigen,
      ubicacionDestino, 
      rutaInfo,
      formData.tipoMovil,
      formData.tipoPago,
      formData.tipoServicio,
      formData.fechaReserva,
      formData.horaReserva,
      formData.tipoServicioDetalle
    ]);

    const cargarConfiguracion = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const config = await obtenerConfiguracionSolicitud();
        setConfiguracion(config);
        
        // Establecer valores por defecto
        let tipoPagoDefault = '';
        if (config.aipagos.length > 0) {
          // Buscar si existe "Corporativo", si no usar el primero
          const corporativo = config.aipagos.find(p => p.tipo.toLowerCase() === 'corporativo');
          tipoPagoDefault = corporativo ? corporativo.tipo : config.aipagos[0].tipo;
        }
        
        // Verificar configuración "Area centrocostos fijo"
        const areaCentrosFijo = config.aiconfiguracion?.find(c => 
          c.opcion.toLowerCase().includes('area centrocostos fijo')
        )?.condicion || false;

        console.log('Configuración al cargar:');
        console.log('- Area centrocostos fijo:', areaCentrosFijo);
        console.log('- Centro de costos desde oidatos:', config.oidatos?.centrocostos);
        console.log('- Area desde oidatos:', config.oidatos?.area);
        console.log('- Configuraciones disponibles:', config.aiconfiguracion);

        // Establecer valores por defecto de configuración
        setFormData(prev => ({ 
          ...prev, 
          tipoPago: tipoPagoDefault,
          tipoMovil: config.aimovil.length > 0 ? config.aimovil[0].tipo : '',
          motivo: config.aimotivo.length > 0 ? config.aimotivo[0].motivo : '',
          modoUsuario: 'Para mí',
          tipoServicioDetalle: 'Traslado',
          // Si "Area centrocostos fijo" es true, usar valores de oidatos y bloquear
          // Si es false, permitir selección libre
          centroCostos: areaCentrosFijo 
            ? (config.oidatos?.centrocostos || '') 
            : (config.oidatos?.centrocostos || ''),
          area: areaCentrosFijo 
            ? (config.oidatos?.area || '') 
            : (config.oidatos?.area || '')
        }));
        
      } catch (error) {
        setError(error instanceof Error ? error.message : 'Error desconocido');
      } finally {
        setIsLoading(false);
      }
    };

    // Función para actualizar solo la lista de personal sin resetear el formulario
    const actualizarListaPersonal = async () => {
      try {
        const config = await obtenerConfiguracionSolicitud();
        setConfiguracion(prev => prev ? { ...prev, aipersonal: config.aipersonal } : config);
      } catch (error) {
        console.error('Error al actualizar lista de personal:', error);
        setToast({
          isVisible: true,
          message: 'Error al actualizar lista de personal',
          type: 'error'
        });
      }
    };

    const obtenerConfiguracionOpcion = (opcion: string): boolean => {
      if (!configuracion?.aiconfiguracion) return false;
      
      console.log('Buscando configuración para:', opcion);
      console.log('Configuraciones disponibles:', configuracion.aiconfiguracion);
      
      const config = configuracion.aiconfiguracion.find(c => 
        c.opcion.toLowerCase().includes(opcion.toLowerCase())
      );
      
      console.log('Configuración encontrada:', config);
      return config?.condicion || false;
    };

    // Determinar si los campos son editables y si se muestran
    const esCorporativo = formData.tipoPago === 'Corporativo';
    
    // Verificar configuraciones
    const areaCentrosFijo = obtenerConfiguracionOpcion('Area centrocostos fijo');
    const centroCostosRequerido = obtenerConfiguracionOpcion('Centro de costos');
    const areaRequerida = obtenerConfiguracionOpcion('Area');
    const motivoRequerido = obtenerConfiguracionOpcion('Motivo de solicitud');
    const detalleRequerido = obtenerConfiguracionOpcion('Detalle de motivo');

    // Si "Area centrocostos fijo" es true, los campos están bloqueados
    // Si es false, se aplican las validaciones individuales
    const camposEditables = {
      centroCostos: !areaCentrosFijo,
      area: !areaCentrosFijo,
      motivo: !motivoRequerido,
      detalle: !detalleRequerido
    };

    // Configuraciones de validación para campos obligatorios
    const camposObligatorios = {
      centroCostos: esCorporativo && (areaCentrosFijo || centroCostosRequerido),
      area: esCorporativo && (areaCentrosFijo || areaRequerida),
      motivo: esCorporativo && motivoRequerido,
      detalle: esCorporativo && detalleRequerido
    };

    console.log('Estado actual de validaciones:');
    console.log('- Es corporativo:', esCorporativo);
    console.log('- Area centrocostos fijo:', areaCentrosFijo);
    console.log('- Campos editables:', camposEditables);
    console.log('- Campos obligatorios:', camposObligatorios);
    console.log('- Datos del usuario (oidatos):', configuracion?.oidatos);
    console.log('- FormData actual:', formData);



    const handleOrigenChange = async (direccion: string, lat?: number, lng?: number) => {
      try {
        console.log('handleOrigenChange llamado con:', { direccion, lat, lng });
        
        setFormData(prev => ({ ...prev, origen: direccion }));
        
        if (lat && lng) {
          console.log('Estableciendo ubicación origen:', { lat, lng, direccion });
          setUbicacionOrigen({ lat, lng, direccion });
          
          // Si también tenemos destino, calcular ruta
          if (ubicacionDestino) {
            console.log('Calculando ruta con destino existente');
            await calcularRutaCompleta({ lat, lng, direccion }, ubicacionDestino);
          }
        } else {
          console.log('Limpiando ubicación origen');
          setUbicacionOrigen(null);
          setRutaInfo(null);
          setTarifaInfo({ tarifa: 0, courier: 0, total: 0, isLoading: false });
        }
      } catch (error) {
        console.error('Error en handleOrigenChange:', error);
        setToast({
          isVisible: true,
          message: 'Error al actualizar origen',
          type: 'error'
        });
      }
    };

    const handleDestinoChange = async (direccion: string, lat?: number, lng?: number) => {
      setFormData(prev => ({ ...prev, destino: direccion }));
      
      if (lat && lng) {
        setUbicacionDestino({ lat, lng, direccion });
        
        // Si también tenemos origen, calcular ruta
        if (ubicacionOrigen) {
          await calcularRutaCompleta(ubicacionOrigen, { lat, lng, direccion });
        }
      } else {
        setUbicacionDestino(null);
        setRutaInfo(null);
        setTarifaInfo({ tarifa: 0, courier: 0, total: 0, isLoading: false });
      }
    };

    const calcularRutaCompleta = async (origen: Ubicacion, destino: Ubicacion) => {
      try {
        console.log('Calculando ruta desde:', origen, 'hacia:', destino);
        
        // Calcular ruta
        const rutaResponse = await calcularRuta(origen.lat, origen.lng, destino.lat, destino.lng);
        console.log('Respuesta de ruta:', rutaResponse);
        
        // Detectar zonas
        const [zonaOrigenResponse, zonaDestinoResponse] = await Promise.all([
          detectarZona(origen.lat, origen.lng),
          detectarZona(destino.lat, destino.lng)
        ]);
        
        console.log('Zona origen:', zonaOrigenResponse);
        console.log('Zona destino:', zonaDestinoResponse);
        
        // Guardar zonas en variables separadas
        const zonaOrigenObtenida = zonaOrigenResponse.oozona?.zona || '';
        const zonaDestinoObtenida = zonaDestinoResponse.oozona?.zona || '';
        
        setZonaOrigen(zonaOrigenObtenida);
        setZonaDestino(zonaDestinoObtenida);
        
        console.log('Zonas establecidas - Origen:', zonaOrigenObtenida, 'Destino:', zonaDestinoObtenida);
        
        setRutaInfo({
          distancia: rutaResponse.distance,
          tiempo: rutaResponse.time,
          zonaOrigen: zonaOrigenObtenida,
          zonaDestino: zonaDestinoObtenida
        });
        
      } catch (error) {
        console.error('Error al calcular ruta:', error);
        setToast({
          isVisible: true,
          message: 'Error al calcular ruta. Intenta nuevamente.',
          type: 'error'
        });
      }
    };

    const handleFavoritoSelect = (direccion: string, lat: number, lng: number) => {
      if (modalFavoritos.tipo === 'origen') {
        handleOrigenChange(direccion, lat, lng);
      } else {
        handleDestinoChange(direccion, lat, lng);
      }
    };

    const handleMapLocationSelect = (lat: number, lng: number, address: string) => {
      // Por ahora, establecer como destino
      handleDestinoChange(address, lat, lng);
    };

    // Función para manejar el arrastre de markers
    const handleMarkerDrag = async (type: 'origen' | 'destino', lat: number, lng: number, address: string) => {
      setIsUpdatingFromMarker(true);
      
      try {
        if (type === 'origen') {
          // Actualizar origen cuando se mueve el marker
          setUbicacionOrigen({ lat, lng, direccion: address });
          setFormData(prev => ({ ...prev, origen: address }));
          
          // Si también tenemos destino, recalcular ruta
          if (ubicacionDestino) {
            await calcularRutaCompleta({ lat, lng, direccion: address }, ubicacionDestino);
          }
        } else if (type === 'destino') {
          // Actualizar destino cuando se mueve el marker
          setUbicacionDestino({ lat, lng, direccion: address });
          setFormData(prev => ({ ...prev, destino: address }));
          
          // Si también tenemos origen, recalcular ruta
          if (ubicacionOrigen) {
            await calcularRutaCompleta(ubicacionOrigen, { lat, lng, direccion: address });
          }
        }
        
        // Mostrar mensaje de éxito
        setToast({
          isVisible: true,
          message: `Ubicación de ${type === 'origen' ? 'origen' : 'destino'} actualizada`,
          type: 'success'
        });
      } catch (error) {
        setToast({
          isVisible: true,
          message: 'Error al actualizar ubicación desde el mapa',
          type: 'error'
        });
      } finally {
        setIsUpdatingFromMarker(false);
      }
    };

    const validarFormulario = (): boolean => {
      if (!ubicacionOrigen) {
        setToast({
          isVisible: true,
          message: 'Debe seleccionar una dirección de origen válida',
          type: 'error'
        });
        return false;
      }

      if (!ubicacionDestino) {
        setToast({
          isVisible: true,
          message: 'Debe seleccionar una dirección de destino válida',
          type: 'error'
        });
        return false;
      }

      if (!rutaInfo) {
        setToast({
          isVisible: true,
          message: 'Debe calcular la ruta antes de continuar',
          type: 'error'
        });
        return false;
      }

      // Validación específica para modo "Para otro"
      if (formData.modoUsuario === 'Para otro' && !formData.personal) {
        setToast({
          isVisible: true,
          message: 'Debe seleccionar un personal para el servicio',
          type: 'error'
        });
        return false;
      }

      // Validaciones específicas para tipo de pago Corporativo
      if (esCorporativo) {
        // Validar centro de costos
        if (camposObligatorios.centroCostos && !(formData.centroCostos || '').trim()) {
          setToast({
            isVisible: true,
            message: 'Debe seleccionar un centro de costos',
            type: 'error'
          });
          return false;
        }

        // Validar área
        if (camposObligatorios.area && !(formData.area || '').trim()) {
          setToast({
            isVisible: true,
            message: 'Debe seleccionar un área',
            type: 'error'
          });
          return false;
        }

        // Validar motivo
        if (camposObligatorios.motivo && !(formData.motivo || '').trim()) {
          setToast({
            isVisible: true,
            message: 'Debe seleccionar un motivo de solicitud',
            type: 'error'
          });
          return false;
        }

        // Validar detalle de motivo
        if (camposObligatorios.detalle && !(formData.detalleMotivo || '').trim()) {
          setToast({
            isVisible: true,
            message: 'Debe escribir el detalle del motivo',
            type: 'error'
          });
          return false;
        }
      }

      // Validación específica para reservas
      if (formData.tipoServicio === 'reserva') {
        if (!formData.fechaReserva || !formData.horaReserva) {
          setToast({
            isVisible: true,
            message: 'Debe especificar fecha y hora para la reserva',
            type: 'error'
          });
          return false;
        }

        // Calcular diferencia en minutos entre fecha/hora actual y fecha/hora de reserva
        const ahora = new Date();
        const fechaHoraReserva = new Date(`${formData.fechaReserva}T${formData.horaReserva}:00`);
        const diferenciaMinutos = Math.floor((fechaHoraReserva.getTime() - ahora.getTime()) / (1000 * 60));
        
        // El tiempo mínimo requerido es el tiempo de la ruta (zona de origen)
        const tiempoMinimoRequerido = Math.ceil(rutaInfo.tiempo);
        
        if (diferenciaMinutos < tiempoMinimoRequerido) {
          setToast({
            isVisible: true,
            message: `La reserva debe ser programada con al menos ${tiempoMinimoRequerido} minutos de anticipación. Diferencia actual: ${diferenciaMinutos} minutos.`,
            type: 'error'
          });
          return false;
        }
      }
      return true;
    };

    const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      
      if (!validarFormulario() || !configuracion || !ubicacionOrigen || !ubicacionDestino || !rutaInfo) {
        return;
      }

      // Mostrar diálogo de confirmación antes de enviar
      setDialogoConfirmacion({
        isOpen: true,
        tipo: 'confirmar',
        response: null
      });
    };

    const confirmarSolicitud = async () => {
      const session = obtenerSesion();
      
      if (!session || !session.key || !session.idpersonal || !session.idcliente) {
        setToast({
          isVisible: true,
          message: 'Sesión no válida. Por favor, inicia sesión nuevamente.',
          type: 'error'
        });
        return;
      }

      if (!configuracion || !ubicacionOrigen || !ubicacionDestino || !rutaInfo) {
        return;
      }

      try {
        setDialogoConfirmacion(prev => ({ ...prev, isOpen: false }));
        setIsSubmitting(true);
        setError(null);

        // Obtener sesión fresca
        const sessionActual = obtenerSesion();
        if (!sessionActual || !sessionActual.idcliente) {
          throw new Error('Sesión no válida');
        }

        // Preparar datos para la solicitud
        const solicitudData: SolicitudRequest = {
          idcliente: sessionActual.idcliente.toString(),
          tservicio: formData.tipoServicioDetalle === 'Courier' ? 'Courier' : 'Traslado',
          idpersonal: session.idpersonal,
          solicitante: configuracion.oidatos?.personal || '',
          centrocostos: formData.tipoPago === 'Corporativo' ? (formData.centroCostos || '') : '',
          area: formData.tipoPago === 'Corporativo' ? (formData.area || '') : '',
          motivo: formData.tipoPago === 'Corporativo' ? (formData.motivo || '') : '',
          motivodetalle: formData.tipoPago === 'Corporativo' ? (formData.detalleMotivo || '') : '',
          personalt: formData.modoUsuario === 'Para otro' && formData.personal 
            ? configuracion.aipersonal.find(p => p.idpersonal === formData.personal)?.personal || ''
            : configuracion.oidatos?.personal || '',
          formas: formData.tipoServicio === 'reserva' ? 'Reserva' : 'Inmediato',
          fecha: formData.tipoServicio === 'reserva' ? formData.fechaReserva! : fechaActual,
          hora: formData.tipoServicio === 'reserva' ? formData.horaReserva! : horaActual,
          pago: formData.tipoPago,
          movil: formData.tipoMovil,
          subtotal: tarifaInfo.tarifa,
          costototal: tarifaInfo.total,
          zorigen: zonaOrigen || rutaInfo.zonaOrigen || '',
          latitudeorigen: ubicacionOrigen.lat,
          longitudeorigen: ubicacionOrigen.lng,
          direccionorigen: ubicacionOrigen.direccion,
          zdestino: zonaDestino || rutaInfo.zonaDestino || '',
          latitudedestino: ubicacionDestino.lat,
          longitudedestino: ubicacionDestino.lng,
          direcciondestino: ubicacionDestino.direccion,
          distancia: rutaInfo.distancia,
          tiempo: rutaInfo.tiempo,
          courier: tarifaInfo.courier,
          observaciones: formData.observaciones,
          ipproceso: '10.0.0.0',
          operador: 'Intranet'
        };

        console.log('Enviando solicitud:', solicitudData);
        
        const response = await guardarSolicitud(solicitudData);
        
        console.log('Respuesta de solicitud:', response);
        
        // Mostrar diálogo de éxito
        setDialogoConfirmacion({
          isOpen: true,
          tipo: 'exito',
          response: response
        });
        
        // Mostrar toast con número de servicio
        setToast({
          isVisible: true,
          message: `Servicio #${response.idreserva} creado exitosamente`,
          type: 'success'
        });
        
      } catch (error) {
        setToast({
          isVisible: true,
          message: error instanceof Error ? error.message : 'Error al enviar solicitud',
          type: 'error'
        });
      } finally {
        setIsSubmitting(false);
      }
    };

    // Efecto para recalcular tarifa cuando cambien los valores relevantes
    useEffect(() => {
      if (ubicacionOrigen && ubicacionDestino && rutaInfo && configuracion) {
        console.log('Recalculando tarifa por cambio en dependencias');
        calcularTarifaServicio();
      }
    }, [
      ubicacionOrigen,
      ubicacionDestino, 
      rutaInfo,
      formData.tipoMovil,
      formData.tipoPago,
      formData.tipoServicio,
      formData.fechaReserva,
      formData.horaReserva,
      formData.tipoServicioDetalle
    ]);

    const formatearMoneda = (monto: number): string => {
      return `S/ ${monto.toFixed(2)}`;
    };

    const formatearTiempo = (minutos: number): string => {
      if (minutos < 60) {
        return `${Math.round(minutos)} min`;
      }
      const horas = Math.floor(minutos / 60);
      const mins = Math.round(minutos % 60);
      return `${horas}h ${mins}min`;
    };

    const formatearDistancia = (km: number): string => {
      if (km < 1) {
        return `${Math.round(km * 1000)} m`;
      }
      return `${km.toFixed(1)} km`;
    };

    if (isLoading) {
      return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Cargando configuración...</p>
          </div>
        </div>
      );
    }

    if (error) {
      return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center max-w-md mx-auto p-6">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Error al cargar configuración
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-4">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200"
            >
              Reintentar
            </button>
          </div>
        </div>
      );
    }

    if (!configuracion) return null;

    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        {/* Header */}
        <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center">
                <button
                  onClick={onVolver}
                  className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors duration-200"
                >
                  <ArrowLeft className="w-5 h-5 mr-2" />
                  Volver
                </button>
                <h1 className="ml-4 text-xl font-bold text-gray-900 dark:text-white flex items-center">
                  <Car className="w-6 h-6 mr-2" />
                  Solicitar Servicio
                </h1>
              </div>
              <ThemeToggle />
            </div>
          </div>
        </header>

        <div className="w-[95%] mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="grid lg:grid-cols-3 gap-6">
            
            {/* Formulario */}
            <div className="lg:col-span-1 space-y-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                
                {/* Ubicaciones */}
                <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                    <MapPin className="w-5 h-5 mr-2" />
                    Ubicaciones
                  </h3>
                  
                  {/* Información sobre markers movibles */}
                  <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg">
                    <p className="text-sm text-blue-800 dark:text-blue-200">
                      <strong>💡 Tip:</strong> También puedes mover los marcadores en el mapa para ajustar las ubicaciones. 
                      Las direcciones se actualizarán automáticamente.
                    </p>
                  </div>
                  
                  <div className="space-y-4">
                    <AutocompleteInput
                      label="Origen"
                      placeholder="¿Desde dónde te recogemos?"
                      value={formData.origen}
                      onChange={handleOrigenChange}
                      onFavoriteClick={() => setModalFavoritos({ isOpen: true, tipo: 'origen' })}
                      showFavoriteButton={true}
                    />
                    
                    <AutocompleteInput
                      label="Destino"
                      placeholder="¿A dónde te llevamos?"
                      value={formData.destino}
                      onChange={handleDestinoChange}
                      onFavoriteClick={() => setModalFavoritos({ isOpen: true, tipo: 'destino' })}
                      showFavoriteButton={true}
                    />
                  </div>
                </div>



                {/* Programación */}
                <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                    <Clock className="w-5 h-5 mr-2" />
                    Programación
                  </h3>
                  
                  <div className="space-y-4">
                    {/* Tipo de servicio */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        ¿Cuándo necesitas el servicio?
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setFormData(prev => ({ ...prev, tipoServicio: 'inmediato' }))}
                          className={`p-3 rounded-lg border-2 transition-all duration-200 ${
                            formData.tipoServicio === 'inmediato'
                              ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300'
                              : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500 text-gray-700 dark:text-gray-300'
                          }`}
                        >
                          <div className="text-center">
                            <Clock className="w-5 h-5 mx-auto mb-1" />
                            <span className="text-sm font-medium">Ahora</span>
                          </div>
                        </button>
                        <button
                          type="button"
                          onClick={() => setFormData(prev => ({ ...prev, tipoServicio: 'reserva' }))}
                          className={`p-3 rounded-lg border-2 transition-all duration-200 ${
                            formData.tipoServicio === 'reserva'
                              ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300'
                              : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500 text-gray-700 dark:text-gray-300'
                          }`}
                        >
                          <div className="text-center">
                            <Calendar className="w-5 h-5 mx-auto mb-1" />
                            <span className="text-sm font-medium">Reservar</span>
                          </div>
                        </button>
                      </div>
                    </div>

                    {/* Fecha y hora de reserva */}
                    {formData.tipoServicio === 'reserva' && (
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Fecha
                          </label>
                          <input
                            type="date"
                            value={formData.fechaReserva}
                            onChange={(e) => setFormData(prev => ({ ...prev, fechaReserva: e.target.value }))}
                            min={fechaActual}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Hora
                          </label>
                          <input
                            type="time"
                            value={formData.horaReserva}
                            onChange={(e) => setFormData(prev => ({ ...prev, horaReserva: e.target.value }))}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                            required
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Configuración */}
                <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                    <Car className="w-5 h-5 mr-2" />
                    Configuración
                  </h3>
                  
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      {/* Tipo de pago */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Tipo de pago
                        </label>
                        <select
                          value={formData.tipoPago}
                          onChange={(e) => setFormData(prev => ({ ...prev, tipoPago: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          required
                        >
                          {configuracion.aipagos.map((pago) => (
                            <option key={pago.tipo} value={pago.tipo}>
                              {pago.tipo}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Tipo de móvil */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Tipo de móvil
                        </label>
                        <select
                          value={formData.tipoMovil}
                          onChange={(e) => setFormData(prev => ({ ...prev, tipoMovil: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          required
                        >
                          {configuracion.aimovil.map((movil) => (
                            <option key={movil.tipo} value={movil.tipo}>
                              {movil.tipo}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Modo de usuario */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Modo de usuario
                        </label>
                        <select
                          value={formData.modoUsuario}
                          onChange={(e) => setFormData(prev => ({ ...prev, modoUsuario: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          required
                        >
                          <option value="Para mí">Para mí</option>
                          <option value="Para otro">Para otro</option>
                        </select>
                      </div>

                      {/* Tipo de servicio */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Tipo de servicio
                        </label>
                        <select
                          value={formData.tipoServicioDetalle}
                          onChange={(e) => setFormData(prev => ({ ...prev, tipoServicioDetalle: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          required
                        >
                          <option value="Traslado">Traslado</option>
                          <option value="Courier">Courier</option>
                        </select>
                      </div>
                    </div>

                    {/* Personal - Solo si es "Para otro" */}
                    {formData.modoUsuario === 'Para otro' && (
                      <PersonalSearchInput
                        label="Seleccionar personal"
                        placeholder="Buscar personal..."
                        value={formData.personal}
                        onChange={(idpersonal) => setFormData(prev => ({ ...prev, personal: idpersonal }))}
                        personalList={configuracion.aipersonal}
                        onAddPersonal={(searchTerm) => abrirModalAgregarPersonal(searchTerm)}
                      />
                    )}

                    {/* Campos corporativos - Solo mostrar si es Corporativo */}
                    {esCorporativo && (
                      <div className="space-y-4 border-t border-gray-200 dark:border-gray-600 pt-4">
                        <h4 className="text-md font-semibold text-gray-900 dark:text-white">
                          Información Corporativa
                        </h4>
                        
                        <div className="grid md:grid-cols-2 gap-4">
                          {/* Centro de costos */}
                          <div className="col-span-2">
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                              Centro de costos {camposObligatorios.centroCostos && <span className="text-red-500">*</span>}
                            </label>
                            {camposEditables.centroCostos ? (
                              <select
                                value={formData.centroCostos}
                                onChange={(e) => setFormData(prev => ({ ...prev, centroCostos: e.target.value }))}
                                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                required={camposObligatorios.centroCostos}
                              >
                                <option value="">Seleccionar centro de costos</option>
                                {configuracion.aicentrocostos.map((centro) => (
                                  <option key={centro.centrocostos} value={centro.centrocostos}>
                                    {centro.centrocostos}
                                  </option>
                                ))}
                              </select>
                            ) : (
                              <input
                                type="text"
                                value={configuracion.oidatos?.centrocostos || 'Centro de costos asignado'}
                                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-100 dark:bg-gray-600 text-gray-700 dark:text-gray-300 cursor-not-allowed"
                                readOnly
                              />
                            )}
                          </div>

                          {/* Área */}
                          <div className="col-span-2">
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                              Área {camposObligatorios.area && <span className="text-red-500">*</span>}
                            </label>
                            {camposEditables.area ? (
                              <select
                                value={formData.area}
                                onChange={(e) => setFormData(prev => ({ ...prev, area: e.target.value }))}
                                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                required={camposObligatorios.area}
                              >
                                <option value="">Seleccionar área</option>
                                {configuracion.aiarea.map((area) => (
                                  <option key={area.area} value={area.area}>
                                    {area.area}
                                  </option>
                                ))}
                              </select>
                            ) : (
                              <input
                                type="text"
                                value={configuracion.oidatos?.area || 'Área asignada'}
                                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-100 dark:bg-gray-600 text-gray-700 dark:text-gray-300 cursor-not-allowed"
                                readOnly
                              />
                            )}
                          </div>
                        </div>

                        <div className="space-y-4">
                          {/* Motivo */}
                          <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                              Motivo de solicitud {camposObligatorios.motivo && <span className="text-red-500">*</span>}
                            </label>
                            {camposEditables.motivo ? (
                              <select
                                value={formData.motivo}
                                onChange={(e) => setFormData(prev => ({ ...prev, motivo: e.target.value }))}
                                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                required={camposObligatorios.motivo}
                              >
                                <option value="">Seleccionar motivo</option>
                                {configuracion.aimotivo.map((motivo) => (
                                  <option key={motivo.motivo} value={motivo.motivo}>
                                    {motivo.motivo}
                                  </option>
                                ))}
                              </select>
                            ) : (
                              <input
                                type="text"
                                value={formData.motivo || "Motivo predeterminado"}
                                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-100 dark:bg-gray-600 text-gray-700 dark:text-gray-300 cursor-not-allowed"
                                readOnly
                              />
                            )}
                          </div>

                          {/* Detalle del motivo */}
                          {(camposEditables.detalle || camposObligatorios.detalle) && (
                            <div>
                              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Detalle del motivo {camposObligatorios.detalle && <span className="text-red-500">*</span>}
                              </label>
                              <textarea
                                value={formData.detalleMotivo ?? ''}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  if (value.length <= 250) {
                                    setFormData(prev => ({ ...prev, detalleMotivo: value }));
                                  }
                                }}
                                rows={3}
                                maxLength={250}
                                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none"
                                placeholder="Describe el detalle del motivo..."
                                required={camposObligatorios.detalle}
                              />
                                                             <div className="text-right text-xs text-gray-500 dark:text-gray-400 mt-1">
                                 {(formData.detalleMotivo ?? '').length}/250 caracteres
                               </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Observaciones */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Observaciones
                      </label>
                      <textarea
                        value={formData.observaciones}
                        onChange={(e) => {
                          const value = e.target.value;
                          if (value.length <= 250) {
                            setFormData(prev => ({ ...prev, observaciones: value }));
                          }
                        }}
                        rows={3}
                        maxLength={250}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none"
                        placeholder="Observaciones adicionales..."
                      />
                      <div className="text-right text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {formData.observaciones.length}/250 caracteres
                      </div>
                    </div>
                  </div>
                </div>

                {/* Información de Ruta y Tarifa */}
                {rutaInfo && tarifaInfo.total > 0 && (
                  <div className="bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-xl p-6 border border-primary-200 dark:border-primary-700">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary-600 dark:text-primary-400 mb-2">
                        {tarifaInfo.isLoading ? (
                          <div className="flex items-center justify-center">
                            <Loader2 className="w-6 h-6 animate-spin mr-2" />
                            Calculando...
                          </div>
                        ) : (
                          formatearMoneda(tarifaInfo.total)
                        )}
                      </div>
                      
                      <div className="flex items-center justify-center space-x-6 text-sm text-gray-600 dark:text-gray-400">
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {formatearDistancia(rutaInfo.distancia)}
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {formatearTiempo(rutaInfo.tiempo)}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Botón de envío */}
                <button
                  type="submit"
                  disabled={isSubmitting || !ubicacionOrigen || !ubicacionDestino || !rutaInfo || tarifaInfo.total <= 0}
                  className="w-full flex justify-center items-center py-4 px-6 rounded-xl text-white font-semibold bg-gradient-to-r from-primary-500 to-primary-600 hover:from-primary-600 hover:to-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-400 focus:ring-offset-2 focus:ring-offset-transparent transform transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none shadow-lg hover:shadow-xl group"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Send className="w-5 h-5 mr-2 group-hover:translate-x-1 transition-transform duration-200" />
                      <span>Solicitar Servicio</span>
                    </>
                  )}
                </button>
              </form>
            </div>

                        {/* Mapa */}
            <div className="lg:col-span-2">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden" style={{ height: 'calc(100vh - 8rem)' }}>
                {/* Indicador de markers movibles */}
                <div className="absolute top-4 right-4 z-10 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 border border-gray-200 dark:border-gray-600">
                  <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span>Origen (arrastra para mover)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400 mt-1">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span>Destino (arrastra para mover)</span>
                  </div>
                  
                  {/* Indicador de actualización */}
                  {isUpdatingFromMarker && (
                    <div className="mt-2 pt-2 border-t border-gray-200 dark:border-gray-600">
                      <div className="flex items-center space-x-2 text-xs text-blue-600 dark:text-blue-400">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        <span>Actualizando ubicación...</span>
                      </div>
                    </div>
                  )}
                </div>
                
                                  <GoogleMap
                    origen={ubicacionOrigen || undefined}
                    destino={ubicacionDestino || undefined}
                    onLocationSelect={handleMapLocationSelect}
                    onMarkerDrag={handleMarkerDrag}
                    useCustomPins={true}
                    className="h-full w-full"
                  />
              </div>
            </div>
        </div>
      </div>

      {/* Modal de Favoritos */}
      <FavoritosModal
        isOpen={modalFavoritos.isOpen}
        onClose={() => setModalFavoritos({ isOpen: false, tipo: 'origen' })}
        onSelectFavorito={handleFavoritoSelect}
        tipo={modalFavoritos.tipo}
      />

      {/* Diálogo de Confirmación */}
      {dialogoConfirmacion.isOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            {/* Overlay */}
            <div 
              className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
              onClick={() => dialogoConfirmacion.tipo === 'confirmar' && setDialogoConfirmacion({ isOpen: false, tipo: 'confirmar', response: null })}
            />

            {/* Modal */}
            <div className="inline-block w-full max-w-lg p-8 my-8 overflow-hidden text-center align-middle transition-all transform bg-white dark:bg-gray-800 shadow-xl rounded-3xl">
              
              {dialogoConfirmacion.tipo === 'confirmar' ? (
                <>
                  {/* Diálogo de Confirmación */}
                  <div className="w-20 h-20 mx-auto mb-6 bg-primary-100 dark:bg-primary-900/20 rounded-full flex items-center justify-center">
                    <Send className="w-10 h-10 text-primary-600 dark:text-primary-400" />
                  </div>

                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                    Confirmar Solicitud
                  </h3>

                  <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-6 mb-6 text-left">
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Origen:</span>
                        <span className="text-gray-900 dark:text-white font-medium">{ubicacionOrigen?.direccion}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Destino:</span>
                        <span className="text-gray-900 dark:text-white font-medium">{ubicacionDestino?.direccion}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Tipo:</span>
                        <span className="text-gray-900 dark:text-white font-medium">{formData.tipoServicio === 'inmediato' ? 'Inmediato' : 'Reserva'}</span>
                      </div>
                      {formData.tipoServicio === 'reserva' && (
                        <div className="flex justify-between">
                          <span className="text-gray-600 dark:text-gray-400">Fecha/Hora:</span>
                          <span className="text-gray-900 dark:text-white font-medium">{formData.fechaReserva} {formData.horaReserva}</span>
                        </div>
                      )}
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Costo:</span>
                        <span className="text-primary-600 dark:text-primary-400 font-bold text-lg">{formatearMoneda(tarifaInfo.total)}</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    ¿Estás seguro de que deseas solicitar este servicio?
                  </p>

                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      onClick={() => setDialogoConfirmacion({ isOpen: false, tipo: 'confirmar', response: null })}
                      disabled={isSubmitting}
                      className="flex-1 py-3 px-6 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200 font-medium disabled:opacity-50"
                    >
                      Cancelar
                    </button>
                    <button
                      onClick={confirmarSolicitud}
                      disabled={isSubmitting}
                      className="flex-1 flex items-center justify-center py-3 px-6 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-colors duration-200 font-medium disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      ) : (
                        <Send className="w-4 h-4 mr-2" />
                      )}
                      Confirmar Solicitud
                    </button>
                  </div>
                </>
              ) : (
                <>
                  {/* Diálogo de Éxito */}
                  <div className="w-20 h-20 mx-auto mb-6 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-10 h-10 text-green-600 dark:text-green-400" />
                  </div>

                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                    ¡Servicio Generado!
                  </h3>

                  {/* Número de reserva */}
                  {dialogoConfirmacion.response && (
                    <div className="bg-primary-50 dark:bg-primary-900/20 rounded-xl p-6 mb-6">
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                        Número de servicio
                      </p>
                      <p className="text-3xl font-bold text-primary-600 dark:text-primary-400">
                        #{dialogoConfirmacion.response.idreserva}
                      </p>
                    </div>
                  )}

                  {/* Botones */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      onClick={() => {
                        setDialogoConfirmacion({ isOpen: false, tipo: 'confirmar', response: null });
                        onNavegar('mis-servicios');
                      }}
                      className="flex-1 flex items-center justify-center py-3 px-6 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-colors duration-200 font-medium"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Ver Mis Servicios
                    </button>
                    <button
                      onClick={() => {
                        setDialogoConfirmacion({ isOpen: false, tipo: 'confirmar', response: null });
                        onVolver();
                      }}
                      className="flex-1 py-3 px-6 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200 font-medium"
                    >
                      Volver al Dashboard
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Toast de Notificación */}
      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={() => setToast(prev => ({ ...prev, isVisible: false }))}
      />

      {/* Modal de Agregar Personal */}
      {modalAgregarPersonal.isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                Agregar Personal
              </h3>
              <button
                onClick={cerrarModalAgregarPersonal}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors duration-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mostrar término de búsqueda si existe */}
            {modalAgregarPersonal.searchTerm && (
              <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg">
                <p className="text-sm text-blue-800 dark:text-blue-200">
                  <strong>Búsqueda:</strong> "{modalAgregarPersonal.searchTerm}"
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-300 mt-1">
                  Los campos se han pre-llenado automáticamente. Puede modificarlos si es necesario.
                </p>
              </div>
            )}

            <div className="space-y-4">
              {/* Apellidos */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Apellidos *
                </label>
                <input
                  type="text"
                  value={modalAgregarPersonal.apellidos}
                  onChange={(e) => handleInputChangePersonal('apellidos', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="Ingrese apellidos"
                  required
                />
              </div>

              {/* Nombres */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Nombres *
                </label>
                <input
                  type="text"
                  value={modalAgregarPersonal.nombres}
                  onChange={(e) => handleInputChangePersonal('nombres', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="Ingrese nombres"
                  required
                />
              </div>

              {/* Teléfono */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Teléfono *
                </label>
                <input
                  type="tel"
                  value={modalAgregarPersonal.telefono}
                  onChange={(e) => handleInputChangePersonal('telefono', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="Ingrese teléfono"
                  required
                />
              </div>

              {/* Tipo - OCULTO: Se envía automáticamente como "Invitado" */}
              {/* <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Tipo *
                </label>
                <select
                  value={modalAgregarPersonal.tipo}
                  onChange={(e) => handleInputChangePersonal('tipo', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  required
                >
                  <option value="Personal">Personal</option>
                  <option value="Invitado">Invitado</option>
                </select>
              </div> */}
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={cerrarModalAgregarPersonal}
                className="flex-1 py-2 px-4 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200 font-medium"
              >
                Cancelar
              </button>
              <button
                onClick={guardarPersonal}
                disabled={!modalAgregarPersonal.apellidos || !modalAgregarPersonal.nombres || !modalAgregarPersonal.telefono}
                className="flex-1 py-2 px-4 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Guardar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
  } catch (error) {
    console.error('Error inesperado en SolicitarServicio:', error);
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-6">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            Error inesperado
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Ha ocurrido un error inesperado. Por favor, intenta nuevamente o contacta al soporte.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200"
          >
            Reintentar
          </button>
        </div>
      </div>
    );
  }
};