import React, { useState, useEffect } from 'react';
import { 
  Users, Search, Plus, Download, Edit, Loader2, AlertCircle, 
  ArrowLeft, RefreshCw, Eye, EyeOff, Shield, UserCheck, CreditCard,
  Phone, Mail, Building, DollarSign, User, Trash2, X
} from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';
import { Toast } from './Toast';
import { ConfirmDialog } from './ConfirmDialog';
import { obtenerPersonal, exportarPersonalXLS, guardarPersonal, obtenerDatosPersonal } from '../services/personalService';
import { Personal, PersonalFormData, PersonalDataResponse } from '../types/personal';

interface PersonalManagementProps {
  onVolver: () => void;
}

/**
 * Componente para gestión de personal
 * Permite consultar, crear, editar y exportar personal
 */
export const PersonalManagement: React.FC<PersonalManagementProps> = ({ onVolver }) => {
  const [personal, setPersonal] = useState<Personal[]>([]);
  const [personalFiltrado, setPersonalFiltrado] = useState<Personal[]>([]);
  const [datosConfiguracion, setDatosConfiguracion] = useState<PersonalDataResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingConfig, setIsLoadingConfig] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busqueda, setBusqueda] = useState('');
  const [filtroEstado, setFiltroEstado] = useState<'todos' | 'activos' | 'inactivos'>('todos');
  const [filtroTipo, setFiltroTipo] = useState<'todos' | 'Personal' | 'Invitado'>('todos');
  const [mostrarModal, setMostrarModal] = useState(false);
  const [personalEditando, setPersonalEditando] = useState<Personal | null>(null);
  const [paginaActual, setPaginaActual] = useState(1);
  const [itemsPorPagina] = useState(50);
  const [mostrarConfirmacion, setMostrarConfirmacion] = useState(false);
  const [toast, setToast] = useState<{
    isVisible: boolean;
    message: string;
    type: 'success' | 'error';
  }>({
    isVisible: false,
    message: '',
    type: 'success'
  });

  const [filtrosTabla, setFiltrosTabla] = useState({
    personal: '',
    datos: '',
    contacto: '',
    area: '',
    centroCostos: '',
    jefe: '',
    servicios: ''
  });

  const [formData, setFormData] = useState<PersonalFormData>({
    tipodocumento: 'DNI',
    ndocumento: '',
    apellidos: '',
    nombres: '',
    telefono: '',
    email: '',
    emailverificador: '',
    datjefe: '',
    area: '',
    centrocostos: '',
    administrador: false,
    jefe: false,
    validador: false,
    credito: false,
    idestado: 1,
    tipo: 'Personal',
    cargo: ''
  });

  useEffect(() => {
    cargarPersonal();
  }, []);

  useEffect(() => {
    filtrarPersonal();
  }, [personal, busqueda, filtroEstado, filtroTipo, filtrosTabla]);

  const cargarPersonal = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await obtenerPersonal();
      setPersonal(response.apersonal);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error desconocido');
    } finally {
      setIsLoading(false);
    }
  };

  const cargarDatosConfiguracion = async () => {
    try {
      setIsLoadingConfig(true);
      const response = await obtenerDatosPersonal();
      setDatosConfiguracion(response);
    } catch (error) {
      console.error('Error al cargar datos de configuración:', error);
    } finally {
      setIsLoadingConfig(false);
    }
  };

  const filtrarPersonal = () => {
    let resultado = [...personal];

    // Filtrar por búsqueda general
    if (busqueda.trim()) {
      resultado = resultado.filter(p =>
        p.nombres.toLowerCase().includes(busqueda.toLowerCase()) ||
        p.apellidos.toLowerCase().includes(busqueda.toLowerCase()) ||
        p.ndocumento.includes(busqueda) ||
        p.telefono.includes(busqueda) ||
        p.email.toLowerCase().includes(busqueda.toLowerCase()) ||
        p.idpersonal.toString().includes(busqueda)
      );
    }

    // Filtros específicos de tabla
    if (filtrosTabla.personal.trim()) {
      resultado = resultado.filter(p =>
        (p.nombres || '').toLowerCase().includes(filtrosTabla.personal.toLowerCase()) ||
        (p.apellidos || '').toLowerCase().includes(filtrosTabla.personal.toLowerCase()) ||
        p.idpersonal.toString().includes(filtrosTabla.personal)
      );
    }

    if (filtrosTabla.datos.trim()) {
      resultado = resultado.filter(p =>
        (p.ndocumento || '').includes(filtrosTabla.datos)
      );
    }

    if (filtrosTabla.contacto.trim()) {
      resultado = resultado.filter(p =>
        p.email.toLowerCase().includes(filtrosTabla.contacto.toLowerCase()) ||
        p.telefono.includes(filtrosTabla.contacto)
      );
    }

    if (filtrosTabla.area.trim()) {
      resultado = resultado.filter(p =>
        (p.area || '').toLowerCase().includes(filtrosTabla.area.toLowerCase())
      );
    }

    if (filtrosTabla.centroCostos.trim()) {
      resultado = resultado.filter(p =>
        (p.centrocostos || '').toLowerCase().includes(filtrosTabla.centroCostos.toLowerCase())
      );
    }

    if (filtrosTabla.jefe.trim()) {
      resultado = resultado.filter(p =>
        (p.datjefe || '').toLowerCase().includes(filtrosTabla.jefe.toLowerCase())
      );
    }

    if (filtrosTabla.servicios.trim()) {
      resultado = resultado.filter(p =>
        p.nservicios.toString().includes(filtrosTabla.servicios) ||
        p.monto.toString().includes(filtrosTabla.servicios)
      );
    }

    // Filtrar por estado
    if (filtroEstado === 'activos') {
      resultado = resultado.filter(p => p.idestado === 1);
    } else if (filtroEstado === 'inactivos') {
      resultado = resultado.filter(p => p.idestado === 2);
    }

    // Filtrar por tipo
    if (filtroTipo !== 'todos') {
      resultado = resultado.filter(p => p.tipo === filtroTipo);
    }

    setPersonalFiltrado(resultado);
    setPaginaActual(1);
  };

  const handleFiltroTablaChange = (campo: keyof typeof filtrosTabla, valor: string) => {
    setFiltrosTabla(prev => ({ ...prev, [campo]: valor }));
  };

  const handleNuevoPersonal = async () => {
    setPersonalEditando(null);
    setFormData({
      tipodocumento: 'DNI',
      ndocumento: '',
      apellidos: '',
      nombres: '',
      telefono: '',
      email: '',
      emailverificador: '',
      datjefe: '',
      area: '',
      centrocostos: '',
      administrador: false,
      jefe: false,
      validador: false,
      credito: false,
      idestado: 1,
      tipo: 'Personal',
      cargo: ''
    });
    await cargarDatosConfiguracion();
    setMostrarModal(true);
  };

  const handleEditarPersonal = async (personalItem: Personal) => {
    setPersonalEditando(personalItem);
    setFormData({
      tipodocumento: personalItem.tipodocumento || 'DNI',
      ndocumento: personalItem.ndocumento || '',
      apellidos: personalItem.apellidos || '',
      nombres: personalItem.nombres || '',
      telefono: personalItem.telefono || '',
      email: personalItem.email || '',
      emailverificador: personalItem.emailverificador || '',
      datjefe: personalItem.datjefe || '',
      area: personalItem.area || '',
      centrocostos: personalItem.centrocostos || '',
      administrador: personalItem.administrador,
      jefe: personalItem.jefe,
      validador: personalItem.validador,
      credito: personalItem.credito,
      idestado: personalItem.idestado,
      tipo: personalItem.tipo || 'Personal',
      cargo: personalItem.cargo || ''
    });
    await cargarDatosConfiguracion();
    setMostrarModal(true);
  };

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validaciones
    if (!formData.nombres.trim()) {
      setError('El nombre es requerido');
      return;
    }
    
    if (!formData.apellidos.trim()) {
      setError('Los apellidos son requeridos');
      return;
    }

    setMostrarConfirmacion(true);
  };

  const confirmarGuardar = async () => {
    try {
      setMostrarConfirmacion(false);
      setError(null);
      
      const personalData = {
        idpersonal: personalEditando ? personalEditando.idpersonal : 0,
        tipodocumento: formData.tipodocumento,
        ndocumento: formData.ndocumento.trim(),
        apellidos: formData.apellidos.trim(),
        nombres: formData.nombres.trim(),
        telefono: formData.telefono.trim(),
        email: formData.email.trim(),
        emailverificador: formData.emailverificador.trim(),
        datjefe: formData.datjefe,
        area: formData.area,
        centrocostos: formData.centrocostos,
        administrador: formData.administrador,
        jefe: formData.jefe,
        validador: formData.validador,
        credito: formData.credito,
        idestado: formData.idestado,
        tipo: formData.tipo,
        cargo: formData.cargo.trim()
      };

      await guardarPersonal(personalData);
      
      setMostrarModal(false);
      setToast({
        isVisible: true,
        message: personalEditando 
          ? 'Personal actualizado exitosamente' 
          : 'Personal registrado exitosamente',
        type: 'success'
      });
      await cargarPersonal();
      
    } catch (error) {
      setToast({
        isVisible: true,
        message: error instanceof Error ? error.message : 'Error al guardar el personal',
        type: 'error'
      });
    }
  };

  const handleExportar = () => {
    exportarPersonalXLS(personalFiltrado);
  };

  // Paginación
  const totalPaginas = Math.ceil(personalFiltrado.length / itemsPorPagina);
  const indiceInicio = (paginaActual - 1) * itemsPorPagina;
  const indiceFin = indiceInicio + itemsPorPagina;
  const personalActual = personalFiltrado.slice(indiceInicio, indiceFin);

  const formatearMoneda = (monto: number): string => {
    return `S/ ${monto.toFixed(2)}`;
  };

  const obtenerBadgesPermisos = (personalItem: Personal) => {
    const badges = [];
    if (personalItem.administrador) badges.push({ text: 'Admin', color: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' });
    if (personalItem.jefe) badges.push({ text: 'Jefe', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' });
    if (personalItem.validador) badges.push({ text: 'Validador', color: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' });
    if (personalItem.credito) badges.push({ text: 'Crédito', color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' });
    return badges;
  };

  if (isLoading && personal.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Cargando personal...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={onVolver}
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors duration-200"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Volver
              </button>
              <h1 className="ml-4 text-xl font-bold text-gray-900 dark:text-white flex items-center">
                <Users className="w-6 h-6 mr-2" />
                Gestión de Personal
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {personalFiltrado.length} persona{personalFiltrado.length !== 1 ? 's' : ''}
              </span>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <div className="w-[95%] mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Controles compactos */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-200 dark:border-gray-700 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                Gestión de Personal
              </h2>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={cargarPersonal}
                disabled={isLoading}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                Consultar
              </button>

              <button
                onClick={handleNuevoPersonal}
                className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nuevo
              </button>

              <button
                onClick={handleExportar}
                className="flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors duration-200"
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar
              </button>
            </div>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 mr-2" />
              <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
            </div>
          </div>
        )}

        {/* Tabla */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div className="overflow-x-auto overflow-y-auto max-h-[600px]">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700 sticky top-0 z-10">
                <tr>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Acciones
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Personal
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Datos
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Contacto
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Área
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Centro Costos
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Jefe
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Crédito
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Permisos
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Servicios
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Estado
                  </th>
                </tr>
                {/* Fila de filtros */}
                <tr className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-600">
                  <td className="px-6 py-2">
                    <button
                      onClick={() => {
                        setBusqueda('');
                        setFiltroEstado('todos');
                        setFiltroTipo('todos');
                        setFiltrosTabla({
                          personal: '',
                          datos: '',
                          contacto: '',
                          area: '',
                          centroCostos: '',
                          jefe: '',
                          servicios: ''
                        });
                      }}
                      className="text-xs text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                      title="Limpiar filtros"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.personal}
                      onChange={(e) => handleFiltroTablaChange('personal', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Buscar personal..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.datos}
                      onChange={(e) => handleFiltroTablaChange('datos', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar documento..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.contacto}
                      onChange={(e) => handleFiltroTablaChange('contacto', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Email/Teléfono..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.area}
                      onChange={(e) => handleFiltroTablaChange('area', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar área..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.centroCostos}
                      onChange={(e) => handleFiltroTablaChange('centroCostos', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar centro..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.jefe}
                      onChange={(e) => handleFiltroTablaChange('jefe', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar jefe..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <span className="text-xs text-gray-400">-</span>
                  </td>
                  <td className="px-6 py-2">
                    <span className="text-xs text-gray-400">-</span>
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.servicios}
                      onChange={(e) => handleFiltroTablaChange('servicios', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="N° servicios..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <div className="flex space-x-1">
                      <select
                        value={filtroTipo}
                        onChange={(e) => setFiltroTipo(e.target.value as 'todos' | 'Personal' | 'Invitado')}
                        className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      >
                        <option value="todos">Todos</option>
                        <option value="Personal">Personal</option>
                        <option value="Invitado">Invitado</option>
                      </select>
                      <select
                        value={filtroEstado}
                        onChange={(e) => setFiltroEstado(e.target.value as 'todos' | 'activos' | 'inactivos')}
                        className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      >
                        <option value="todos">Todos</option>
                        <option value="activos">Activos</option>
                        <option value="inactivos">Inactivos</option>
                      </select>
                    </div>
                  </td>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-600">
                {personalActual.length > 0 ? (
                  personalActual.map((personalItem) => (
                    <tr key={personalItem.idpersonal} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <div className="flex items-center space-x-2">
                          {/* Botón Editar */}
                          <button
                            onClick={() => handleEditarPersonal(personalItem)}
                            className="text-primary-600 hover:text-primary-900 dark:text-primary-400 dark:hover:text-primary-200 transition-colors duration-200"
                            title="Editar personal"
                          >
                            <Edit className="w-4 h-4" />
                          </button>

                          {/* Botón Eliminar */}
                          {/* <button
                            onClick={() => handleEliminar(personalItem)}
                            className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-200 transition-colors duration-200"
                            title="Eliminar personal"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button> */}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div>
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {`${personalItem.nombres || ''} ${personalItem.apellidos || ''}`.trim() || '-'}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            ID: {personalItem.idpersonal}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900 dark:text-white">
                          {personalItem.ndocumento || '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900 dark:text-white">
                          {personalItem.email || '-'}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {personalItem.telefono || '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900 dark:text-white">
                          {personalItem.area || '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="text-sm text-gray-900 dark:text-white">
                          {personalItem.centrocostos || '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="text-sm text-gray-900 dark:text-white">
                          {personalItem.datjefe || '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        {personalItem.credito ? (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
                            <CreditCard className="w-3 h-3 mr-1" />
                            Sí
                          </span>
                        ) : (
                          <span className="text-xs text-gray-400">No</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-wrap gap-1 justify-center">
                          {obtenerBadgesPermisos(personalItem).filter(badge => badge.text !== 'Crédito').map((badge, index) => (
                            <span
                              key={index}
                              className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${badge.color}`}
                            >
                              {badge.text}
                            </span>
                          ))}
                          {obtenerBadgesPermisos(personalItem).filter(badge => badge.text !== 'Crédito').length === 0 && (
                            <span className="text-xs text-gray-400">Sin permisos</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="text-sm">
                          <div className="font-semibold text-gray-900 dark:text-white">
                            {personalItem.nservicios}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            {formatearMoneda(personalItem.monto)}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          personalItem.estado === 'Activo' 
                            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                            : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                        }`}>
                          {personalItem.estado}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={10} className="px-6 py-12 text-center">
                      <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500 dark:text-gray-400">
                        {Object.values(filtrosTabla).some(f => f !== '') || busqueda || filtroEstado !== 'todos' || filtroTipo !== 'todos'
                          ? 'No se encontró personal con los filtros aplicados' 
                          : 'No hay personal registrado'
                        }
                      </p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Paginación */}
          {totalPaginas > 1 && (
            <div className="bg-gray-50 dark:bg-gray-700 px-6 py-3 border-t border-gray-200 dark:border-gray-600">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-700 dark:text-gray-300">
                  Mostrando {indiceInicio + 1} a {Math.min(indiceFin, personalFiltrado.length)} de {personalFiltrado.length} resultados
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setPaginaActual(prev => Math.max(prev - 1, 1))}
                    disabled={paginaActual === 1}
                    className="px-3 py-1 text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed text-gray-900 dark:text-white"
                  >
                    Anterior
                  </button>
                  <span className="text-sm text-gray-700 dark:text-gray-300">
                    Página {paginaActual} de {totalPaginas}
                  </span>
                  <button
                    onClick={() => setPaginaActual(prev => Math.min(prev + 1, totalPaginas))}
                    disabled={paginaActual === totalPaginas}
                    className="px-3 py-1 text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed text-gray-900 dark:text-white"
                  >
                    Siguiente
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal para Nuevo/Editar */}
      {mostrarModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            {/* Overlay */}
            <div 
              className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
              onClick={() => setMostrarModal(false)}
            />

            {/* Modal */}
            <div className="inline-block w-full max-w-4xl p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white dark:bg-gray-800 shadow-xl rounded-2xl">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
                {personalEditando ? 'Editar Personal' : 'Nuevo Personal'}
              </h3>

              {isLoadingConfig ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-8 h-8 animate-spin text-primary-600" />
                  <span className="ml-2 text-gray-600 dark:text-gray-400">
                    Cargando configuración...
                  </span>
                </div>
              ) : (
                <form onSubmit={handleSubmitForm} className="space-y-6">
                  {/* Información Personal */}
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                    <h4 className="text-md font-semibold text-gray-900 dark:text-white mb-4">
                      Información Personal
                    </h4>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Nombres *
                        </label>
                        <input
                          type="text"
                          value={formData.nombres}
                          onChange={(e) => setFormData(prev => ({ ...prev, nombres: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          placeholder="Ingresa los nombres"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Apellidos *
                        </label>
                        <input
                          type="text"
                          value={formData.apellidos}
                          onChange={(e) => setFormData(prev => ({ ...prev, apellidos: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          placeholder="Ingresa los apellidos"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Tipo de Documento
                        </label>
                        <select
                          value={formData.tipodocumento}
                          onChange={(e) => setFormData(prev => ({ ...prev, tipodocumento: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        >
                          <option value="DNI">DNI</option>
                          <option value="CE">Carnet de Extranjería</option>
                          <option value="PASAPORTE">Pasaporte</option>
                          <option value="NINGUNO">Ninguno</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Número de Documento
                        </label>
                        <input
                          type="text"
                          value={formData.ndocumento}
                          onChange={(e) => setFormData(prev => ({ ...prev, ndocumento: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          placeholder="Número de documento"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Teléfono
                        </label>
                        <input
                          type="tel"
                          value={formData.telefono}
                          onChange={(e) => setFormData(prev => ({ ...prev, telefono: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          placeholder="Número de teléfono"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Email
                        </label>
                        <input
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          placeholder="Correo electrónico"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Email Verificador
                        </label>
                        <input
                          type="email"
                          value={formData.emailverificador}
                          onChange={(e) => setFormData(prev => ({ ...prev, emailverificador: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          placeholder="Email verificador"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Cargo
                        </label>
                        <input
                          type="text"
                          value={formData.cargo}
                          onChange={(e) => setFormData(prev => ({ ...prev, cargo: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                          placeholder="Cargo o posición"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Configuración Organizacional */}
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                    <h4 className="text-md font-semibold text-gray-900 dark:text-white mb-4">
                      Configuración Organizacional
                    </h4>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Tipo
                        </label>
                        <select
                          value={formData.tipo}
                          onChange={(e) => setFormData(prev => ({ ...prev, tipo: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        >
                          <option value="Personal">Personal</option>
                          <option value="Invitado">Invitado</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Jefe
                        </label>
                        <select
                          value={formData.datjefe}
                          onChange={(e) => setFormData(prev => ({ ...prev, datjefe: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        >
                          <option value="">Seleccionar jefe</option>
                          {datosConfiguracion?.apjefe.map((jefe, index) => (
                            <option key={index} value={jefe.datjefe}>
                              {jefe.datjefe}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Área
                        </label>
                        <select
                          value={formData.area}
                          onChange={(e) => setFormData(prev => ({ ...prev, area: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        >
                          <option value="">Seleccionar área</option>
                          {datosConfiguracion?.aparea.map((area, index) => (
                            <option key={index} value={area.area}>
                              {area.area}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Centro de Costos
                        </label>
                        <select
                          value={formData.centrocostos}
                          onChange={(e) => setFormData(prev => ({ ...prev, centrocostos: e.target.value }))}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        >
                          <option value="">Seleccionar centro de costos</option>
                          {datosConfiguracion?.apcentrocostos.map((centro, index) => (
                            <option key={index} value={centro.centrocostos}>
                              {centro.centrocostos}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Permisos */}
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                    <h4 className="text-md font-semibold text-gray-900 dark:text-white mb-4">
                      Permisos y Configuración
                    </h4>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={formData.administrador}
                            onChange={(e) => setFormData(prev => ({ ...prev, administrador: e.target.checked }))}
                            className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                          />
                          <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
                            <Shield className="w-4 h-4 mr-1 text-red-500" />
                            Administrador
                          </span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={formData.jefe}
                            onChange={(e) => setFormData(prev => ({ ...prev, jefe: e.target.checked }))}
                            className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                          />
                          <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
                            <UserCheck className="w-4 h-4 mr-1 text-blue-500" />
                            Jefe
                          </span>
                        </label>
                      </div>
                      <div className="space-y-3">
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={formData.validador}
                            onChange={(e) => setFormData(prev => ({ ...prev, validador: e.target.checked }))}
                            className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                          />
                          <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
                            <UserCheck className="w-4 h-4 mr-1 text-green-500" />
                            Validador
                          </span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={formData.credito}
                            onChange={(e) => setFormData(prev => ({ ...prev, credito: e.target.checked }))}
                            className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                          />
                          <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
                            <CreditCard className="w-4 h-4 mr-1 text-yellow-500" />
                            Crédito
                          </span>
                        </label>
                      </div>
                    </div>
                  </div>

                  {/* Estado - Solo mostrar cuando se edita */}
                  {personalEditando && (
                    <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                      <h4 className="text-md font-semibold text-gray-900 dark:text-white mb-4">
                        Estado
                      </h4>
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={formData.idestado === 1}
                          onChange={(e) => setFormData(prev => ({ 
                            ...prev, 
                            idestado: e.target.checked ? 1 : 2 
                          }))}
                          className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                        />
                        <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                          Personal activo
                        </span>
                      </label>
                    </div>
                  )}

                  {/* Botones */}
                  <div className="flex justify-end space-x-3 pt-4">
                    <button
                      type="button"
                      onClick={() => setMostrarModal(false)}
                      className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200 disabled:opacity-50 flex items-center"
                    >
                      {isLoading ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : null}
                      {personalEditando ? 'Actualizar' : 'Crear'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Diálogo de Confirmación */}
      <ConfirmDialog
        isOpen={mostrarConfirmacion}
        title={personalEditando ? 'Confirmar Actualización' : 'Confirmar Registro'}
        message={personalEditando 
          ? `¿Estás seguro de que deseas actualizar a "${formData.nombres} ${formData.apellidos}"?`
          : `¿Estás seguro de que deseas registrar a "${formData.nombres} ${formData.apellidos}"?`
        }
        confirmText={personalEditando ? 'Actualizar' : 'Registrar'}
        onConfirm={confirmarGuardar}
        onCancel={() => setMostrarConfirmacion(false)}
        type="info"
      />

      {/* Toast de Notificación */}
      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={() => setToast(prev => ({ ...prev, isVisible: false }))}
      />
    </div>
  );
};