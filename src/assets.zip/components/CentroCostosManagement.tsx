import React, { useState, useEffect } from 'react';
import { 
  DollarSign, Search, Plus, Download, Edit, Loader2, AlertCircle, 
  ArrowLeft, Filter, RefreshCw, Eye, EyeOff, X
} from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';
import { Toast } from './Toast';
import { ConfirmDialog } from './ConfirmDialog';
import { obtenerCentrosCostos, exportarCentrosCostosXLS, guardarCentroCostos } from '../services/centroCostosService';
import { CentroCostos, CentroCostosFormData } from '../types/centroCostos';

interface CentroCostosManagementProps {
  onVolver: () => void;
}

/**
 * Componente para gestión de centros de costos
 * Permite consultar, crear, editar y exportar centros de costos
 */
export const CentroCostosManagement: React.FC<CentroCostosManagementProps> = ({ onVolver }) => {
  const [centrosCostos, setCentrosCostos] = useState<CentroCostos[]>([]);
  const [centrosCostosFiltrados, setCentrosCostosFiltrados] = useState<CentroCostos[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busqueda, setBusqueda] = useState('');
  const [filtroEstado, setFiltroEstado] = useState<'todos' | 'activos' | 'inactivos'>('todos');
  const [mostrarModal, setMostrarModal] = useState(false);
  const [centroCostosEditando, setCentroCostosEditando] = useState<CentroCostos | null>(null);
  const [paginaActual, setPaginaActual] = useState(1);
  const [itemsPorPagina] = useState(50);
  const [mostrarConfirmacion, setMostrarConfirmacion] = useState(false);
  const [toast, setToast] = useState<{
    isVisible: boolean;
    message: string;
    type: 'success' | 'error';
  }>({
    isVisible: false,
    message: '',
    type: 'success'
  });

  const [filtrosTabla, setFiltrosTabla] = useState({
    centroCostos: '',
    modalidad: '',
    nServicios: '',
    monto: ''
  });

  const [formData, setFormData] = useState<CentroCostosFormData>({
    centrocostos: '',
    modalidad: '',
    colorcelda: '#FFFF80',
    colortexto: '#000000',
    idestado: 1
  });

  useEffect(() => {
    cargarCentrosCostos();
  }, []);

  useEffect(() => {
    filtrarCentrosCostos();
  }, [centrosCostos, busqueda, filtroEstado, filtrosTabla]);

  const cargarCentrosCostos = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await obtenerCentrosCostos();
      setCentrosCostos(response.acentrocostos);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Error desconocido');
    } finally {
      setIsLoading(false);
    }
  };

  const filtrarCentrosCostos = () => {
    let resultado = [...centrosCostos];

    // Filtrar por búsqueda general
    if (busqueda.trim()) {
      resultado = resultado.filter(centro =>
        centro.centrocostos.toLowerCase().includes(busqueda.toLowerCase()) ||
        centro.modalidad.toLowerCase().includes(busqueda.toLowerCase()) ||
        centro.idcentrocostos.toString().includes(busqueda)
      );
    }

    // Filtros específicos de tabla
    if (filtrosTabla.centroCostos.trim()) {
      resultado = resultado.filter(centro =>
        centro.centrocostos.toLowerCase().includes(filtrosTabla.centroCostos.toLowerCase())
      );
    }

    if (filtrosTabla.modalidad.trim()) {
      resultado = resultado.filter(centro =>
        centro.modalidad.toLowerCase().includes(filtrosTabla.modalidad.toLowerCase())
      );
    }

    if (filtrosTabla.nServicios.trim()) {
      resultado = resultado.filter(centro =>
        centro.nservicios.toString().includes(filtrosTabla.nServicios)
      );
    }

    if (filtrosTabla.monto.trim()) {
      resultado = resultado.filter(centro =>
        centro.monto.toString().includes(filtrosTabla.monto)
      );
    }

    // Filtrar por estado
    if (filtroEstado === 'activos') {
      resultado = resultado.filter(centro => centro.idestado === 1);
    } else if (filtroEstado === 'inactivos') {
      resultado = resultado.filter(centro => centro.idestado === 2);
    }

    setCentrosCostosFiltrados(resultado);
    setPaginaActual(1);
  };

  const handleFiltroTablaChange = (campo: keyof typeof filtrosTabla, valor: string) => {
    setFiltrosTabla(prev => ({ ...prev, [campo]: valor }));
  };

  const handleNuevoCentroCostos = () => {
    setCentroCostosEditando(null);
    setFormData({
      centrocostos: '',
      modalidad: '',
      colorcelda: '#FFFF80',
      colortexto: '#000000',
      idestado: 1
    });
    setMostrarModal(true);
  };

  const handleEditarCentroCostos = (centroCostos: CentroCostos) => {
    setCentroCostosEditando(centroCostos);
    setFormData({
      centrocostos: centroCostos.centrocostos,
      modalidad: centroCostos.modalidad,
      colorcelda: centroCostos.colorcelda,
      colortexto: centroCostos.colortexto,
      idestado: centroCostos.idestado
    });
    setMostrarModal(true);
  };

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validaciones
    if (!formData.centrocostos.trim()) {
      setError('El nombre del centro de costos es requerido');
      return;
    }

    setMostrarConfirmacion(true);
  };

  const confirmarGuardar = async () => {
    try {
      setMostrarConfirmacion(false);
      setError(null);
      
      const centroCostosData = {
        idcentrocostos: centroCostosEditando ? centroCostosEditando.idcentrocostos : 0,
        centrocostos: formData.centrocostos.trim(),
        idestado: formData.idestado
      };

      await guardarCentroCostos(centroCostosData);
      
      setMostrarModal(false);
      setToast({
        isVisible: true,
        message: centroCostosEditando 
          ? 'Centro de costos actualizado exitosamente' 
          : 'Centro de costos registrado exitosamente',
        type: 'success'
      });
      await cargarCentrosCostos();
      
    } catch (error) {
      setToast({
        isVisible: true,
        message: error instanceof Error ? error.message : 'Error al guardar el centro de costos',
        type: 'error'
      });
    }
  };

  const handleExportar = () => {
    exportarCentrosCostosXLS(centrosCostosFiltrados);
  };

  // Paginación
  const totalPaginas = Math.ceil(centrosCostosFiltrados.length / itemsPorPagina);
  const indiceInicio = (paginaActual - 1) * itemsPorPagina;
  const indiceFin = indiceInicio + itemsPorPagina;
  const centrosCostosActuales = centrosCostosFiltrados.slice(indiceInicio, indiceFin);

  const formatearMoneda = (monto: number): string => {
    return `S/ ${monto.toFixed(2)}`;
  };

  if (isLoading && centrosCostos.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary-600 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Cargando centros de costos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={onVolver}
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors duration-200"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Volver
              </button>
              <h1 className="ml-4 text-xl font-bold text-gray-900 dark:text-white flex items-center">
                <DollarSign className="w-6 h-6 mr-2" />
                Gestión de Centros de Costos
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {centrosCostosFiltrados.length} centro{centrosCostosFiltrados.length !== 1 ? 's' : ''} de costos
              </span>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <div className="w-[95%] mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Controles compactos */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-200 dark:border-gray-700 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                Gestión de Centros de Costos
              </h2>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={cargarCentrosCostos}
                disabled={isLoading}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                Consultar
              </button>

              <button
                onClick={handleNuevoCentroCostos}
                className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nuevo
              </button>

              <button
                onClick={handleExportar}
                className="flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors duration-200"
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar
              </button>
            </div>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 mr-2" />
              <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
            </div>
          </div>
        )}

        {/* Tabla */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div className="overflow-x-auto overflow-y-auto max-h-[600px]">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700 sticky top-0 z-10">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Centro de Costos
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Modalidad
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    N° Servicios
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Monto
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Estado
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Acciones
                  </th>
                </tr>
                {/* Fila de filtros */}
                <tr className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-600">
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.centroCostos}
                      onChange={(e) => handleFiltroTablaChange('centroCostos', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar centro..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.modalidad}
                      onChange={(e) => handleFiltroTablaChange('modalidad', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar modalidad..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.nServicios}
                      onChange={(e) => handleFiltroTablaChange('nServicios', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="N° servicios..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <input
                      type="text"
                      value={filtrosTabla.monto}
                      onChange={(e) => handleFiltroTablaChange('monto', e.target.value)}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Filtrar monto..."
                    />
                  </td>
                  <td className="px-6 py-2">
                    <select
                      value={filtroEstado}
                      onChange={(e) => setFiltroEstado(e.target.value as 'todos' | 'activos' | 'inactivos')}
                      className="w-full px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    >
                      <option value="todos">Todos</option>
                      <option value="activos">Activos</option>
                      <option value="inactivos">Inactivos</option>
                    </select>
                  </td>
                  <td className="px-6 py-2">
                    <button
                      onClick={() => {
                        setBusqueda('');
                        setFiltroEstado('todos');
                        setFiltrosTabla({
                          centroCostos: '',
                          modalidad: '',
                          nServicios: '',
                          monto: ''
                        });
                      }}
                      className="text-xs text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                      title="Limpiar filtros"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-600">
                {centrosCostosActuales.length > 0 ? (
                  centrosCostosActuales.map((centroCostos) => (
                    <tr key={centroCostos.idcentrocostos} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span 
                          className="text-sm text-gray-900 dark:text-white max-w-xs truncate block"
                          title={centroCostos.centrocostos}
                        >
                          {centroCostos.centrocostos}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">
                        {centroCostos.modalidad || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-900 dark:text-white">
                        {centroCostos.nservicios}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-semibold text-gray-900 dark:text-white">
                        {formatearMoneda(centroCostos.monto)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          centroCostos.idestado === 1 
                            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' 
                            : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                        }`}>
                          {centroCostos.idestado === 1 ? (
                            <>
                              <Eye className="w-3 h-3 mr-1" />
                              Activo
                            </>
                          ) : (
                            <>
                              <EyeOff className="w-3 h-3 mr-1" />
                              Inactivo
                            </>
                          )}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <div className="flex items-center space-x-2">
                          {/* Botón Editar */}
                          <button
                            onClick={() => handleEditarCentroCostos(centroCostos)}
                            className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-200 transition-colors duration-200"
                            title="Editar centro de costos"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center">
                      <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500 dark:text-gray-400">
                        {Object.values(filtrosTabla).some(f => f !== '') || busqueda || filtroEstado !== 'todos' 
                          ? 'No se encontraron centros de costos con los filtros aplicados' 
                          : 'No hay centros de costos registrados'
                        }
                      </p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Paginación */}
          {totalPaginas > 1 && (
            <div className="bg-gray-50 dark:bg-gray-700 px-6 py-3 border-t border-gray-200 dark:border-gray-600">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-700 dark:text-gray-300">
                  Mostrando {indiceInicio + 1} a {Math.min(indiceFin, centrosCostosFiltrados.length)} de {centrosCostosFiltrados.length} resultados
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setPaginaActual(prev => Math.max(prev - 1, 1))}
                    disabled={paginaActual === 1}
                    className="px-3 py-1 text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed text-gray-900 dark:text-white"
                  >
                    Anterior
                  </button>
                  <span className="text-sm text-gray-700 dark:text-gray-300">
                    Página {paginaActual} de {totalPaginas}
                  </span>
                  <button
                    onClick={() => setPaginaActual(prev => Math.min(prev + 1, totalPaginas))}
                    disabled={paginaActual === totalPaginas}
                    className="px-3 py-1 text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed text-gray-900 dark:text-white"
                  >
                    Siguiente
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal para Nuevo/Editar */}
      {mostrarModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            {/* Overlay */}
            <div 
              className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
              onClick={() => setMostrarModal(false)}
            />

            {/* Modal */}
            <div className="inline-block w-full max-w-md p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white dark:bg-gray-800 shadow-xl rounded-2xl">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
                {centroCostosEditando ? 'Editar Centro de Costos' : 'Nuevo Centro de Costos'}
              </h3>

              <form onSubmit={handleSubmitForm} className="space-y-4">
                {/* Nombre del Centro de Costos */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Nombre del Centro de Costos *
                  </label>
                  <input
                    type="text"
                    value={formData.centrocostos}
                    onChange={(e) => setFormData(prev => ({ ...prev, centrocostos: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Ingresa el nombre del centro de costos"
                    required
                  />
                </div>

                {/* Estado - Solo mostrar cuando se edita */}
                {centroCostosEditando && (
                  <div>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.idestado === 1}
                        onChange={(e) => setFormData(prev => ({ 
                          ...prev, 
                          idestado: e.target.checked ? 1 : 2 
                        }))}
                        className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                      />
                      <span className="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                        Centro de costos activo
                      </span>
                    </label>
                  </div>
                )}

                {/* Botones */}
                <div className="flex justify-end space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setMostrarModal(false)}
                    className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={false}
                    className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200 disabled:opacity-50 flex items-center"
                  >
                    {centroCostosEditando ? 'Actualizar' : 'Crear'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Diálogo de Confirmación */}
      <ConfirmDialog
        isOpen={mostrarConfirmacion}
        title={centroCostosEditando ? 'Confirmar Actualización' : 'Confirmar Registro'}
        message={centroCostosEditando 
          ? `¿Estás seguro de que deseas actualizar el centro de costos "${formData.centrocostos}"?`
          : `¿Estás seguro de que deseas registrar el centro de costos "${formData.centrocostos}"?`
        }
        confirmText={centroCostosEditando ? 'Actualizar' : 'Registrar'}
        onConfirm={confirmarGuardar}
        onCancel={() => setMostrarConfirmacion(false)}
        type="info"
      />

      {/* Toast de Notificación */}
      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={() => setToast(prev => ({ ...prev, isVisible: false }))}
      />
    </div>
  );
};