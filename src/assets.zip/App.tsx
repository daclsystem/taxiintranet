import React from 'react';
import { obtenerSesion } from './services/authService';
import { ThemeProvider } from './contexts/ThemeContext';
import { ThemeToggle } from './components/ThemeToggle';
import { LoginForm } from './components/LoginForm';
import { Dashboard } from './components/Dashboard';

function App() {
  const session = obtenerSesion();
  const showDashboard = !!session;

  return (
    <ThemeProvider>
      <div className="min-h-screen relative">
        {/* Imagen de fondo */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: 'url("https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop")'
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-black/40 to-black/60"></div>
        </div>

        {/* Header con toggle de tema - Solo mostrar si no hay sesión */}
        {!showDashboard && (
        <div className="absolute top-4 right-4 z-20">
          <ThemeToggle />
        </div>
        )}

        {/* Contenido principal */}

        <div className="relative z-10">
          {showDashboard ? (
            <Dashboard />
          ) : (
            <LoginForm />
          )}
        </div>
      </div>
    </ThemeProvider>
  );
}

export default App;